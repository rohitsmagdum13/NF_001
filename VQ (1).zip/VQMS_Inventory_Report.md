# VQMS — Inventory Report

_Source: `vqm_ps/` codebase. Read directly from `CLAUDE.md`, `README.md`, `Flow.md`, `src/models/*`, `src/api/routes/*`, `src/orchestration/*`, `src/adapters/*`, `src/db/migrations/*`._

---

## 1. System Identity

- **Project:** VQMS (Vendor Query Management System) — Hexaware Technologies
- **Stack:** Python 3.12 · FastAPI · LangGraph · Amazon Bedrock (Claude Sonnet 3.5 + Titan Embed v2) · Amazon RDS for PostgreSQL (pgvector) · Amazon S3 · Amazon SQS · Amazon EventBridge · Microsoft Graph API · Salesforce CRM · ServiceNow ITSM · Angular 17+ (existing portal)
- **Build status:** Phases 1–6 done. Phase 7 (frontend portal — Angular) partially shipped. Phase 8 (production hardening) planned.
- **Two entry points:** Email (vendor‑support@ via Microsoft Graph API) + Portal (POST /queries).
- **Three resolution paths:** A (AI‑resolved from KB), B (human team investigates), C (low‑confidence human review before drafting).

---

## 2. Modules / Features Found

### Backend (`src/`)

| Layer | Module | Status |
|---|---|---|
| `models/` | auth · communication · email · email_dashboard · memory · query · sla · ticket · triage · vendor · workflow | ✅ |
| `services/auth.py` | JWT login/logout, token blacklist via `cache.kv_store` | ✅ |
| `services/email_intake/` | `service.py`, `parser.py`, `attachment_processor.py`, `vendor_identifier.py`, `thread_correlator.py`, `relevance_filter.py` (4‑layer noise drop), `storage.py` | ✅ |
| `services/portal_submission.py` | Portal POST /queries → SQS | ✅ |
| `services/email_dashboard/` | Read‑only paginated email‑chain dashboard | ✅ |
| `services/admin_email/` | Admin compose / reply on existing trail | ✅ |
| `services/triage.py` | Path C reviewer queue + decision + SQS resume | ✅ |
| `services/sla_monitor.py` | 60s tick, 70/85/95% thresholds, EventBridge fanout | ✅ |
| `services/closure.py` · `auto_close_scheduler.py` | Closure write path + auto‑close after window | ✅ |
| `services/episodic_memory.py` | Closure → `memory.episodic_memory` write‑back | ✅ |
| `services/draft_approval.py` | Draft approval workflow | ✅ |
| `services/polling.py` | Email reconciliation poller (5 min) | ✅ |
| `orchestration/` | `graph.py` (StateGraph), `sqs_consumer.py`, `dependencies.py`, `studio.py` | ✅ |
| `orchestration/nodes/` | context_loading · query_analysis · confidence_check · routing · kb_search · path_decision · resolution · acknowledgment · triage · quality_gate · delivery · resolution_from_notes (Step 15) | ✅ All 12 nodes real |
| `agents/reviewer_copilot/` | LLM copilot for Path C reviewer (SSE streaming) | ✅ |
| `mcp_servers/reviewer/` | MCP server exposing reviewer tools | ✅ |
| `adapters/bedrock.py` · `llm_gateway.py` · `openai_llm.py` | LLM Gateway (Bedrock primary, OpenAI fallback, 4 modes) | ✅ |
| `adapters/graph_api/` | client (MSAL) · email_fetch · email_send · webhook | ✅ |
| `adapters/salesforce/` | client · vendor_lookup · account_operations | ✅ |
| `adapters/servicenow/` | client · ticket_create · ticket_query | ✅ |
| `adapters/textract.py` | Amazon Textract OCR | ✅ |
| `db/connection/` | SSH tunnel → RDS, asyncpg pool, idempotency, cache, health | ✅ |
| `storage/s3_client.py` | Single bucket `vqms-data-store`, prefix‑organized | ✅ |
| `queues/sqs.py` | Producer/consumer, intake + DLQ | ✅ |
| `events/eventbridge.py` | 20 event types (EmailParsed, QueryReceived, HumanReviewRequired, SLAWarning70, SLAEscalation85/95, TicketClosed, …) | ✅ |
| `cache/cache_client.py` | PostgreSQL‑backed kv_store (no Redis anywhere) | ✅ |

### Database (PostgreSQL on Amazon RDS, 6 schemas)

Migrations 000 → 020 in `src/db/migrations/`. Key schemas: `intake`, `workflow`, `memory`, `audit`, `reporting`, `cache`, plus `public` for auth.

### Existing Frontend (`vqm_ps/frontend/` — Angular 17+)

Standalone components present: `core/auth`, `core/layout`, `core/notifications`, `data/*` stores (queries, vendors, emails, triage, draft‑approvals, copilot, path‑b, preferences), feature folders for `admin-dashboard · admin-drafts · admin-ops · admin-path-b · admin-triage · admin-vendors · email · login · portal · preferences · queries · wizard`. Per CLAUDE.md, "zero CSS — browser defaults only" — no design system applied yet.

---

## 3. Entities & Relationships

```
Salesforce Vendor_Account__c (V-001…)
  ├─ vendor_id (PK in our system)
  ├─ name · website · vendor_tier {PLATINUM, GOLD, SILVER, BRONZE}
  ├─ category (drives secondary routing) · payment_terms · annual_revenue
  ├─ sla_response_hours · sla_resolution_days · vendor_status
  └─ billing_city/state/country · onboarded_date
       │
       │ 1:N
       ▼
intake.email_messages / intake.portal_queries
  ├─ query_id (VQ-2026-XXXX)  ◄── unique business key
  ├─ correlation_id · execution_id (UUIDs)
  ├─ source {email, portal}
  ├─ subject · body · priority · received_at
  ├─ attachments (intake.email_attachments / portal_query_attachments)
  └─ thread refs (in_reply_to, references[], conversation_id)
       │
       ▼
workflow.case_execution    (the lifecycle row)
  ├─ status {RECEIVED, ANALYZING, ROUTING, DRAFTING, VALIDATING,
  │          DELIVERING, RESOLVED, AWAITING_RESOLUTION,
  │          PAUSED, REOPENED, CLOSED, FAILED, MERGED_INTO_PARENT}
  ├─ processing_path {A, B, C, null}
  ├─ analysis_result (JSONB)
  ├─ vendor_id · linked_query_id (for reopen-out-of-window)
       │
       ├─► workflow.routing_decisions (assigned_team, sla_target_hours, sla_deadline)
       ├─► workflow.draft_responses (draft_type RESOLUTION|ACKNOWLEDGMENT, body_html, sources, confidence)
       ├─► workflow.quality_gate_results (passed, failed_checks[])
       ├─► workflow.ticket_link (query_id ↔ ServiceNow INC-XXXXXXX)
       ├─► workflow.sla_checkpoints (warning_fired, l1_fired, l2_fired)
       ├─► workflow.closure_tracking (auto_close_deadline)
       ├─► workflow.triage_packages (Path C, callback_token, package_data)
       └─► workflow.reviewer_decisions (corrected_intent, corrected_vendor_id, override)

memory.embedding_index           — KB articles (12 seeded), vector(1536) via Titan Embed v2
memory.episodic_memory           — every closed case writes one row (vendor_id, intent, path, outcome, summary)

audit.action_log                 — actor, action, query_id (admin sends, reviewer decisions, …)
audit.execution_trail            — node-level pipeline trace
intake.admin_outbound_emails     — admin compose/reply tracking (QUEUED → SENT/FAILED)
intake.admin_outbound_attachments
reporting.sla_metrics            — wide analytics row per case
cache.vendor_cache               — Salesforce profile cache (1h TTL, has dedicated vendor_name/tier/category cols)
cache.kv_store                   — JWT blacklist + general short-TTL k/v
                                  (No user/role tables — auth is stateless JWT; roles ADMIN / REVIEWER / VENDOR are encoded in token claims via `src/api/middleware/auth_middleware.py`.)
```

---

## 4. API Endpoints (grouped by domain)

### Authentication — `src/api/routes/auth.py`
- `POST /auth/login` → `{token, user_name, email, role, tenant, vendor_id}`
- `POST /auth/logout` → blacklist JTI in `cache.kv_store`

### Portal Queries — `src/api/routes/queries.py`
- `GET /queries` (Bearer + X‑Vendor‑ID) — vendor's own queries, newest first
- `POST /queries` — submit; SHA‑256 idempotency on `(vendor_id, subject, description)`
- `GET /queries/{query_id}` — detail (vendor scope‑checked)

### Portal Dashboard — `src/api/routes/portal_dashboard.py`
- `GET /dashboard/kpis` — open / resolved / avg resolution hours / total

### Admin Dashboard / Emails — `src/api/routes/dashboard.py`
- `GET /emails?status=&priority=&search=&sort=&page=&page_size=` — paginated chains
- `GET /emails/stats` — totals + by status + by priority + today + week
- `GET /emails/{query_id}` — single chain incl. attachments (presigned URLs)
- `GET /emails/{query_id}/attachments/{attachment_id}/download` — refresh presigned URL

### Vendor Management (ADMIN) — `src/api/routes/vendors.py`
- `GET /vendors` — list active (V‑001 first)
- `POST /vendors` — create (auto V‑XXX)
- `PUT /vendors/{vendor_id}` — update (returns full record)
- `DELETE /vendors/{vendor_id}` — permanent delete

### Admin Email Send — `src/api/routes/admin_email.py`
- `POST /admin/email/send` (multipart) — fresh email to one or more vendors; X‑Request‑Id dedupes
- `POST /admin/email/queries/{query_id}/reply` (multipart) — reply on existing trail (preserves conversationId)

### Admin Drafts — `src/api/routes/admin_drafts.py`
- Draft list / approve / edit / reject endpoints

### Admin Queries — `src/api/routes/admin_queries.py`
- All‑queries view + filters across vendors

### Triage / Path C (REVIEWER, ADMIN) — `src/api/routes/triage.py`
- `GET /triage/queue?limit=` — pending packages, oldest first (limit clamped 1–200)
- `GET /triage/{query_id}` — full TriagePackage
- `POST /triage/{query_id}/review` — `{corrected_intent?, corrected_vendor_id?, corrected_routing?, confidence_override?, reviewer_notes}` → `{status, query_id, resume_method: "sqs"|"db_only"}`

### Copilot Triage — `src/api/routes/copilot_triage.py`
- SSE stream of reviewer copilot tool calls (suggest intent / similar past cases)

### System & Webhooks — `src/api/routes/webhooks.py`
- `GET /health`
- `POST /webhooks/ms-graph` (HMAC) — Microsoft Graph email notifications
- `POST /webhooks/servicenow` (HMAC) — `{ticket_id, status, correlation_id?}`; `RESOLVED` re‑enqueues with `resume_context.action="prepare_resolution"` → triggers Step 15 (resolution drafted from work notes)

---

## 5. Three Routing Paths

| Path | Trigger | LLM Calls | Outcome | Human in loop |
|---|---|---|---|---|
| **A — AI‑Resolved** | confidence ≥ 0.85 **AND** KB cosine ≥ 0.80 with substantive content | 2 (analysis + resolution) | Full answer drafted from KB articles, ticket created for monitoring, status `RESOLVED` | No (Quality Gate enforces) |
| **B — Human Team** | confidence ≥ 0.85 **AND** KB miss / weak match | 2 initial + 1 resolution‑from‑notes (Step 15) | Acknowledgment with INC# + SLA, team investigates in ServiceNow, work notes → AI drafts resolution → vendor | Yes (investigation) |
| **C — Low‑Confidence Triage** | confidence < 0.85 | 2–3 | Workflow PAUSED, TriagePackage persisted, reviewer corrects, SQS re‑enqueue with `resume_context.from_triage=True`, naturally flows to A or B | Yes (review) |

Quality Gate (Step 11) — 7 deterministic checks, max 2 redrafts before human escalation.

---

## 6. LangGraph State Machine

```
START
 └─► entry (route_from_entry)
     ├─ resume_context.action == "prepare_resolution" ──► resolution_from_notes ──► quality_gate ──► delivery ──► END
     └─ else ──► context_loading ──► query_analysis ──► confidence_check
                                                          ├─ path C ──► triage ──► END (PAUSED)
                                                          └─ else ──► routing ──► kb_search ──► path_decision
                                                                                                    ├─ A ──► resolution ──► quality_gate ──► delivery ──► END
                                                                                                    └─ B ──► acknowledgment ──► quality_gate ──► delivery ──► END
```

State carrier: `PipelineState` TypedDict (workflow.py) — query_id, correlation_id, execution_id, source, unified_payload, vendor_context, analysis_result, routing_decision, kb_search_result, processing_path, draft_response, quality_gate_result, ticket_info, triage_package, resume_context, status, error.

---

## 7. Integrations Summary

| System | Adapter | What it's used for |
|---|---|---|
| Amazon Bedrock | `adapters/bedrock.py` (+ `llm_gateway.py`) | Claude Sonnet 3.5 inference · Titan Embed v2 (1536‑dim) |
| OpenAI | `adapters/openai_llm.py` | GPT‑4o + text‑embedding‑3‑small (fallback) |
| Microsoft Graph API | `adapters/graph_api/*` | Webhook subscription · fetch email · send email · large attachments |
| Salesforce CRM | `adapters/salesforce/*` | Vendor identification (3‑step) · vendor CRUD · category lookup |
| ServiceNow ITSM | `adapters/servicenow/*` | `create_ticket` (incident) · `update_ticket_status` · `get_work_notes` · `resolve_user_display_name` · `resolve_group_name` |
| Amazon RDS for PostgreSQL | `db/connection/*` | SSH‑tunneled asyncpg pool · pgvector · idempotency · cache |
| Amazon S3 | `storage/s3_client.py` | Single bucket `vqms-data-store` (inbound‑emails, attachments, processed, templates, archive) |
| Amazon SQS | `queues/sqs.py` | `vqms-email-intake-queue` · `vqms-query-intake-queue` · DLQ |
| Amazon EventBridge | `events/eventbridge.py` | 20 event types — pipeline lifecycle + SLA + closure |
| Amazon Textract | `adapters/textract.py` | Image / scanned‑PDF OCR |

---

## 8. Current State vs. Planned

| Phase | Status |
|---|---|
| 1. Foundation (models, DB, connectors, config) | ✅ Done |
| 2. Intake (email + portal) | ✅ Done |
| 3. AI Pipeline (LangGraph + nodes 7–9) | ✅ Done |
| 4. Drafting + QG + Delivery (10A/10B, 11, 12) | ✅ Done |
| 5. Path C triage (persist + pause + reviewer API + SQS resume) | ✅ Done |
| 6. SLA monitor · resolution‑from‑notes (Step 15) · closure · episodic memory | ✅ Done |
| 7. Frontend portal | 🟡 Angular skeleton present, no design system applied |
| 8. Hardening / production readiness | ⏳ Planned |
