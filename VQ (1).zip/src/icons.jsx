// Lucide icon wrappers — render as inline React components reading from window.lucide
const I = ({ name, size = 16, className = "", strokeWidth = 1.6, style }) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.lucide) return;
    ref.current.innerHTML = "";
    const icons = window.lucide.icons;
    const def = icons && icons[toPascal(name)];
    if (!def) return;
    const svg = window.lucide.createElement(def);
    svg.setAttribute("width", size);
    svg.setAttribute("height", size);
    svg.setAttribute("stroke-width", strokeWidth);
    svg.setAttribute("class", className);
    if (style) Object.assign(svg.style, style);
    ref.current.appendChild(svg);
  }, [name, size, className, strokeWidth, style]);
  return <span ref={ref} className="inline-flex items-center" style={{ lineHeight: 0 }} />;
};
function toPascal(name) {
  return name.split("-").map(s => s[0].toUpperCase() + s.slice(1)).join("");
}
window.I = I;
