// Query Inbox screen with filters

const Inbox = ({ onOpen }) => {
  const { caps, role } = window.useRole();
  const ep = window.useEndpoints();
  const [filters, setFilters] = React.useState({
    status: "ALL",
    path: "ALL",
    vendor: "ALL",
    minConf: 0,
    search: "",
    priority: "ALL",
  });
  const [selected, setSelected] = React.useState(new Set());
  const [sortBy, setSortBy] = React.useState({ key: "received_at", dir: "desc" });

  const filtered = React.useMemo(() => {
    let list = window.QUERIES.filter(q => {
      if (filters.status !== "ALL" && q.status !== filters.status) return false;
      if (filters.path !== "ALL" && q.processing_path !== filters.path) return false;
      if (filters.vendor !== "ALL" && q.vendor_id !== filters.vendor) return false;
      if (filters.priority !== "ALL" && q.priority !== filters.priority) return false;
      if (q.confidence < filters.minConf) return false;
      if (filters.search) {
        const s = filters.search.toLowerCase();
        if (!q.query_id.toLowerCase().includes(s) && !q.subject.toLowerCase().includes(s) && !q.vendor_name.toLowerCase().includes(s)) return false;
      }
      return true;
    });
    list.sort((a, b) => {
      const av = a[sortBy.key], bv = b[sortBy.key];
      const cmp = av > bv ? 1 : av < bv ? -1 : 0;
      return sortBy.dir === "asc" ? cmp : -cmp;
    });
    return list;
  }, [filters, sortBy]);

  const toggle = (id) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };
  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map(q => q.query_id)));
  };

  const sortLink = (key, label) => (
    <button className="inline-flex items-center gap-1 hover:text-[color:var(--ink)]"
      onClick={() => setSortBy(s => ({ key, dir: s.key === key && s.dir === "desc" ? "asc" : "desc" }))}>
      {label}
      {sortBy.key === key && <I name={sortBy.dir === "asc" ? "chevron-up" : "chevron-down"} size={11}/>}
    </button>
  );

  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Query inbox</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>
            <Mono>{filtered.length}</Mono> of <Mono>{window.QUERIES.length}</Mono> queries
            {selected.size > 0 && <> · <Mono style={{ color: "var(--accent)" }}>{selected.size} selected</Mono></>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {selected.size > 0 && (
            <>
              {caps.approve && <button className="btn"><I name="user-check" size={13}/> Approve drafts</button>}
              {caps.reroute && <button className="btn"><I name="route" size={13}/> Reroute</button>}
              {caps.escalate && <button className="btn"><I name="alert-triangle" size={13}/> Escalate</button>}
              <div style={{ width: 1, height: 22, background: "var(--line)" }}/>
            </>
          )}
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="download" size={13}/> Export CSV</button>
          {caps.editVendor && <button className="btn btn-primary"><I name="plus" size={13}/> New query</button>}
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Query inbox · backend contract"
        subtitle="src/api/routes/queries.py · all routes role-gated"
        endpoints={window.ENDPOINTS_INBOX}
        role={role}
      />

      {/* Filter bar */}
      <div className="panel p-3 flex items-center gap-2 flex-wrap mb-3" style={{ borderRadius: 4 }}>
        <div className="relative flex-1 min-w-[260px]">
          <I name="search" size={14} className="muted" style={{ position: "absolute", left: 10, top: "50%", transform: "translateY(-50%)" }}/>
          <input className="w-full" style={{ paddingLeft: 32 }} placeholder="Search VQ‑id, subject, vendor…"
            value={filters.search} onChange={e => setFilters({...filters, search: e.target.value})}/>
        </div>
        <FSelect label="Status" value={filters.status} onChange={v => setFilters({...filters, status: v})}
          options={["ALL","RESOLVED","DELIVERING","DRAFTING","ROUTING","ANALYZING","AWAITING_RESOLUTION","PAUSED","REOPENED","FAILED"]}/>
        <FSelect label="Path" value={filters.path} onChange={v => setFilters({...filters, path: v})}
          options={["ALL","A","B","C"]} format={v => v === "ALL" ? "All paths" : `Path ${v}`}/>
        <FSelect label="Vendor" value={filters.vendor} onChange={v => setFilters({...filters, vendor: v})}
          options={["ALL", ...window.VENDORS.map(v => v.vendor_id)]}
          format={v => v === "ALL" ? "All vendors" : window.VENDORS.find(x => x.vendor_id === v)?.name }/>
        <FSelect label="Priority" value={filters.priority} onChange={v => setFilters({...filters, priority: v})}
          options={["ALL","P1","P2","P3"]}/>
        <div className="flex items-center gap-2 px-2 py-1.5">
          <span className="muted text-[11px] uppercase tracking-wider">Min conf</span>
          <input type="range" min={0} max={1} step={0.05} value={filters.minConf}
            onChange={e => setFilters({...filters, minConf: Number(e.target.value)})}
            style={{ width: 90, padding: 0, accentColor: "var(--accent)" }}/>
          <Mono style={{ width: 28 }}>{filters.minConf.toFixed(2)}</Mono>
        </div>
      </div>

      {/* Table */}
      <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
        <table className="vqms-table">
          <thead>
            <tr>
              <th style={{ width: 32 }}>
                <input type="checkbox" checked={selected.size === filtered.length && filtered.length > 0}
                  onChange={toggleAll} style={{ accentColor: "var(--accent)" }}/>
              </th>
              <th>{sortLink("query_id", "Query")}</th>
              <th>{sortLink("vendor_name", "Vendor")}</th>
              <th>Subject / Intent</th>
              <th>{sortLink("processing_path", "Path")}</th>
              <th>{sortLink("status", "Status")}</th>
              <th>{sortLink("confidence", "Conf.")}</th>
              <th>SLA</th>
              <th>Team / Ticket</th>
              <th style={{ textAlign: "right" }}>{sortLink("received_at", "Received")}</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={10}><Empty title="No queries match" desc="Try clearing a filter or expanding the date window."/></td></tr>
            )}
            {filtered.map(q => (
              <tr key={q.query_id} className={selected.has(q.query_id) ? "selected" : ""} onClick={() => onOpen(q)}>
                <td onClick={(e) => { e.stopPropagation(); toggle(q.query_id); }}>
                  <input type="checkbox" checked={selected.has(q.query_id)} onChange={() => {}}
                    style={{ accentColor: "var(--accent)" }}/>
                </td>
                <td>
                  <div className="flex items-center gap-2">
                    <Priority p={q.priority}/>
                    <Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{q.query_id}</Mono>
                    {q.reopened && <span className="chip" style={{ fontSize: 9.5, padding: "1px 5px" }}>REOPENED</span>}
                  </div>
                  <Mono className="muted" style={{ fontSize: 10.5 }}>{q.source} · {q.attachments > 0 ? `${q.attachments} att.` : "no att."}</Mono>
                </td>
                <td>
                  <div className="ink-2" style={{ fontSize: 12.5 }}>{q.vendor_name}</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <Tier tier={q.vendor_tier}/>
                    <Mono className="muted" style={{ fontSize: 10.5 }}>{q.vendor_id}</Mono>
                  </div>
                </td>
                <td>
                  <div className="ink-2 truncate" style={{ fontSize: 12.5, maxWidth: 320 }}>{q.subject}</div>
                  <div className="muted mt-0.5" style={{ fontSize: 11 }}>{q.intent}</div>
                </td>
                <td><PathBadge p={q.processing_path} size="sm"/></td>
                <td><Status s={q.status}/></td>
                <td><ConfidenceBar value={q.confidence}/></td>
                <td><SLABar pct={q.sla_pct}/></td>
                <td>
                  <div className="ink-2" style={{ fontSize: 12 }}>{q.assigned_team}</div>
                  {q.ticket_id && <Mono className="muted" style={{ fontSize: 10.5 }}>{q.ticket_id}</Mono>}
                </td>
                <td style={{ textAlign: "right" }}>
                  <Mono className="muted">{relative(q.received_at)}</Mono>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex items-center justify-between p-3 border-t hairline">
          <div className="muted" style={{ fontSize: 12 }}>Showing 1–{filtered.length} of {filtered.length}</div>
          <div className="flex items-center gap-1">
            <button className="btn btn-ghost" disabled><I name="chevron-left" size={13}/></button>
            <Mono className="px-2">1 / 1</Mono>
            <button className="btn btn-ghost" disabled><I name="chevron-right" size={13}/></button>
          </div>
        </div>
      </div>
    </div>
  );
};

const FSelect = ({ label, value, onChange, options, format }) => (
  <div className="inline-flex items-center" style={{ borderRadius: 4 }}>
    <span className="muted text-[10.5px] uppercase tracking-wider mr-2">{label}</span>
    <select value={value} onChange={e => onChange(e.target.value)} style={{ minWidth: 110, fontSize: 12.5 }}>
      {options.map(o => <option key={o} value={o}>{format ? format(o) : o}</option>)}
    </select>
  </div>
);

Object.assign(window, { Inbox });
