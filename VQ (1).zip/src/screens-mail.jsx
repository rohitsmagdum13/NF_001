// Email Management — three-pane unified inbox for VQMS admins
// Field shape mirrors intake.email_messages, intake.admin_outbound_emails,
// workflow.draft_responses, audit.action_log. UI-only fields are prefixed with `_`.

const fmtTime = (iso) => {
  const d = new Date(iso);
  const now = new Date("2026-04-28T14:23:00Z");
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) return d.toUTCString().slice(17, 22);
  const sameYear = d.getUTCFullYear() === now.getUTCFullYear();
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric", ...(sameYear ? {} : { year: "numeric" }) });
};
const fmtBytes = (b) => b > 1_000_000 ? `${(b/1_000_000).toFixed(1)} MB` : `${Math.round(b/1000)} KB`;
const initials = (s) => s.split(" ").map(x => x[0]).slice(0,2).join("").toUpperCase();

// =========================================================
// Folder rail (left)
// =========================================================
const FolderRail = ({ folder, setFolder, filters, setFilters, counts }) => {
  return (
    <div className="flex flex-col flex-shrink-0" style={{ width: 200, borderRight: "1px solid var(--line)", background: "var(--panel)" }}>
      <div className="px-3 pt-3 pb-2">
        <button className="btn btn-accent w-full justify-center" style={{ padding: "7px 12px", fontSize: 12.5 }}
          onClick={() => window.dispatchEvent(new CustomEvent("vqms:compose"))}>
          <I name="pen-line" size={13}/> Compose
          <Mono className="ml-auto" style={{ color: "rgba(255,255,255,.7)", fontSize: 10 }}>C</Mono>
        </button>
      </div>

      <div className="px-2 pt-1 pb-2">
        {window.MAIL_FOLDERS.map(f => {
          const c = counts[f.id] || 0;
          const active = folder === f.id;
          return (
            <div key={f.id} className={"nav-item " + (active ? "active" : "")} onClick={() => setFolder(f.id)}>
              <I name={f.icon} size={13}/>
              <span className="flex-1">{f.label}</span>
              {c > 0 && (
                <Mono style={{ fontSize: 10.5, padding: "1px 6px",
                              background: active ? "var(--accent)" : "var(--line)",
                              color: active ? "white" : "var(--muted)",
                              borderRadius: 999 }}>{c}</Mono>
              )}
            </div>
          );
        })}
      </div>

      <div className="border-t hairline mx-2"/>

      <div className="p-3 space-y-2.5 overflow-y-auto">
        <div className="muted uppercase tracking-wider" style={{ fontSize: 10, fontWeight: 600 }}>Filters</div>

        <RailFilter label="Vendor">
          <select value={filters.vendor} onChange={e => setFilters({ ...filters, vendor: e.target.value })} style={{ width: "100%", fontSize: 12 }}>
            <option value="ALL">All vendors</option>
            {window.VENDORS.map(v => <option key={v.vendor_id} value={v.vendor_id}>{v.vendor_id} · {v.name}</option>)}
          </select>
        </RailFilter>

        <RailFilter label="Path">
          <div className="flex gap-1">
            {["ALL","A","B","C"].map(p => (
              <button key={p}
                className="btn"
                style={{
                  flex: 1, padding: "4px 6px", fontSize: 11,
                  background: filters.path === p ? "var(--accent-soft)" : "var(--panel)",
                  color: filters.path === p ? "var(--accent)" : "var(--ink-2)",
                  borderColor: filters.path === p ? "var(--accent)" : "var(--line-strong)",
                }}
                onClick={() => setFilters({ ...filters, path: p })}>
                {p === "ALL" ? "All" : p}
              </button>
            ))}
          </div>
        </RailFilter>

        <RailFilter label="Confidence">
          <div className="flex gap-1">
            {[
              { id: "ALL",  label: "All" },
              { id: "HIGH", label: "High",  hint: "≥ 0.85" },
              { id: "MED",  label: "Med",   hint: "0.6–0.85" },
              { id: "LOW",  label: "Low",   hint: "< 0.6" },
            ].map(c => (
              <button key={c.id} title={c.hint}
                className="btn"
                style={{
                  flex: 1, padding: "4px 6px", fontSize: 11,
                  background: filters.conf === c.id ? "var(--accent-soft)" : "var(--panel)",
                  color: filters.conf === c.id ? "var(--accent)" : "var(--ink-2)",
                  borderColor: filters.conf === c.id ? "var(--accent)" : "var(--line-strong)",
                }}
                onClick={() => setFilters({ ...filters, conf: c.id })}>
                {c.label}
              </button>
            ))}
          </div>
        </RailFilter>

        <RailFilter label="Date">
          <select value={filters.date} onChange={e => setFilters({ ...filters, date: e.target.value })} style={{ width: "100%", fontSize: 12 }}>
            <option value="ALL">Any time</option>
            <option value="24H">Last 24 hours</option>
            <option value="7D">Last 7 days</option>
            <option value="30D">Last 30 days</option>
          </select>
        </RailFilter>

        <RailFilter label="SLA status">
          <div className="flex gap-1">
            {[
              { id: "ALL", label: "All" },
              { id: "OK",  label: "On‑track", color: "var(--ok)" },
              { id: "RISK",label: "At‑risk",  color: "var(--warn)" },
              { id: "BAD", label: "Breached", color: "var(--bad)" },
            ].map(s => (
              <button key={s.id}
                className="btn"
                style={{
                  flex: 1, padding: "4px 4px", fontSize: 10.5,
                  background: filters.sla === s.id ? "var(--accent-soft)" : "var(--panel)",
                  color: filters.sla === s.id ? "var(--accent)" : (s.color || "var(--ink-2)"),
                  borderColor: filters.sla === s.id ? "var(--accent)" : "var(--line-strong)",
                }}
                onClick={() => setFilters({ ...filters, sla: s.id })}>
                {s.label}
              </button>
            ))}
          </div>
        </RailFilter>

        <label className="flex items-center gap-2 mt-1" style={{ fontSize: 12, color: "var(--ink-2)" }}>
          <input type="checkbox" checked={filters.has_attach} onChange={e => setFilters({ ...filters, has_attach: e.target.checked })}
            style={{ accentColor: "var(--accent)" }}/>
          <I name="paperclip" size={11} className="muted"/>
          Has attachment
        </label>
      </div>
    </div>
  );
};
const RailFilter = ({ label, children }) => (
  <div>
    <div className="muted uppercase tracking-wider mb-1" style={{ fontSize: 9.5, fontWeight: 500 }}>{label}</div>
    {children}
  </div>
);

// =========================================================
// Middle pane — list
// =========================================================
const MailList = ({ rows, selectedId, onSelect, bulk, setBulk, search, setSearch, sort, setSort, folder }) => {
  const allChecked = bulk.size > 0 && bulk.size === rows.length;
  const toggleAll = () => {
    if (allChecked) setBulk(new Set());
    else setBulk(new Set(rows.map(r => r.message_id)));
  };
  const toggle = (id, e) => {
    e.stopPropagation();
    const next = new Set(bulk);
    next.has(id) ? next.delete(id) : next.add(id);
    setBulk(next);
  };

  return (
    <div className="flex flex-col flex-shrink-0" style={{ width: 360, borderRight: "1px solid var(--line)", background: "var(--panel)" }}>
      {/* Top bar */}
      <div className="px-3 py-2.5 border-b hairline">
        <div className="flex items-center gap-2">
          <input type="checkbox" checked={allChecked} onChange={toggleAll} style={{ accentColor: "var(--accent)" }}/>
          <div className="relative flex-1">
            <I name="search" size={12} className="muted" style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)" }}/>
            <input className="w-full" style={{ paddingLeft: 28, fontSize: 12.5 }} placeholder="Search mail…"
              value={search} onChange={e => setSearch(e.target.value)}/>
            <Mono className="muted" style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", fontSize: 10 }}>/</Mono>
          </div>
          <select value={sort} onChange={e => setSort(e.target.value)} style={{ fontSize: 11.5, padding: "5px 6px" }}>
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
            <option value="priority">Priority</option>
            <option value="confidence">Confidence</option>
          </select>
        </div>

        {/* Bulk actions */}
        {bulk.size > 0 && (
          <div className="flex items-center gap-1.5 mt-2 fade-up">
            <Mono className="text-accent" style={{ fontSize: 11, fontWeight: 600 }}>{bulk.size} selected</Mono>
            <div className="flex-1"/>
            <button className="btn" style={{ padding: "3px 8px", fontSize: 11 }}><I name="mail-open" size={11}/> Mark read</button>
            <button className="btn" style={{ padding: "3px 8px", fontSize: 11 }}><I name="archive" size={11}/> Archive</button>
            <button className="btn" style={{ padding: "3px 8px", fontSize: 11 }}><I name="link" size={11}/> Link query</button>
            <button className="btn" style={{ padding: "3px 8px", fontSize: 11 }} onClick={() => setBulk(new Set())}><I name="x" size={11}/></button>
          </div>
        )}

        <div className="flex items-center justify-between mt-2">
          <div className="muted" style={{ fontSize: 11 }}>
            <Mono>{rows.length}</Mono> message{rows.length === 1 ? "" : "s"} · {window.MAIL_FOLDERS.find(f => f.id === folder)?.label}
          </div>
          <div className="flex items-center gap-2 muted" style={{ fontSize: 10.5 }}>
            <Mono>J</Mono><span>/</span><Mono>K</Mono>
            <span>navigate</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {rows.length === 0 && <Empty title="No messages" desc="Nothing matches the current folder + filters." icon="mail"/>}
        {rows.map(r => (
          <MailRow key={r.message_id} row={r} selected={selectedId === r.message_id}
            checked={bulk.has(r.message_id)}
            onCheck={(e) => toggle(r.message_id, e)}
            onClick={() => onSelect(r.message_id)}/>
        ))}
      </div>
    </div>
  );
};

const MailRow = ({ row, selected, checked, onCheck, onClick }) => {
  const unread = row._status === "unread";
  const isOutbound = row._direction === "outbound";
  const conf = row.confidence_score;
  const confColor = conf >= 0.85 ? "var(--ok)" : conf >= 0.6 ? "var(--warn)" : "var(--bad)";
  const slaPct = row._sla_pct;
  const slaColor = slaPct == null ? null : slaPct >= 95 ? "var(--bad)" : slaPct >= 70 ? "var(--warn)" : "var(--ok)";

  return (
    <div onClick={onClick}
      className="px-3 py-2.5 cursor-pointer fade-up"
      style={{
        borderBottom: "1px solid var(--line)",
        background: selected ? "var(--accent-soft)" : "transparent",
        borderLeft: selected ? "2px solid var(--accent)" : "2px solid transparent",
      }}>
      <div className="flex items-start gap-2">
        <input type="checkbox" checked={checked} onChange={() => {}} onClick={onCheck}
          style={{ accentColor: "var(--accent)", marginTop: 4 }}/>
        <div style={{ width: 6, marginTop: 7, flexShrink: 0 }}>
          {unread && <span style={{ display: "block", width: 6, height: 6, borderRadius: 999, background: "var(--accent)" }}/>}
        </div>
        <div className="flex-1 min-w-0">
          {/* line 1: sender + time */}
          <div className="flex items-center gap-2">
            <span className="ink truncate" style={{ fontSize: 13, fontWeight: unread ? 600 : 500, flex: 1, minWidth: 0 }}>
              {isOutbound ? <><I name="corner-up-right" size={11} className="muted"/> {row.from_name || "You"}</> : row.from_name}
            </span>
            <Mono className="muted" style={{ fontSize: 10.5, flexShrink: 0 }}>{fmtTime(row.received_at)}</Mono>
          </div>

          {/* line 2: vendor + tier */}
          <div className="flex items-center gap-1.5 mt-0.5">
            <Mono className="muted" style={{ fontSize: 10 }}>{row.vendor_id}</Mono>
            <span className="muted" style={{ fontSize: 10 }}>·</span>
            <span className="muted truncate" style={{ fontSize: 11 }}>{row.vendor_name}</span>
            {row._flagged && <I name="flag" size={10} style={{ color: "var(--accent)" }}/>}
          </div>

          {/* line 3: subject */}
          <div className="ink-2 truncate mt-1" style={{ fontSize: 12.5, fontWeight: unread ? 500 : 400 }}>
            {row.subject}
          </div>

          {/* line 4: snippet */}
          <div className="muted truncate mt-0.5" style={{ fontSize: 11.5 }}>
            {(row.body_text || "").split("\n").join(" ").slice(0, 88)}…
          </div>

          {/* line 5: chips */}
          <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
            <PathBadge p={row.processing_path} size="sm"/>
            <span className="chip" style={{ padding: "1px 5px", fontSize: 10, color: confColor, borderColor: "var(--line)" }}>
              <span style={{ width: 4, height: 4, borderRadius: 999, background: confColor, display: "inline-block", marginRight: 4 }}/>
              <Mono style={{ fontSize: 10 }}>{conf.toFixed(2)}</Mono>
            </span>
            {row._has_ai_draft && row._direction === "inbound" && (
              <span className="chip" style={{ padding: "1px 5px", fontSize: 10, color: "var(--accent)", borderColor: "var(--accent)", background: "var(--accent-soft)" }}>
                <I name="sparkles" size={9}/> AI draft
              </span>
            )}
            {row.attachments.length > 0 && (
              <span className="muted inline-flex items-center" style={{ fontSize: 10.5 }}>
                <I name="paperclip" size={10}/> <Mono style={{ fontSize: 10, marginLeft: 2 }}>{row.attachments.length}</Mono>
              </span>
            )}
            {slaPct != null && (
              <span className="muted inline-flex items-center gap-1" style={{ fontSize: 10.5 }}>
                <span style={{ width: 24, height: 3, background: "var(--line)", borderRadius: 2, overflow: "hidden", display: "inline-block" }}>
                  <span style={{ display: "block", height: "100%", width: `${slaPct}%`, background: slaColor }}/>
                </span>
                <Mono style={{ fontSize: 10, color: slaColor }}>{slaPct}%</Mono>
              </span>
            )}
            <span className="flex-1"/>
            <Mono className="muted" style={{ fontSize: 10 }}>{row.query_id}</Mono>
          </div>
        </div>
      </div>
    </div>
  );
};

// =========================================================
// Right pane — detail + reply
// =========================================================
const MailDetail = ({ row, onUpdate }) => {
  const [showCompose, setShowCompose] = React.useState(false);
  const [replyMode, setReplyMode] = React.useState("Reply");
  const [showAudit, setShowAudit] = React.useState(false);

  if (!row) {
    return (
      <div className="flex-1 flex items-center justify-center bg-bg">
        <div className="text-center fade-up">
          <div style={{ width: 56, height: 56, borderRadius: 999, background: "var(--panel)", border: "1px solid var(--line)",
                        display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
            <I name="mail" size={20} className="subtle"/>
          </div>
          <div className="ink" style={{ fontSize: 14, fontWeight: 500 }}>Select a message</div>
          <div className="muted mt-1" style={{ fontSize: 12 }}>Pick anything from the list to read the full thread.</div>
          <div className="muted mt-4" style={{ fontSize: 11 }}>
            <Mono>J</Mono>/<Mono>K</Mono> navigate · <Mono>R</Mono> reply · <Mono>E</Mono> archive · <Mono>C</Mono> compose
          </div>
        </div>
      </div>
    );
  }

  const ai = window.MAIL_AI_DRAFTS[row.message_id];
  const history = window.MAIL_THREAD_HISTORY[row.conversation_id] || [];
  const audit = window.MAIL_AUDIT[row.message_id] || [];
  const notes = window.MAIL_INTERNAL_NOTES[row.message_id] || [];
  const vendor = window.VENDORS.find(v => v.vendor_id === row.vendor_id);

  const startReply = (mode) => { setReplyMode(mode); setShowCompose(true); };

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Center: thread + reply */}
      <div className="flex-1 overflow-y-auto bg-bg">
        {/* Header */}
        <div className="bg-panel border-b hairline px-6 py-4">
          <div className="flex items-start gap-3">
            <div className="flex-1 min-w-0">
              <div className="ink" style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-.01em", lineHeight: 1.3 }}>
                {row.subject}
              </div>
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                <PathBadge p={row.processing_path}/>
                {row.ticket_id && (
                  <a className="chip" href="#" style={{ color: "var(--info)", borderColor: "var(--line)" }}>
                    <I name="ticket" size={10}/> <Mono style={{ fontSize: 10.5 }}>{row.ticket_id}</Mono>
                  </a>
                )}
                <a className="chip" href="#" style={{ color: "var(--accent)", borderColor: "var(--line)" }}>
                  <I name="link" size={10}/> <Mono style={{ fontSize: 10.5 }}>{row.query_id}</Mono>
                </a>
                <button className="chip" onClick={() => onUpdate("create_query")}>
                  <I name="plus" size={10}/> Create query
                </button>
                <span className="flex-1"/>
                <button className="btn btn-ghost" title="Flag" onClick={() => onUpdate("flag")}>
                  <I name="flag" size={13} style={{ color: row._flagged ? "var(--accent)" : "var(--muted)" }}/>
                </button>
                <button className="btn btn-ghost" title="Print"><I name="printer" size={13}/></button>
                <button className="btn btn-ghost" title="More"><I name="more-horizontal" size={13}/></button>
              </div>
            </div>
          </div>

          {/* From/To grid */}
          <div className="grid grid-cols-[80px_1fr] gap-y-1 gap-x-3 mt-4" style={{ fontSize: 12 }}>
            <div className="muted">From</div>
            <div className="flex items-center gap-2">
              <Avatar name={row.from_name} size={20}/>
              <span className="ink" style={{ fontWeight: 500 }}>{row.from_name}</span>
              <Mono className="muted" style={{ fontSize: 11 }}>&lt;{row.from_address}&gt;</Mono>
            </div>
            <div className="muted">To</div>
            <Mono className="ink-2" style={{ fontSize: 11.5 }}>{row.to_addresses.join(", ")}</Mono>
            {row.cc_addresses.length > 0 && <>
              <div className="muted">Cc</div>
              <Mono className="ink-2" style={{ fontSize: 11.5 }}>{row.cc_addresses.join(", ")}</Mono>
            </>}
            <div className="muted">Date</div>
            <Mono className="ink-2" style={{ fontSize: 11.5 }}>{new Date(row.received_at).toUTCString()}</Mono>
            <div className="muted">Message‑Id</div>
            <Mono className="muted" style={{ fontSize: 10.5 }}>{row.message_id}</Mono>
          </div>

          {/* Action toolbar */}
          <div className="flex items-center gap-1.5 mt-4 flex-wrap">
            <button className="btn btn-primary" onClick={() => startReply("Reply")}>
              <I name="reply" size={13}/> Reply <Mono style={{ color: "rgba(255,255,255,.6)", fontSize: 10, marginLeft: 4 }}>R</Mono>
            </button>
            <button className="btn" onClick={() => startReply("Reply all")}>
              <I name="reply-all" size={13}/> Reply all
            </button>
            <button className="btn" onClick={() => startReply("Forward")}>
              <I name="corner-up-right" size={13}/> Forward
            </button>
            <div style={{ width: 1, height: 22, background: "var(--line)", margin: "0 4px" }}/>
            <button className="btn"><I name="user-plus" size={13}/> Assign</button>
            <button className="btn"><I name="alert-triangle" size={13}/> Escalate</button>
            <button className="btn"><I name="check-circle-2" size={13}/> Mark resolved</button>
            <button className="btn" onClick={() => onUpdate("archive")}>
              <I name="archive" size={13}/> Archive <Mono style={{ color: "var(--muted)", fontSize: 10, marginLeft: 4 }}>E</Mono>
            </button>
            <span className="flex-1"/>
            <button className="btn btn-ghost" onClick={() => setShowAudit(s => !s)}>
              <I name="scroll-text" size={13}/> {showAudit ? "Hide" : "Show"} audit
            </button>
          </div>
        </div>

        {/* AI draft card — only inbound + has draft */}
        {ai && row._direction === "inbound" && (
          <AIDraftCard ai={ai} onUse={() => startReply("AI draft")}/>
        )}

        {/* Thread */}
        <div className="px-6 py-5">
          {history.filter(h => h.collapsed).length > 0 && (
            <details className="mb-3">
              <summary className="cursor-pointer muted" style={{ fontSize: 12 }}>
                <I name="history" size={11}/> {history.filter(h => h.collapsed).length} earlier message{history.filter(h => h.collapsed).length === 1 ? "" : "s"} in thread
              </summary>
              <div className="mt-2 space-y-2">
                {history.filter(h => h.collapsed).map((m, i) => (
                  <div key={i} className="panel px-3 py-2" style={{ borderRadius: 4 }}>
                    <div className="flex items-center gap-2">
                      <Avatar name={m.from_name} size={20}/>
                      <span className="ink-2" style={{ fontSize: 12, fontWeight: 500 }}>{m.from_name}</span>
                      <Mono className="muted" style={{ fontSize: 10.5 }}>{fmtTime(m.ts)}</Mono>
                    </div>
                    <div className="muted truncate mt-1" style={{ fontSize: 12 }}>{m.snippet}</div>
                  </div>
                ))}
              </div>
            </details>
          )}

          {/* Latest expanded */}
          <div className="panel" style={{ borderRadius: 4 }}>
            <div className="px-5 py-4">
              <pre className="ink-2" style={{ fontFamily: "inherit", whiteSpace: "pre-wrap", fontSize: 13, lineHeight: 1.65, margin: 0 }}>
{row.body_text}
              </pre>

              {row.attachments.length > 0 && (
                <div className="mt-4 pt-4 border-t hairline">
                  <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10, fontWeight: 600 }}>
                    {row.attachments.length} attachment{row.attachments.length === 1 ? "" : "s"}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {row.attachments.map(a => (
                      <div key={a.attachment_id} className="flex items-center gap-2 panel px-3 py-2 cursor-pointer"
                        style={{ borderRadius: 4, background: "var(--bg)" }}>
                        <I name={a.mime_type.includes("pdf") ? "file-text" : a.filename.endsWith(".xlsx") ? "file-spreadsheet" : "file"} size={14} className="muted"/>
                        <div>
                          <div className="ink-2" style={{ fontSize: 12, fontWeight: 500 }}>{a.filename}</div>
                          <Mono className="muted" style={{ fontSize: 10 }}>{fmtBytes(a.size_bytes)} · S3</Mono>
                        </div>
                        <button className="btn btn-ghost ml-2"><I name="download" size={12}/></button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Audit trail */}
          {showAudit && audit.length > 0 && (
            <div className="panel mt-4 fade-up" style={{ borderRadius: 4 }}>
              <div className="px-4 py-2.5 border-b hairline flex items-center gap-2">
                <I name="scroll-text" size={12} className="muted"/>
                <span className="ink-2" style={{ fontSize: 12, fontWeight: 500 }}>Audit trail</span>
                <Mono className="muted ml-auto" style={{ fontSize: 10 }}>audit.action_log</Mono>
              </div>
              <div className="px-4 py-3">
                {audit.map((a, i) => (
                  <div key={i} className="flex items-start gap-3 py-1.5" style={{ fontSize: 11.5 }}>
                    <Mono className="muted" style={{ fontSize: 10.5, minWidth: 130 }}>{a.ts}</Mono>
                    <Mono className="muted" style={{ fontSize: 10.5, minWidth: 150 }}>{a.actor}</Mono>
                    <span className="ink-2">{a.action}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Inline composer */}
        {showCompose && (
          <InlineComposer mode={replyMode} row={row} onClose={() => setShowCompose(false)}
            seedBody={replyMode === "AI draft" ? ai?.body_text : ""}/>
        )}
      </div>

      {/* Right panel: vendor card + internal notes */}
      <aside className="flex-shrink-0 hidden xl:block" style={{ width: 260, borderLeft: "1px solid var(--line)", background: "var(--panel)", overflowY: "auto" }}>
        <VendorCard vendor={vendor} row={row}/>
        <InternalNotes notes={notes} message_id={row.message_id}/>
      </aside>
    </div>
  );
};

// AI Draft card
const AIDraftCard = ({ ai, onUse }) => {
  const passed = ai.quality_gate?.passed;
  return (
    <div className="px-6 pt-5">
      <div className="panel fade-up" style={{
        borderRadius: 4,
        borderColor: passed ? "color-mix(in oklch, var(--accent) 35%, var(--line-strong))" : "var(--line-strong)",
        background: "linear-gradient(180deg, var(--accent-soft) 0%, var(--panel) 30%)",
      }}>
        <div className="px-5 py-3 border-b hairline flex items-center gap-3">
          <I name="sparkles" size={14} style={{ color: "var(--accent)" }}/>
          <span className="ink" style={{ fontSize: 12.5, fontWeight: 600 }}>AI‑suggested {ai.draft_type === "RESOLUTION" ? "resolution" : "acknowledgment"}</span>
          <Mono className="muted" style={{ fontSize: 10.5 }}>{ai.draft_id}</Mono>
          <span className="flex-1"/>
          <span className="chip" style={{
            color: ai.confidence >= 0.85 ? "var(--ok)" : ai.confidence >= 0.6 ? "var(--warn)" : "var(--bad)",
            fontWeight: 600,
          }}>
            confidence <Mono style={{ marginLeft: 4, fontSize: 11 }}>{ai.confidence.toFixed(2)}</Mono>
          </span>
          <span className="chip" style={{
            color: passed ? "var(--ok)" : "var(--bad)",
            background: passed ? "color-mix(in oklch, var(--ok) 10%, var(--panel))" : "color-mix(in oklch, var(--bad) 10%, var(--panel))",
          }}>
            <I name={passed ? "shield-check" : "shield-alert"} size={10}/>
            QG {ai.quality_gate.checks_passed}/{ai.quality_gate.checks_passed + ai.quality_gate.checks_failed}
          </span>
        </div>

        <div className="px-5 py-4">
          <pre className="ink-2" style={{ fontFamily: "inherit", whiteSpace: "pre-wrap", fontSize: 12.5, lineHeight: 1.6, margin: 0 }}>
{ai.body_text}
          </pre>

          {ai.sources?.length > 0 && (
            <div className="mt-3 pt-3 border-t hairline">
              <div className="muted uppercase tracking-wider mb-1.5" style={{ fontSize: 10, fontWeight: 600 }}>Sources</div>
              <div className="flex flex-wrap gap-1.5">
                {ai.sources.map(s => (
                  <span key={s.kb_id} className="chip" style={{ fontSize: 10.5 }}>
                    <Mono style={{ fontSize: 10 }}>{s.kb_id}</Mono> · {s.title} · cosine <Mono style={{ fontSize: 10 }}>{s.cosine}</Mono>
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="px-5 py-3 border-t hairline flex items-center gap-2">
          <button className="btn btn-accent" onClick={onUse}><I name="check" size={13}/> Use this</button>
          <button className="btn" onClick={onUse}><I name="edit-3" size={13}/> Edit</button>
          <button className="btn"><I name="refresh-cw" size={13}/> Regenerate</button>
          <button className="btn"><I name="x" size={13}/> Reject</button>
          <span className="flex-1"/>
          <Mono className="muted" style={{ fontSize: 10 }}>generated {fmtTime(ai.generated_at)} · Amazon Bedrock</Mono>
        </div>
      </div>
    </div>
  );
};

// Vendor card mini
const VendorCard = ({ vendor, row }) => {
  if (!vendor) return null;
  return (
    <div className="px-4 py-4 border-b hairline">
      <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 9.5, fontWeight: 600 }}>Vendor</div>
      <div className="flex items-start gap-3">
        <Avatar name={vendor.name} size={36}/>
        <div className="flex-1 min-w-0">
          <div className="ink" style={{ fontSize: 13, fontWeight: 600 }}>{vendor.name}</div>
          <Mono className="muted" style={{ fontSize: 10.5 }}>{vendor.vendor_id} · {vendor.website}</Mono>
          <div className="mt-1.5"><Tier tier={vendor.tier}/></div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mt-3" style={{ fontSize: 11 }}>
        <Stat label="Open" value={<Mono style={{ fontWeight: 600, color: "var(--ink)", fontSize: 13 }}>{vendor.open_queries}</Mono>}/>
        <Stat label="P1" value={<Mono style={{ fontWeight: 600, color: vendor.p1_open > 0 ? "var(--bad)" : "var(--ink)", fontSize: 13 }}>{vendor.p1_open}</Mono>}/>
        <Stat label="Health" value={<Mono style={{ fontWeight: 600, color: vendor.health > 85 ? "var(--ok)" : vendor.health > 70 ? "var(--warn)" : "var(--bad)", fontSize: 13 }}>{vendor.health}</Mono>}/>
        <Stat label="SLA" value={<Mono style={{ color: "var(--ink-2)", fontSize: 11.5 }}>{vendor.sla_response_hours}h/{vendor.sla_resolution_days}d</Mono>}/>
      </div>

      <div className="muted mt-3" style={{ fontSize: 11 }}>{vendor.category} · {vendor.city}, {vendor.country}</div>
      <button className="btn w-full justify-center mt-3" style={{ fontSize: 11.5 }}>
        <I name="external-link" size={11}/> Open Vendor 360
      </button>
    </div>
  );
};
const Stat = ({ label, value }) => (
  <div>
    <div className="muted uppercase tracking-wider" style={{ fontSize: 9, fontWeight: 600 }}>{label}</div>
    <div>{value}</div>
  </div>
);

// Internal notes
const InternalNotes = ({ notes, message_id }) => {
  const [draft, setDraft] = React.useState("");
  const [list, setList] = React.useState(notes);
  React.useEffect(() => setList(notes), [message_id]);
  const post = () => {
    if (!draft.trim()) return;
    setList([...list, { author: "Anika Verma", ts: new Date().toISOString().replace("T", " ").slice(0, 16), text: draft }]);
    setDraft("");
  };
  return (
    <div className="px-4 py-4">
      <div className="flex items-center gap-2 mb-2">
        <I name="message-square" size={11} className="muted"/>
        <span className="muted uppercase tracking-wider" style={{ fontSize: 9.5, fontWeight: 600 }}>Internal notes</span>
        <span className="chip ml-auto" style={{ fontSize: 9.5, padding: "1px 5px", color: "var(--warn)", borderColor: "color-mix(in oklch, var(--warn) 30%, var(--line))" }}>
          <I name="eye-off" size={9}/> not visible to vendor
        </span>
      </div>
      <div className="space-y-2">
        {list.length === 0 && <div className="muted" style={{ fontSize: 11.5 }}>No internal notes yet.</div>}
        {list.map((n, i) => (
          <div key={i} className="panel px-3 py-2" style={{ background: "var(--bg)", borderRadius: 4 }}>
            <div className="flex items-center gap-2 mb-1">
              <Avatar name={n.author} size={16}/>
              <span className="ink-2" style={{ fontSize: 11.5, fontWeight: 500 }}>{n.author}</span>
              <Mono className="muted ml-auto" style={{ fontSize: 10 }}>{n.ts}</Mono>
            </div>
            <div className="ink-2" style={{ fontSize: 12, lineHeight: 1.5 }}>{n.text}</div>
          </div>
        ))}
      </div>
      <div className="mt-2">
        <textarea value={draft} onChange={e => setDraft(e.target.value)}
          placeholder="Add an internal note (only visible to VQMS team)…"
          style={{ width: "100%", minHeight: 60, fontSize: 12, resize: "vertical" }}/>
        <button className="btn btn-primary mt-1.5 w-full justify-center" onClick={post} style={{ fontSize: 11.5 }}>
          <I name="send" size={11}/> Post note
        </button>
      </div>
    </div>
  );
};

// Inline composer (appears at bottom of detail)
const InlineComposer = ({ mode, row, onClose, seedBody = "" }) => {
  const [body, setBody] = React.useState(seedBody);
  const [resolveOnSend, setResolveOnSend] = React.useState(false);
  const isForward = mode === "Forward";
  return (
    <div className="px-6 pb-6 fade-up">
      <div className="panel" style={{ borderRadius: 4, borderColor: "var(--line-strong)" }}>
        <div className="flex items-center gap-2 px-4 py-2.5 border-b hairline" style={{ background: "var(--bg)" }}>
          <I name="pen-line" size={13} className="text-accent"/>
          <span className="ink" style={{ fontSize: 12.5, fontWeight: 600 }}>{mode}</span>
          <Mono className="muted" style={{ fontSize: 10.5 }}>· conversationId preserved · POST /admin/email/queries/{row.query_id}/reply</Mono>
          <span className="flex-1"/>
          <button className="btn btn-ghost" onClick={onClose}><I name="x" size={13}/></button>
        </div>

        {/* Recipients */}
        <div className="px-4 py-2 border-b hairline space-y-1">
          <ComposerRow label="To"      defaultValue={isForward ? "" : row.from_address}/>
          <ComposerRow label="Cc"      defaultValue={row.cc_addresses.join(", ")}/>
          <ComposerRow label="Bcc"     defaultValue=""/>
          <ComposerRow label="Subject" defaultValue={`${mode === "Forward" ? "Fwd: " : "Re: "}${row.subject.replace(/^(Re:|Fwd:)\s*/i, "")}`}/>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-1 px-4 py-1.5 border-b hairline">
          {["bold","italic","underline","list","list-ordered","link","code","quote"].map(i => (
            <button key={i} className="btn btn-ghost" style={{ padding: "4px 6px" }}><I name={i} size={12}/></button>
          ))}
          <div style={{ width: 1, height: 18, background: "var(--line)", margin: "0 4px" }}/>
          <button className="btn btn-ghost" style={{ padding: "4px 8px", fontSize: 11.5 }}><I name="paperclip" size={12}/> Attach</button>
          <button className="btn btn-ghost" style={{ padding: "4px 8px", fontSize: 11.5 }}><I name="file-text" size={12}/> Template</button>
        </div>

        <textarea value={body} onChange={e => setBody(e.target.value)}
          placeholder={`Type your ${mode.toLowerCase()}…`}
          style={{ width: "100%", minHeight: 200, fontSize: 13, lineHeight: 1.6, border: "none", borderRadius: 0, padding: 16, resize: "vertical" }}/>

        <div className="flex items-center gap-2 px-4 py-2.5 border-t hairline" style={{ background: "var(--bg)" }}>
          <button className="btn btn-accent">
            <I name="send" size={13}/> Send via Microsoft Graph
          </button>
          <button className="btn">
            <I name="check-check" size={13}/> Send & resolve query
          </button>
          <button className="btn">
            <I name="save" size={13}/> Save draft
          </button>
          <span className="flex-1"/>
          <label className="flex items-center gap-2 muted" style={{ fontSize: 11.5 }}>
            <input type="checkbox" checked={resolveOnSend} onChange={e => setResolveOnSend(e.target.checked)}
              style={{ accentColor: "var(--accent)" }}/>
            mark <Mono style={{ fontSize: 10.5 }}>{row.query_id}</Mono> resolved
          </label>
        </div>
      </div>
    </div>
  );
};
const ComposerRow = ({ label, defaultValue }) => (
  <div className="flex items-center gap-3" style={{ fontSize: 12.5 }}>
    <span className="muted" style={{ width: 56, textAlign: "right", fontSize: 11 }}>{label}</span>
    <input defaultValue={defaultValue}
      style={{ flex: 1, border: "none", padding: "4px 0", borderRadius: 0, background: "transparent", fontSize: 12.5 }}/>
  </div>
);

// =========================================================
// Compose modal (slide-over)
// =========================================================
const ComposeModal = ({ open, onClose }) => {
  const [vendorId, setVendorId] = React.useState("V-001");
  const [linkQuery, setLinkQuery] = React.useState("none");
  const [template, setTemplate] = React.useState("none");
  const [subject, setSubject] = React.useState("");
  const [body, setBody] = React.useState("");

  if (!open) return null;
  const vendor = window.VENDORS.find(v => v.vendor_id === vendorId);
  const contacts = window.CONTACTS[vendorId] || [];

  return (
    <div className="fixed inset-0 z-40" style={{ background: "rgba(0,0,0,.32)" }} onClick={onClose}>
      <div className="absolute right-0 top-0 bottom-0 panel fade-up overflow-auto"
        style={{ width: 760, borderLeft: "1px solid var(--line-strong)" }}
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b hairline">
          <div>
            <div className="ink" style={{ fontSize: 16, fontWeight: 600 }}>New email</div>
            <Mono className="muted" style={{ fontSize: 11 }}>POST /admin/email/send · X‑Request‑Id idempotency</Mono>
          </div>
          <button className="btn btn-ghost" onClick={onClose}><I name="x" size={14}/></button>
        </div>

        <div className="px-6 py-4 space-y-4">
          <div>
            <Label>Vendor</Label>
            <select value={vendorId} onChange={e => setVendorId(e.target.value)} style={{ width: "100%" }}>
              {window.VENDORS.map(v => <option key={v.vendor_id} value={v.vendor_id}>{v.vendor_id} · {v.name} · {v.tier}</option>)}
            </select>
            {vendor && (
              <div className="muted mt-1" style={{ fontSize: 11 }}>
                {vendor.category} · {vendor.city}, {vendor.country} · SLA <Mono>{vendor.sla_response_hours}h/{vendor.sla_resolution_days}d</Mono>
              </div>
            )}
          </div>

          <div>
            <Label>Recipients <Mono className="muted ml-1" style={{ fontSize: 10 }}>from Vendor_Contact__c</Mono></Label>
            <div className="space-y-1.5">
              {contacts.map((c, i) => (
                <label key={c.email} className="flex items-center gap-2 panel px-3 py-2 cursor-pointer" style={{ borderRadius: 4 }}>
                  <input type="checkbox" defaultChecked={i === 0} style={{ accentColor: "var(--accent)" }}/>
                  <Avatar name={c.name} size={22}/>
                  <div className="flex-1">
                    <div className="ink-2" style={{ fontSize: 12.5, fontWeight: 500 }}>{c.name}</div>
                    <Mono className="muted" style={{ fontSize: 10.5 }}>{c.email} · {c.role}</Mono>
                  </div>
                </label>
              ))}
              {contacts.length === 0 && <div className="muted" style={{ fontSize: 12 }}>No contacts on file. Add one in Vendor 360.</div>}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Link to query (optional)</Label>
              <select value={linkQuery} onChange={e => setLinkQuery(e.target.value)} style={{ width: "100%" }}>
                <option value="none">— None —</option>
                {window.QUERIES.filter(q => q.vendor_id === vendorId).slice(0, 8).map(q => (
                  <option key={q.query_id} value={q.query_id}>{q.query_id} · {q.subject.slice(0, 50)}</option>
                ))}
              </select>
            </div>
            <div>
              <Label>Template</Label>
              <select value={template} onChange={e => setTemplate(e.target.value)} style={{ width: "100%" }}>
                <option value="none">— None —</option>
                {window.MAIL_TEMPLATES.map(t => (
                  <option key={t.id} value={t.id}>{t.category} · {t.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <Label>Subject</Label>
            <input value={subject} onChange={e => setSubject(e.target.value)} style={{ width: "100%" }}
              placeholder="e.g. Banking detail change — verification required"/>
          </div>

          <div>
            <Label>Message</Label>
            <textarea value={body} onChange={e => setBody(e.target.value)}
              style={{ width: "100%", minHeight: 220, fontSize: 13, lineHeight: 1.6 }}
              placeholder="Compose your message…"/>
          </div>

          <div>
            <Label>Attachments</Label>
            <div className="panel px-4 py-6 text-center" style={{ borderRadius: 4, borderStyle: "dashed", background: "var(--bg)" }}>
              <I name="upload-cloud" size={20} className="muted"/>
              <div className="ink-2 mt-1" style={{ fontSize: 12.5 }}>Drop files or click to upload</div>
              <Mono className="muted" style={{ fontSize: 10.5 }}>uploaded to Amazon S3 · sent via Microsoft Graph</Mono>
            </div>
          </div>
        </div>

        <div className="border-t hairline px-6 py-3 flex items-center gap-2 sticky bottom-0" style={{ background: "var(--panel)" }}>
          <button className="btn btn-accent">
            <I name="send" size={13}/> Send via Microsoft Graph
          </button>
          <button className="btn">
            <I name="save" size={13}/> Save draft
          </button>
          <span className="flex-1"/>
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
        </div>
      </div>
    </div>
  );
};
const Label = ({ children }) => (
  <div className="muted uppercase tracking-wider mb-1.5" style={{ fontSize: 10, fontWeight: 600 }}>{children}</div>
);

// =========================================================
// Sync banner (top of screen)
// =========================================================
const SyncBanner = () => {
  const [seconds, setSeconds] = React.useState(window.MAIL_SYNC.last_sync_seconds_ago);
  const [newCount, setNewCount] = React.useState(0);
  React.useEffect(() => {
    const t = setInterval(() => setSeconds(s => (s + 1) % 90), 1000);
    const t2 = setInterval(() => setNewCount(c => c + (Math.random() > 0.55 ? 1 : 0)), 9000);
    return () => { clearInterval(t); clearInterval(t2); };
  }, []);
  const degraded = window.MAIL_SYNC.graph_status !== "healthy";

  return (
    <div className="flex items-center gap-3 px-6 py-2 border-b hairline" style={{
      background: degraded
        ? "color-mix(in oklch, var(--warn) 8%, var(--panel))"
        : "var(--panel)",
      fontSize: 11.5,
    }}>
      <span className="flex items-center gap-1.5">
        <HealthDot status={window.MAIL_SYNC.graph_status}/>
        <span className="ink-2" style={{ fontWeight: 500 }}>Microsoft Graph API</span>
        {degraded && <span style={{ color: "var(--warn)" }}>· {window.MAIL_SYNC.graph_note}</span>}
      </span>
      <span className="muted">|</span>
      <span className="muted">
        <Mono>vqms‑email‑intake‑queue</Mono> · {window.MAIL_SYNC.sqs_visible} visible / {window.MAIL_SYNC.sqs_in_flight} in‑flight / {window.MAIL_SYNC.sqs_dlq} DLQ
      </span>
      <span className="flex-1"/>
      {newCount > 0 && (
        <button className="chip fade-up" style={{ background: "var(--accent-soft)", color: "var(--accent)", borderColor: "var(--accent)", fontWeight: 600 }}>
          <I name="arrow-down" size={10}/> {newCount} new email{newCount === 1 ? "" : "s"} — refresh
        </button>
      )}
      <span className="muted inline-flex items-center gap-1.5">
        <I name="refresh-cw" size={10}/>
        last synced <Mono className="ink-2" style={{ fontSize: 10.5 }}>{seconds}s</Mono> ago
      </span>
    </div>
  );
};

// =========================================================
// Endpoints reference (uses shared drawer)
// =========================================================
const EndpointsCard = ({ open, onClose }) => (
  <window.EndpointsDrawer
    open={open}
    onClose={onClose}
    title="Email management · backend contract"
    subtitle="extends dashboard.py + admin.py · src/api/routes/*"
    endpoints={(window.MAIL_ENDPOINTS || []).map(e => ({ ...e }))}
    role="Admin"
  />
);

// =========================================================
// Top-level Mail screen
// =========================================================
const Mail = () => {
  const [folder, setFolder] = React.useState("inbox");
  const [filters, setFilters] = React.useState({ vendor: "ALL", path: "ALL", conf: "ALL", date: "ALL", sla: "ALL", has_attach: false });
  const [selectedId, setSelectedId] = React.useState(window.MAIL_THREADS[0].message_id);
  const [bulk, setBulk] = React.useState(new Set());
  const [search, setSearch] = React.useState("");
  const [sort, setSort] = React.useState("newest");
  const [composeOpen, setComposeOpen] = React.useState(false);
  const [endpointsOpen, setEndpointsOpen] = React.useState(false);
  const [flagged, setFlagged] = React.useState(new Set(window.MAIL_THREADS.filter(r => r._flagged).map(r => r.message_id)));
  const [archived, setArchived] = React.useState(new Set());

  // Derived rows
  const allRows = window.MAIL_THREADS.map(r => ({ ...r, _flagged: flagged.has(r.message_id) }));

  const folderRows = React.useMemo(() => allRows.filter(r => {
    if (archived.has(r.message_id) && folder !== "archived") return false;
    switch (folder) {
      case "all":         return r._direction === "inbound";
      case "unread":      return r._direction === "inbound" && r._status === "unread";
      case "inbox":       return r._direction === "inbound" && r._status !== "draft";
      case "sent":        return r._direction === "outbound" && r._status === "sent";
      case "drafts":      return r._status === "draft";
      case "awaiting":    return r._direction === "outbound" && r._sla_pct != null;
      case "ai_suggested":return r._direction === "inbound" && r._has_ai_draft;
      case "flagged":     return r._flagged;
      case "archived":    return archived.has(r.message_id);
      case "spam":        return false;
      default: return true;
    }
  }), [folder, allRows, archived]);

  const filteredRows = React.useMemo(() => {
    let list = folderRows.filter(r => {
      if (filters.vendor !== "ALL" && r.vendor_id !== filters.vendor) return false;
      if (filters.path !== "ALL" && r.processing_path !== filters.path) return false;
      if (filters.conf === "HIGH" && r.confidence_score < 0.85) return false;
      if (filters.conf === "MED"  && (r.confidence_score < 0.6 || r.confidence_score >= 0.85)) return false;
      if (filters.conf === "LOW"  && r.confidence_score >= 0.6) return false;
      if (filters.has_attach && r.attachments.length === 0) return false;
      if (filters.sla !== "ALL") {
        const p = r._sla_pct;
        if (p == null) return false;
        if (filters.sla === "OK"   && p >= 70) return false;
        if (filters.sla === "RISK" && (p < 70 || p >= 95)) return false;
        if (filters.sla === "BAD"  && p < 95) return false;
      }
      if (search) {
        const s = search.toLowerCase();
        if (!(r.subject.toLowerCase().includes(s)
          || r.from_name.toLowerCase().includes(s)
          || r.from_address.toLowerCase().includes(s)
          || r.body_text.toLowerCase().includes(s)
          || r.vendor_name.toLowerCase().includes(s)
          || r.query_id.toLowerCase().includes(s))) return false;
      }
      return true;
    });
    // sort
    list.sort((a, b) => {
      if (sort === "oldest") return new Date(a.received_at) - new Date(b.received_at);
      if (sort === "confidence") return b.confidence_score - a.confidence_score;
      if (sort === "priority") return (b._sla_pct ?? -1) - (a._sla_pct ?? -1);
      return new Date(b.received_at) - new Date(a.received_at);
    });
    return list;
  }, [folderRows, filters, search, sort]);

  // Folder counts
  const counts = React.useMemo(() => {
    const c = {};
    for (const f of window.MAIL_FOLDERS) {
      const tmp = folder; // not used; just compute fresh
      let n = 0;
      for (const r of allRows) {
        const a = archived.has(r.message_id);
        if (a && f.id !== "archived") continue;
        if (
          (f.id === "all" && r._direction === "inbound") ||
          (f.id === "unread" && r._direction === "inbound" && r._status === "unread") ||
          (f.id === "inbox" && r._direction === "inbound" && r._status !== "draft") ||
          (f.id === "sent" && r._direction === "outbound" && r._status === "sent") ||
          (f.id === "drafts" && r._status === "draft") ||
          (f.id === "awaiting" && r._direction === "outbound" && r._sla_pct != null) ||
          (f.id === "ai_suggested" && r._direction === "inbound" && r._has_ai_draft) ||
          (f.id === "flagged" && r._flagged) ||
          (f.id === "archived" && archived.has(r.message_id))
        ) n++;
      }
      c[f.id] = n;
    }
    return c;
  }, [allRows, archived, folder]);

  const selectedRow = filteredRows.find(r => r.message_id === selectedId) || filteredRows[0];

  // Keyboard shortcuts
  React.useEffect(() => {
    const onKey = (e) => {
      const tag = (document.activeElement?.tagName || "").toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") return;
      if (e.key === "j" || e.key === "k") {
        e.preventDefault();
        const idx = filteredRows.findIndex(r => r.message_id === selectedRow?.message_id);
        const next = e.key === "j" ? Math.min(filteredRows.length - 1, idx + 1) : Math.max(0, idx - 1);
        if (filteredRows[next]) setSelectedId(filteredRows[next].message_id);
      } else if (e.key === "c") {
        e.preventDefault(); setComposeOpen(true);
      } else if (e.key === "/") {
        e.preventDefault();
        document.querySelector('input[placeholder="Search mail…"]')?.focus();
      } else if (e.key === "e" && selectedRow) {
        e.preventDefault();
        const next = new Set(archived); next.add(selectedRow.message_id); setArchived(next);
      } else if (e.key === "f" && selectedRow) {
        e.preventDefault();
        const next = new Set(flagged);
        next.has(selectedRow.message_id) ? next.delete(selectedRow.message_id) : next.add(selectedRow.message_id);
        setFlagged(next);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [filteredRows, selectedRow, archived, flagged]);

  // Compose event from rail
  React.useEffect(() => {
    const open = () => setComposeOpen(true);
    window.addEventListener("vqms:compose", open);
    return () => window.removeEventListener("vqms:compose", open);
  }, []);

  const handleUpdate = (action) => {
    if (!selectedRow) return;
    if (action === "flag") {
      const next = new Set(flagged);
      next.has(selectedRow.message_id) ? next.delete(selectedRow.message_id) : next.add(selectedRow.message_id);
      setFlagged(next);
    } else if (action === "archive") {
      const next = new Set(archived); next.add(selectedRow.message_id); setArchived(next);
    }
  };

  return (
    <div className="flex flex-col fade-up" style={{ height: "100%" }}>
      <SyncBanner/>

      {/* Header strip */}
      <div className="flex items-center justify-between px-6 py-3 border-b hairline bg-panel">
        <div>
          <div className="ink" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-.02em" }}>Email management</div>
          <div className="muted mt-0.5" style={{ fontSize: 12 }}>
            Unified vendor inbox · <Mono>{window.MAIL_THREADS.filter(r => r._direction === "inbound").length}</Mono> messages ·
            backed by <Mono>intake.email_messages</Mono> + <Mono>workflow.draft_responses</Mono>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn" onClick={() => setEndpointsOpen(true)}>
            <I name="terminal" size={13}/> Endpoints
          </button>
          <button className="btn btn-accent" onClick={() => setComposeOpen(true)}>
            <I name="pen-line" size={13}/> Compose
            <Mono style={{ color: "rgba(255,255,255,.7)", fontSize: 10, marginLeft: 4 }}>C</Mono>
          </button>
        </div>
      </div>

      {/* Three-pane */}
      <div className="flex-1 flex overflow-hidden">
        <FolderRail folder={folder} setFolder={setFolder} filters={filters} setFilters={setFilters} counts={counts}/>
        <MailList rows={filteredRows} selectedId={selectedRow?.message_id} onSelect={setSelectedId}
          bulk={bulk} setBulk={setBulk}
          search={search} setSearch={setSearch}
          sort={sort} setSort={setSort}
          folder={folder}/>
        <MailDetail row={selectedRow} onUpdate={handleUpdate}/>
      </div>

      <ComposeModal open={composeOpen} onClose={() => setComposeOpen(false)}/>
      <EndpointsCard open={endpointsOpen} onClose={() => setEndpointsOpen(false)}/>
    </div>
  );
};

Object.assign(window, { Mail });
