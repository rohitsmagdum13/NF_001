// =========================================================
// Shared Endpoints drawer + per-screen catalogs
// Used by every top-level screen so admins/reviewers/vendors can
// see the exact backend contract behind the UI they're looking at.
// =========================================================

// ---------- Drawer component ----------
const EndpointsDrawer = ({ open, onClose, title, subtitle, endpoints = [], role = "Admin" }) => {
  if (!open) return null;
  const exists = endpoints.filter(e => e.status === "exists");
  const proposed = endpoints.filter(e => e.status === "new");

  const verbColor = (m, status) => {
    if (m === "GET") return "var(--info)";
    if (m === "DELETE") return "var(--bad)";
    return status === "new" ? "var(--accent)" : "var(--ok)";
  };

  return (
    <div className="fixed inset-0 z-40" style={{ background: "rgba(0,0,0,.32)" }} onClick={onClose}>
      <div className="absolute right-0 top-0 bottom-0 panel fade-up overflow-auto"
        style={{ width: 720, borderLeft: "1px solid var(--line-strong)" }}
        onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-6 py-4 border-b hairline" style={{ position: "sticky", top: 0, background: "var(--panel)", zIndex: 1 }}>
          <div>
            <div className="ink" style={{ fontSize: 16, fontWeight: 600 }}>{title || "Backend endpoints this UI calls"}</div>
            <Mono className="muted" style={{ fontSize: 11 }}>{subtitle || "handoff reference · src/api/routes/*"}</Mono>
          </div>
          <div className="flex items-center gap-2">
            <span className="chip" style={{
              background: role === "Admin" ? "var(--accent-soft)" : role === "Reviewer" ? "color-mix(in oklch, var(--info) 12%, var(--panel))" : "var(--bg)",
              color: role === "Admin" ? "var(--accent)" : role === "Reviewer" ? "var(--info)" : "var(--ink-2)",
              borderColor: "transparent"
            }}><I name="user" size={10}/> {role} scope</span>
            <button className="btn btn-ghost" onClick={onClose}><I name="x" size={14}/></button>
          </div>
        </div>

        <div className="px-6 py-4">
          {exists.length > 0 && <>
            <div className="muted uppercase tracking-wider mb-2 flex items-center gap-2" style={{ fontSize: 10, fontWeight: 600 }}>
              Already in codebase
              <Mono style={{ fontSize: 10, padding: "0 6px", background: "var(--bg)", color: "var(--ok)", borderRadius: 999 }}>{exists.length}</Mono>
            </div>
            <table className="vqms-table">
              <thead>
                <tr><th style={{ width: 70 }}>Verb</th><th>Path</th><th>Source</th><th>Notes</th></tr>
              </thead>
              <tbody>
                {exists.map((e, i) => (
                  <tr key={i} style={{ cursor: "default" }}>
                    <td><Mono style={{ fontWeight: 600, color: verbColor(e.method, e.status) }}>{e.method}</Mono></td>
                    <td><Mono className="ink" style={{ fontWeight: 500 }}>{e.path}</Mono></td>
                    <td className="muted" style={{ fontSize: 11.5 }}>{e.source}</td>
                    <td className="muted" style={{ fontSize: 11.5 }}>{e.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>}

          {proposed.length > 0 && <>
            <div className="muted uppercase tracking-wider mb-2 mt-6 flex items-center gap-2" style={{ fontSize: 10, fontWeight: 600 }}>
              Proposed new
              <Mono style={{ fontSize: 10, padding: "0 6px", background: "var(--accent-soft)", color: "var(--accent)", borderRadius: 999 }}>{proposed.length}</Mono>
            </div>
            <table className="vqms-table">
              <thead>
                <tr><th style={{ width: 70 }}>Verb</th><th>Path</th><th>Wraps / depends on</th><th>Notes</th></tr>
              </thead>
              <tbody>
                {proposed.map((e, i) => (
                  <tr key={i} style={{ cursor: "default" }}>
                    <td><Mono style={{ fontWeight: 600, color: verbColor(e.method, e.status) }}>{e.method}</Mono></td>
                    <td><Mono className="ink" style={{ fontWeight: 500 }}>{e.path}</Mono></td>
                    <td className="muted" style={{ fontSize: 11.5 }}>{e.source || "—"}</td>
                    <td className="muted" style={{ fontSize: 11.5 }}>{e.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </>}

          <div className="mt-6 panel" style={{ background: "var(--bg)", padding: 12, borderRadius: 4 }}>
            <div className="muted" style={{ fontSize: 11, lineHeight: 1.6 }}>
              <Mono style={{ color: "var(--ink-2)" }}>Authorization: Bearer &lt;jwt&gt;</Mono> · 8h TTL ·
              role claims gate every route.
              All write operations emit a <Mono style={{ color: "var(--ink-2)" }}>workflow.audit_events</Mono> row
              and an <Mono style={{ color: "var(--ink-2)" }}>Amazon EventBridge</Mono> event for downstream consumers.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ---------- Reusable header button ----------
const EndpointsButton = ({ onClick, label = "Endpoints" }) => (
  <button className="btn" onClick={onClick}>
    <I name="terminal" size={13}/> {label}
  </button>
);

// ---------- Hook for state ----------
const useEndpoints = () => {
  const [open, setOpen] = React.useState(false);
  return { open, setOpen, openIt: () => setOpen(true), closeIt: () => setOpen(false) };
};

// =========================================================
// Catalogs — per screen, role-aware where needed
// =========================================================
const ENDPOINTS_INBOX = [
  { method: "GET",    path: "/queries",                                 status: "exists", source: "queries.py",            note: "list with filters: status, vendor_id, path, sla, priority, q" },
  { method: "GET",    path: "/queries/stats",                           status: "exists", source: "queries.py",            note: "counts by status / path / SLA bucket" },
  { method: "GET",    path: "/queries/{query_id}",                       status: "exists", source: "queries.py",            note: "single query + thread + audit" },
  { method: "POST",   path: "/queries/{query_id}/assign",                status: "exists", source: "queries.py",            note: "{ assignee_id }" },
  { method: "POST",   path: "/queries/{query_id}/reopen",                status: "exists", source: "queries.py",            note: "moves CLOSED → IN_PROGRESS" },
  { method: "POST",   path: "/queries/{query_id}/comment",               status: "exists", source: "queries.py",            note: "internal note, never sent to vendor" },
  { method: "POST",   path: "/queries/bulk",                             status: "new",    source: "wraps assign/close",     note: "{ ids[], action: assign|close|tag|reopen }" },
  { method: "GET",    path: "/queries/saved-views",                      status: "new",    source: "workflow.saved_views",   note: "per-user inbox filter presets" },
  { method: "POST",   path: "/queries/saved-views",                      status: "new",    source: "workflow.saved_views",   note: "persist current filter set" },
  { method: "GET",    path: "/queries/export.csv",                       status: "new",    source: "queries.py",             note: "stream filtered list as CSV (S3-presigned)" },
];

const ENDPOINTS_TRIAGE = [
  { method: "GET",    path: "/triage/packages",                          status: "exists", source: "triage.py",             note: "Path C items needing human review, ordered by SLA" },
  { method: "GET",    path: "/triage/packages/{query_id}",               status: "exists", source: "triage.py",             note: "full triage package: extract + KB + history + suggested action" },
  { method: "POST",   path: "/triage/packages/{query_id}/decision",      status: "exists", source: "triage.py",             note: "{ decision: APPROVE|REJECT|ESCALATE, reason, draft_id? }" },
  { method: "POST",   path: "/triage/packages/{query_id}/route",         status: "exists", source: "triage.py",             note: "override path A/B/C assignment" },
  { method: "POST",   path: "/triage/packages/{query_id}/escalate",      status: "exists", source: "ticketing.py",          note: "creates ServiceNow incident, links sys_id" },
  { method: "POST",   path: "/triage/packages/bulk-claim",               status: "new",    source: "extends triage.py",      note: "{ ids[] } — atomic claim by current reviewer" },
  { method: "GET",    path: "/triage/leaderboard",                       status: "new",    source: "workflow.audit_events",  note: "per-reviewer throughput + accuracy" },
  { method: "POST",   path: "/triage/packages/{query_id}/regenerate",    status: "new",    source: "wraps Bedrock invoke",   note: "force AI re-draft with reviewer hints" },
];

const ENDPOINTS_VENDORS = [
  { method: "GET",    path: "/vendors",                                  status: "exists", source: "vendors.py",            note: "from Salesforce Vendor_Account__c (5min cache)" },
  { method: "GET",    path: "/vendors/{vendor_id}",                      status: "exists", source: "vendors.py",            note: "single vendor + open queries + health score" },
  { method: "GET",    path: "/vendors/{vendor_id}/queries",              status: "exists", source: "queries.py",            note: "scoped to vendor" },
  { method: "GET",    path: "/vendors/{vendor_id}/timeline",             status: "exists", source: "vendors.py",            note: "merged inbound + outbound + status events" },
  { method: "GET",    path: "/vendors/{vendor_id}/contacts",             status: "exists", source: "vendors.py",            note: "Salesforce Vendor_Contact__c" },
  { method: "GET",    path: "/vendors/{vendor_id}/memory",               status: "exists", source: "memory.py",             note: "episodic memory write-backs (Bedrock)" },
  { method: "POST",   path: "/vendors/{vendor_id}/health-recompute",     status: "new",    source: "vendors.py + sqs",       note: "force health-score recompute job" },
  { method: "POST",   path: "/vendors/{vendor_id}/notes",                status: "new",    source: "workflow.vendor_notes",  note: "internal-only notes pinned on Vendor 360" },
  { method: "GET",    path: "/vendors/export.csv",                       status: "new",    source: "vendors.py",             note: "stream all vendors + counts" },
];

const ENDPOINTS_VENDOR360 = [
  { method: "GET",    path: "/vendors/{vendor_id}",                      status: "exists", source: "vendors.py",            note: "header card + tier + region" },
  { method: "GET",    path: "/vendors/{vendor_id}/queries?status=open",  status: "exists", source: "queries.py",            note: "open queries panel" },
  { method: "GET",    path: "/vendors/{vendor_id}/timeline",             status: "exists", source: "vendors.py",            note: "activity feed" },
  { method: "GET",    path: "/vendors/{vendor_id}/contacts",             status: "exists", source: "vendors.py",            note: "Vendor_Contact__c" },
  { method: "GET",    path: "/vendors/{vendor_id}/memory",               status: "exists", source: "memory.py",             note: "Bedrock episodic memory entries" },
  { method: "GET",    path: "/vendors/{vendor_id}/sla-summary",          status: "new",    source: "wraps queries + audit",  note: "rolling 30/60/90-day SLA performance" },
  { method: "POST",   path: "/vendors/{vendor_id}/notes",                status: "new",    source: "workflow.vendor_notes",  note: "pin internal notes on the 360 view" },
];

const ENDPOINTS_EMAIL_MONITOR = [
  { method: "GET",    path: "/health",                                   status: "exists", source: "health.py",             note: "Microsoft Graph + Amazon SQS depth + DLQ" },
  { method: "GET",    path: "/emails",                                   status: "exists", source: "dashboard.py",          note: "ingestion log feed" },
  { method: "GET",    path: "/emails/stats",                             status: "exists", source: "dashboard.py",          note: "filtered/relevant/Path A-B-C counts" },
  { method: "POST",   path: "/admin/email/replay/{message_id}",          status: "exists", source: "admin.py",              note: "re-run a single message through the pipeline" },
  { method: "POST",   path: "/admin/email/replay-dlq",                   status: "new",    source: "wraps admin.py",         note: "drain Amazon SQS DLQ in batches" },
  { method: "GET",    path: "/pipeline/throughput",                      status: "new",    source: "Amazon CloudWatch",      note: "messages/min by stage, last 24h" },
  { method: "GET",    path: "/pipeline/textract-jobs",                   status: "new",    source: "wraps Textract",         note: "in-flight + recent OCR jobs with confidence" },
];

const ENDPOINTS_KB = [
  { method: "GET",    path: "/kb/articles",                              status: "exists", source: "kb.py",                 note: "list with vector + metadata filters" },
  { method: "GET",    path: "/kb/articles/{article_id}",                 status: "exists", source: "kb.py",                 note: "single article + embedding info" },
  { method: "POST",   path: "/kb/search",                                status: "exists", source: "kb.py",                 note: "{ query, k } — Bedrock embedding + cosine over Postgres pgvector" },
  { method: "POST",   path: "/kb/articles",                              status: "new",    source: "kb.py",                  note: "{ title, body_md, tags[] } — re-embeds on save" },
  { method: "PATCH",  path: "/kb/articles/{article_id}",                 status: "new",    source: "kb.py",                  note: "edit + bump version + re-embed" },
  { method: "POST",   path: "/kb/reindex",                               status: "new",    source: "wraps Bedrock embed",    note: "force full re-embed (admin only)" },
];

const ENDPOINTS_BULK = [
  { method: "POST",   path: "/queries/bulk",                             status: "new",    source: "wraps queries.py",       note: "{ ids[], action } — assign / close / tag / reopen" },
  { method: "POST",   path: "/admin/email/bulk",                         status: "new",    source: "wraps admin.py",         note: "{ ids[], action: archive|reroute|replay }" },
  { method: "POST",   path: "/exports",                                  status: "new",    source: "exports.py",             note: "kicks off async CSV/XLSX export → S3" },
  { method: "GET",    path: "/exports/{export_id}",                      status: "new",    source: "exports.py",             note: "poll job status + presigned URL" },
];

const ENDPOINTS_AUDIT = [
  { method: "GET",    path: "/audit",                                    status: "exists", source: "audit.py",              note: "filterable: actor, target_type, action, time range" },
  { method: "GET",    path: "/audit/{event_id}",                         status: "exists", source: "audit.py",              note: "single event + before/after diff" },
  { method: "GET",    path: "/audit/export.csv",                         status: "new",    source: "audit.py",               note: "stream filtered audit log" },
  { method: "GET",    path: "/audit/anomalies",                          status: "new",    source: "wraps Bedrock",          note: "AI-flagged unusual actor/action pairs" },
];

const ENDPOINTS_ADMIN = [
  { method: "GET",    path: "/admin/users",                              status: "exists", source: "admin.py",              note: "user list + roles" },
  { method: "POST",   path: "/admin/users",                              status: "exists", source: "admin.py",              note: "invite by email" },
  { method: "PATCH",  path: "/admin/users/{user_id}",                    status: "exists", source: "admin.py",              note: "role / status changes" },
  { method: "GET",    path: "/admin/feature-flags",                      status: "exists", source: "admin.py",              note: "system feature toggles" },
  { method: "PATCH",  path: "/admin/feature-flags/{flag}",               status: "exists", source: "admin.py",              note: "{ enabled }" },
  { method: "GET",    path: "/admin/integrations",                       status: "new",    source: "admin.py",               note: "connection state for Salesforce, Microsoft Graph, ServiceNow, Bedrock" },
  { method: "POST",   path: "/admin/integrations/{key}/test",            status: "new",    source: "admin.py",               note: "round-trip ping for selected integration" },
  { method: "GET",    path: "/admin/secrets",                            status: "new",    source: "AWS Secrets Manager",    note: "metadata only — never plaintext values" },
];

const ENDPOINTS_OVERVIEW = [
  { method: "GET",    path: "/dashboard/overview",                       status: "exists", source: "dashboard.py",          note: "headline KPIs + path-mix sparklines" },
  { method: "GET",    path: "/dashboard/sla",                            status: "exists", source: "dashboard.py",          note: "rolling SLA performance" },
  { method: "GET",    path: "/dashboard/throughput",                     status: "exists", source: "dashboard.py",          note: "queries/day, last 30d" },
  { method: "GET",    path: "/dashboard/path-mix",                       status: "exists", source: "dashboard.py",          note: "Path A/B/C distribution + AI confidence histogram" },
];

// ---------- Vendor portal (vendor-facing, narrow scope) ----------
const ENDPOINTS_PORTAL = [
  { method: "POST",   path: "/portal/auth/login",                        status: "exists", source: "auth.py",               note: "vendor JWT, scoped to single vendor_id" },
  { method: "GET",    path: "/portal/me",                                status: "exists", source: "portal.py",             note: "vendor profile + contact + tier" },
  { method: "GET",    path: "/portal/queries",                           status: "exists", source: "portal.py",             note: "queries WHERE vendor_id = me — never cross-vendor" },
  { method: "GET",    path: "/portal/queries/{query_id}",                status: "exists", source: "portal.py",             note: "single query — RLS enforced" },
  { method: "POST",   path: "/portal/queries",                           status: "exists", source: "portal.py",             note: "{ intent, subject, body, attachments[] } — uploads to S3 via presigned PUT" },
  { method: "POST",   path: "/portal/queries/{query_id}/reply",          status: "exists", source: "portal.py",             note: "vendor adds message to thread; emits inbound EventBridge event" },
  { method: "POST",   path: "/portal/uploads/presign",                   status: "exists", source: "portal.py",             note: "returns S3 presigned PUT for attachments" },
  { method: "GET",    path: "/portal/notifications",                     status: "new",    source: "portal.py",              note: "in-app notifications (status changes, replies)" },
  { method: "POST",   path: "/portal/notifications/{id}/ack",            status: "new",    source: "portal.py",              note: "mark notification read" },
  { method: "GET",    path: "/portal/sla/{query_id}",                    status: "new",    source: "wraps queries.py",       note: "vendor-safe SLA view (no internal reviewer notes)" },
];

// expose
Object.assign(window, {
  EndpointsDrawer, EndpointsButton, useEndpoints,
  ENDPOINTS_INBOX, ENDPOINTS_TRIAGE, ENDPOINTS_VENDORS, ENDPOINTS_VENDOR360,
  ENDPOINTS_EMAIL_MONITOR, ENDPOINTS_KB, ENDPOINTS_BULK, ENDPOINTS_AUDIT,
  ENDPOINTS_ADMIN, ENDPOINTS_OVERVIEW, ENDPOINTS_PORTAL,
});
