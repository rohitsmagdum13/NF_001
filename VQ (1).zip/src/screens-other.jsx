// Admin / audit / triage / login

// --- Admin (integrations health + users + flags) ---

const Admin = () => {
  const [tab, setTab] = React.useState("integrations");
  const { caps, role } = window.useRole();
  const ep = window.useEndpoints();
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Admin</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>System health · users &amp; roles · feature flags</div>
        </div>
        <div className="flex items-center gap-2">
          <window.EndpointsButton onClick={ep.openIt}/>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Admin · backend contract"
        subtitle="src/api/routes/admin.py · Admin role required"
        endpoints={window.ENDPOINTS_ADMIN}
        role={role}
      />

      <div className="border-b hairline flex items-center mb-4">
        {["integrations", caps.manageUsers && "users", caps.toggleFlags && "feature flags"].filter(Boolean).map(t => (
          <span key={t} className={"tab " + (tab === t ? "active" : "")} onClick={() => setTab(t)}>
            {t[0].toUpperCase() + t.slice(1)}
          </span>
        ))}
      </div>

      {tab === "integrations" && (
        <div className="grid grid-cols-2 gap-3">
          {window.INTEGRATIONS.map(i => (
            <div key={i.name} className="panel p-4" style={{ borderRadius: 4 }}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <HealthDot status={i.status}/>
                  <span className="ink" style={{ fontSize: 13.5, fontWeight: 600 }}>{i.name}</span>
                  <span className="chip mono" style={{ fontSize: 10 }}>{i.kind}</span>
                </div>
                <Mono className="muted" style={{ fontSize: 11 }}>{i.region}</Mono>
              </div>
              <div className="muted" style={{ fontSize: 11.5 }}>{i.note}</div>
              <div className="grid grid-cols-3 gap-3 mt-3 pt-3 border-t hairline">
                <Mini label="Status" value={
                  <span style={{ color: i.status === "healthy" ? "var(--ok)" : i.status === "degraded" ? "var(--warn)" : i.status === "down" ? "var(--bad)" : "var(--muted)", fontSize: 12, fontWeight: 600 }}>
                    {i.status.toUpperCase()}
                  </span>
                }/>
                <Mini label="Latency p50" value={i.latency_ms ? `${i.latency_ms}ms` : "—"}/>
                <Mini label="Errors (1h)" value={i.status === "degraded" ? "14" : "0"}/>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "users" && (
        <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
          <div className="p-3 border-b hairline flex items-center justify-between">
            <input placeholder="Search users…" style={{ width: 280 }}/>
            {caps.manageUsers && <button className="btn btn-primary"><I name="user-plus" size={13}/> Invite</button>}
          </div>
          <table className="vqms-table">
            <thead><tr><th>User</th><th>Email</th><th>Role</th><th>Status</th><th>Last active</th><th></th></tr></thead>
            <tbody>
              {window.USERS.map(u => (
                <tr key={u.email}>
                  <td>
                    <div className="flex items-center gap-2">
                      <Avatar name={u.name} size={28}/>
                      <div className="ink" style={{ fontSize: 13, fontWeight: 500 }}>{u.name}</div>
                    </div>
                  </td>
                  <td><Mono>{u.email}</Mono></td>
                  <td>
                    <span className="chip" style={{
                      color: u.role === "Admin" ? "var(--accent)" : "var(--ink-2)",
                      borderColor: u.role === "Admin" ? "var(--accent)" : "var(--line-strong)"
                    }}>{u.role}</span>
                  </td>
                  <td>
                    <span className="inline-flex items-center gap-1.5" style={{ fontSize: 12 }}>
                      <span style={{ width: 6, height: 6, borderRadius: 999,
                        background: u.status === "online" ? "var(--ok)" : u.status === "away" ? "var(--warn)" : "var(--subtle)" }}/>
                      {u.status}
                    </span>
                  </td>
                  <td><Mono className="muted">{u.last_active}</Mono></td>
                  <td><button className="btn btn-ghost"><I name="more-horizontal" size={13}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "feature flags" && (
        <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
          <table className="vqms-table">
            <thead><tr><th>Flag</th><th>Scope</th><th>State</th><th>Last changed</th></tr></thead>
            <tbody>
              {window.FEATURE_FLAGS.map(f => (
                <tr key={f.key}>
                  <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{f.key}</Mono></td>
                  <td><span className="chip">{f.scope}</span></td>
                  <td>
                    <Toggle on={f.on} disabled={!caps.toggleFlags}/>
                  </td>
                  <td><Mono className="muted">{f.changed}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

const Toggle = ({ on, disabled }) => (
  <button disabled={disabled} style={{
    width: 32, height: 18, borderRadius: 999,
    background: on ? "var(--accent)" : "var(--line-strong)",
    border: "none", padding: 2, position: "relative", cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? .5 : 1,
    transition: "background 120ms ease"
  }}>
    <span style={{
      display: "block", width: 14, height: 14, borderRadius: 999, background: "white",
      transform: `translateX(${on ? 14 : 0}px)`, transition: "transform 120ms ease",
    }}/>
  </button>
);

// --- Audit log ---

const AuditLog = () => {
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Audit log</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>audit.action_log · all actor / system events · immutable</div>
        </div>
        <div className="flex items-center gap-2">
          <input placeholder="Search…" style={{ width: 240 }}/>
          <button className="btn"><I name="filter" size={13}/> Filter</button>
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="download" size={13}/> Export</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Audit log · backend contract"
        subtitle="src/api/routes/audit.py · append-only · Bedrock anomaly hooks"
        endpoints={window.ENDPOINTS_AUDIT}
        role={role}
      />
      <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
        <table className="vqms-table">
          <thead><tr><th>Timestamp</th><th>Actor</th><th>Action</th><th>Target</th><th>Note</th></tr></thead>
          <tbody>
            {window.AUDIT_LOG.map((a, i) => (
              <tr key={i}>
                <td><Mono className="muted">{a.ts}</Mono></td>
                <td>
                  {a.actor === "system"
                    ? <span className="chip mono" style={{ fontSize: 10.5 }}>system</span>
                    : <Mono>{a.actor}</Mono>}
                </td>
                <td className="ink-2" style={{ fontSize: 12.5 }}>{a.action}</td>
                <td>{a.target === "—" ? <span className="subtle">—</span> : <Mono style={{ color: "var(--accent)" }}>{a.target}</Mono>}</td>
                <td className="muted" style={{ fontSize: 12 }}>{a.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- Triage / Path C ---

const TriageQueue = ({ onOpen }) => {
  const queue = window.QUERIES.filter(q => q.processing_path === "C").slice(0, 8);
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Triage queue</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>Path C · low‑confidence cases awaiting reviewer decision</div>
        </div>
        <div className="flex items-center gap-2">
          <span className="chip"><Mono>{queue.length}</Mono> pending</span>
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="users" size={13}/> Assign me</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Triage queue · backend contract"
        subtitle="src/api/routes/triage.py · Reviewer + Admin only"
        endpoints={window.ENDPOINTS_TRIAGE}
        role={role}
      />

      <div className="grid grid-cols-2 gap-3">
        {queue.map(q => (
          <div key={q.query_id} className="panel p-4 cursor-pointer hover:border-line-strong" style={{ borderRadius: 4, transition: "border-color 120ms" }}
               onClick={() => onOpen(q)}>
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2">
                <Priority p={q.priority}/>
                <Mono style={{ color: "var(--ink)", fontWeight: 600 }}>{q.query_id}</Mono>
                <span className="chip" style={{ color: "var(--warn)", borderColor: "var(--warn)" }}>conf {q.confidence.toFixed(2)}</span>
              </div>
              <Mono className="muted" style={{ fontSize: 11 }}>{relative(q.received_at)}</Mono>
            </div>
            <div className="ink-2 truncate" style={{ fontSize: 13, fontWeight: 500 }}>{q.subject}</div>
            <div className="muted mt-1" style={{ fontSize: 11.5 }}>
              {q.vendor_name} · {q.intent}
            </div>
            <div className="mt-3 pt-3 border-t hairline grid grid-cols-3 gap-2">
              <Mini label="Suggested intent" value={<span style={{ fontSize: 11.5 }}>{q.intent}</span>}/>
              <Mini label="KB cosine" value={<Mono>{q.kb_match.toFixed(2)}</Mono>}/>
              <Mini label="Best path" value={<PathBadge p={q.kb_match > 0.6 ? "A" : "B"} size="sm"/>}/>
            </div>
            <div className="flex items-center gap-2 mt-3">
              <button className="btn btn-accent"><I name="check" size={12}/> Approve</button>
              <button className="btn"><I name="pencil" size={12}/> Correct</button>
              <button className="btn"><I name="route" size={12}/> Force Path B</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- Bulk actions screen ---

const BulkActions = () => {
  const [action, setAction] = React.useState("approve");
  const [filter, setFilter] = React.useState({ status: "DRAFTING", path: "B" });
  const sample = window.QUERIES.filter(q => q.status === filter.status && q.processing_path === filter.path).slice(0, 12);
  const { role } = window.useRole();
  const ep = window.useEndpoints();

  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Bulk actions</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>Apply an action to a filtered slice · preview before confirm</div>
        </div>
        <div className="flex items-center gap-2">
          <window.EndpointsButton onClick={ep.openIt}/>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Bulk actions · backend contract"
        subtitle="async jobs land in Amazon SQS, status polled from /exports/{id}"
        endpoints={window.ENDPOINTS_BULK}
        role={role}
      />

      <div className="grid grid-cols-12 gap-3">
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="1. Pick action"/>
          <div className="flex flex-col gap-2">
            {[
              { k: "approve", icon: "check", label: "Approve drafts", desc: "Send queued resolutions" },
              { k: "reroute", icon: "route", label: "Reroute to team", desc: "Change assigned_team" },
              { k: "escalate", icon: "alert-triangle", label: "Escalate priority", desc: "P3 → P2 / P2 → P1" },
              { k: "close", icon: "archive", label: "Force close", desc: "Mark RESOLVED + auto‑close" },
              { k: "tag", icon: "tag", label: "Add tag", desc: "Apply a label across selection" },
            ].map(o => (
              <label key={o.k} className="flex items-start gap-3 p-3 rounded cursor-pointer"
                     style={{ background: action === o.k ? "var(--accent-soft)" : "transparent", border: "1px solid " + (action === o.k ? "var(--accent)" : "var(--line)") }}>
                <input type="radio" checked={action === o.k} onChange={() => setAction(o.k)} style={{ accentColor: "var(--accent)" }}/>
                <div>
                  <div className="ink" style={{ fontSize: 13, fontWeight: 500 }}><I name={o.icon} size={12} className="mr-1"/> {o.label}</div>
                  <div className="muted" style={{ fontSize: 11.5 }}>{o.desc}</div>
                </div>
              </label>
            ))}
          </div>
        </div>

        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="2. Filter selection"/>
          <div className="flex flex-col gap-3 mt-1">
            <Field2 label="Status">
              <select value={filter.status} onChange={e => setFilter({...filter, status: e.target.value})}>
                {["DRAFTING","ROUTING","ANALYZING","AWAITING_RESOLUTION","PAUSED"].map(s => <option key={s}>{s}</option>)}
              </select>
            </Field2>
            <Field2 label="Path">
              <select value={filter.path} onChange={e => setFilter({...filter, path: e.target.value})}>
                {["A","B","C"].map(p => <option key={p}>{p}</option>)}
              </select>
            </Field2>
            <Field2 label="Vendor tier">
              <select><option>Any</option><option>PLATINUM</option><option>GOLD</option><option>SILVER</option><option>BRONZE</option></select>
            </Field2>
            <Field2 label="Received">
              <select><option>Last 24 hours</option><option>Last 7 days</option><option>Last 30 days</option></select>
            </Field2>
          </div>
          <div className="mt-3 pt-3 border-t hairline">
            <Mono>{sample.length}</Mono> <span className="muted text-[12px]">queries match</span>
          </div>
        </div>

        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="3. Confirm"/>
          <div className="muted mb-3" style={{ fontSize: 12.5 }}>
            You are about to <span className="ink" style={{ fontWeight: 500 }}>{action}</span> across <Mono>{sample.length}</Mono> queries.
            This action will write to <Mono>audit.action_log</Mono> and may trigger downstream events (EventBridge fanout).
          </div>
          <label className="flex items-center gap-2 mb-3" style={{ fontSize: 12 }}>
            <input type="checkbox" style={{ accentColor: "var(--accent)" }}/>
            I understand this action cannot be undone.
          </label>
          <button className="btn btn-accent w-full justify-center"><I name="zap" size={13}/> Run on {sample.length} queries</button>
          <button className="btn w-full justify-center mt-2"><I name="eye" size={13}/> Dry run</button>
        </div>
      </div>

      <div className="mt-3 panel" style={{ borderRadius: 4, overflow: "hidden" }}>
        <div className="p-3 border-b hairline">
          <SectionHead title="Selection preview" desc={`${sample.length} queries match the filter above`}/>
        </div>
        <table className="vqms-table">
          <thead><tr><th>Query</th><th>Vendor</th><th>Subject</th><th>Path</th><th>Status</th><th>Conf.</th></tr></thead>
          <tbody>
            {sample.map(q => (
              <tr key={q.query_id}>
                <td><Mono>{q.query_id}</Mono></td>
                <td className="ink-2">{q.vendor_name}</td>
                <td><div className="truncate" style={{ maxWidth: 320 }}>{q.subject}</div></td>
                <td><PathBadge p={q.processing_path} size="sm"/></td>
                <td><Status s={q.status}/></td>
                <td><ConfidenceBar value={q.confidence}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const Field2 = ({ label, children }) => (
  <div>
    <div className="muted uppercase tracking-wider mb-1" style={{ fontSize: 10 }}>{label}</div>
    {children}
  </div>
);

// --- Login / role-based landing ---

const Login = ({ onSignIn }) => {
  const [role, setRole] = React.useState("Admin");
  return (
    <div className="min-h-screen flex">
      <div className="flex-1 flex items-center justify-center p-12">
        <div className="w-full max-w-md fade-up">
          <div className="flex items-center gap-2 mb-8">
            <Logo size={28}/>
            <span className="ink" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-.01em" }}>VQMS</span>
            <Mono className="muted ml-1" style={{ fontSize: 11 }}>v0.7.4‑rc1</Mono>
          </div>
          <div className="ink" style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-.02em" }}>Sign in</div>
          <div className="muted mt-1.5 mb-6" style={{ fontSize: 13 }}>Vendor Query Management System · Hexaware Technologies</div>

          <div className="flex flex-col gap-3">
            <Field2 label="Email"><input className="w-full" defaultValue="anika.verma@hexaware.com"/></Field2>
            <Field2 label="Password"><input className="w-full" type="password" defaultValue="••••••••••"/></Field2>
            <Field2 label="Role (demo selector)">
              <div className="grid grid-cols-3 gap-2">
                {["Admin","Reviewer","Vendor"].map(r => (
                  <label key={r} className="flex items-center gap-2 p-2 rounded cursor-pointer"
                    style={{ border: "1px solid " + (role === r ? "var(--accent)" : "var(--line)"),
                             background: role === r ? "var(--accent-soft)" : "transparent" }}>
                    <input type="radio" checked={role === r} onChange={() => setRole(r)} style={{ accentColor: "var(--accent)" }}/>
                    <span style={{ fontSize: 12.5 }}>{r}</span>
                  </label>
                ))}
              </div>
            </Field2>
            <button className="btn btn-accent w-full justify-center mt-2" onClick={() => onSignIn(role)}>
              <I name="log-in" size={14}/> Sign in
            </button>
            <button className="btn w-full justify-center"><I name="key" size={13}/> Continue with SSO (Microsoft)</button>
          </div>

          <div className="muted mt-6" style={{ fontSize: 11.5 }}>
            By signing in you agree to the internal acceptable‑use policy. JWT issued via <Mono>POST /auth/login</Mono> with 8h TTL.
          </div>
        </div>
      </div>
      <div className="hidden lg:flex flex-1 items-center justify-center"
           style={{ background: "var(--ink)", color: "var(--bg)", padding: 64 }}>
        <div className="max-w-md">
          <div className="mono" style={{ fontSize: 11, opacity: .6, letterSpacing: ".1em" }}>VENDOR QUERY MANAGEMENT</div>
          <div style={{ fontSize: 32, fontWeight: 600, letterSpacing: "-.02em", marginTop: 12, lineHeight: 1.15 }}>
            Three paths.<br/>One inbox.<br/>
            <span style={{ color: "var(--accent)" }}>Zero dropped queries.</span>
          </div>
          <div className="mt-6" style={{ fontSize: 13.5, opacity: .8, lineHeight: 1.6 }}>
            AI‑resolved, human‑routed, or sent to triage — every vendor email lands in the right place,
            with full audit, SLA tracking, and episodic memory write‑back.
          </div>
          <div className="grid grid-cols-3 gap-4 mt-10">
            <Stat3 v="91.4%" l="Resolution rate"/>
            <Stat3 v="4h 12m" l="Avg response"/>
            <Stat3 v="< 1%" l="DLQ rate"/>
          </div>
        </div>
      </div>
    </div>
  );
};

const Stat3 = ({ v, l }) => (
  <div>
    <div className="mono" style={{ fontSize: 22, fontWeight: 600, color: "var(--bg)" }}>{v}</div>
    <div className="mono" style={{ fontSize: 10.5, opacity: .55, letterSpacing: ".06em", textTransform: "uppercase", marginTop: 4 }}>{l}</div>
  </div>
);

const Logo = ({ size = 24 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <rect x="1" y="1" width="30" height="30" rx="3" fill="var(--ink)"/>
    <path d="M9 10l5 12 4-9 5 9" stroke="var(--accent)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <circle cx="23" cy="22" r="2" fill="var(--accent)"/>
  </svg>
);

Object.assign(window, { Admin, Toggle, AuditLog, TriageQueue, BulkActions, Login, Logo, Field2 });
