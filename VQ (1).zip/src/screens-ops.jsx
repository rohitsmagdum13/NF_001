// Email ingestion / pipeline monitor screen

const EmailMonitor = () => {
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Email ingestion monitor</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>Live pipeline · Microsoft Graph API → Amazon S3 → Amazon SQS → LangGraph</div>
        </div>
        <div className="flex items-center gap-2">
          <span className="chip"><span className="pulse-dot" style={{display:"inline-block",width:6,height:6,background:"var(--ok)",borderRadius:999,marginRight:6}}/>Live · 5s polling</span>
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="rotate-cw" size={13}/> Refresh</button>
          <button className="btn"><I name="play" size={13}/> Reconcile poller</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Email ingestion · backend contract"
        subtitle="health.py + dashboard.py + admin.py · pipeline observability"
        endpoints={window.ENDPOINTS_EMAIL_MONITOR}
        role={role}
      />

      {/* Pipeline visual */}
      <div className="panel p-5 mb-3" style={{ borderRadius: 4 }}>
        <SectionHead title="Ingestion pipeline" desc="Per-stage in / out / errors / median latency · last 60 minutes"/>
        <div className="flex items-stretch gap-2 overflow-x-auto py-2">
          {window.EMAIL_PIPELINE.map((s, i) => (
            <React.Fragment key={s.stage}>
              <div className="panel p-3 flex-1 min-w-[180px]" style={{ borderRadius: 4, background: "var(--bg)" }}>
                <div className="flex items-start justify-between">
                  <div className="ink-2" style={{ fontSize: 12.5, fontWeight: 500 }}>{s.stage}</div>
                  <HealthDot status={s.errors > 0 ? "degraded" : "healthy"}/>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-3">
                  <Mini label="In" value={s.in}/>
                  <Mini label="Out" value={s.out}/>
                  <Mini label="Err" value={s.errors} color={s.errors > 0 ? "var(--bad)" : undefined}/>
                </div>
                <Mono className="muted mt-2 block" style={{ fontSize: 10.5 }}>p50 {s.median_ms}ms</Mono>
              </div>
              {i < window.EMAIL_PIPELINE.length - 1 && (
                <div className="flex items-center"><I name="chevron-right" size={14} className="subtle"/></div>
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-3 mb-3">
        {/* Queue depth */}
        <div className="panel col-span-7" style={{ borderRadius: 4, overflow: "hidden" }}>
          <div className="p-4 border-b hairline">
            <SectionHead title="Amazon SQS queue depth" desc="Visible · in‑flight · DLQ · oldest message age"/>
          </div>
          <table className="vqms-table">
            <thead>
              <tr><th>Queue</th><th>Visible</th><th>In‑flight</th><th>DLQ</th><th>Oldest age</th><th>Throughput / min</th></tr>
            </thead>
            <tbody>
              {window.QUEUES.map(q => (
                <tr key={q.name}>
                  <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{q.name}</Mono></td>
                  <td><Mono>{q.visible}</Mono></td>
                  <td><Mono>{q.in_flight}</Mono></td>
                  <td><Mono style={{ color: q.dlq > 0 ? "var(--bad)" : "var(--ink)" }}>{q.dlq}</Mono></td>
                  <td><Mono className="muted">{q.oldest_age_s > 0 ? formatAge(q.oldest_age_s) : "—"}</Mono></td>
                  <td><Mono>{q.throughput_1m}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* MS Graph status */}
        <div className="panel col-span-5 p-4" style={{ borderRadius: 4 }}>
          <SectionHead title="Microsoft Graph subscription" desc="Webhook health · last 24h"/>
          <div className="grid grid-cols-2 gap-3 mt-2">
            <Stat block label="Active subscription" value="✓ live"/>
            <Stat block label="Expires in" value="3d 14h"/>
            <Stat block label="Notifications (24h)" value="218"/>
            <Stat block label="429s (last hour)" value={<span style={{color:"var(--warn)"}}>14</span>}/>
            <Stat block label="Avg fetch latency" value="2.24s"/>
            <Stat block label="Reconcile lag" value="4m 12s"/>
          </div>
          <div className="mt-4 pt-4 border-t hairline">
            <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10 }}>Subscription URL</div>
            <Mono style={{ fontSize: 11, wordBreak: "break-all" }}>
              https://api.vqms.hexaware.com/webhooks/ms-graph
            </Mono>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-3">
        {/* Recent ingestion */}
        <div className="panel col-span-8" style={{ borderRadius: 4, overflow: "hidden" }}>
          <div className="p-4 border-b hairline">
            <SectionHead title="Recent ingestion" desc="Webhook → vendor identification → SQS"/>
          </div>
          <table className="vqms-table">
            <thead>
              <tr><th>Time</th><th>From</th><th>Subject</th><th>Vendor match</th><th>Outcome</th><th style={{textAlign:"right"}}>Lat.</th></tr>
            </thead>
            <tbody>
              {RECENT_INGEST.map((r, i) => (
                <tr key={i}>
                  <td><Mono className="muted" style={{fontSize:11}}>{r.ts}</Mono></td>
                  <td><Mono className="ink-2" style={{fontSize:11.5}}>{r.from}</Mono></td>
                  <td><span className="ink-2" style={{fontSize:12.5}}>{r.subject}</span></td>
                  <td>{r.vendor === "—" ? <span className="subtle">— no match</span> : <Mono>{r.vendor}</Mono>}</td>
                  <td>
                    {r.outcome === "enqueued" && <span className="chip" style={{color:"var(--ok)",borderColor:"var(--ok)"}}>Enqueued</span>}
                    {r.outcome === "filtered" && <span className="chip">Filtered (noise)</span>}
                    {r.outcome === "ocr"      && <span className="chip" style={{color:"var(--info)",borderColor:"var(--info)"}}>OCR running</span>}
                    {r.outcome === "error"    && <span className="chip" style={{color:"var(--bad)",borderColor:"var(--bad)"}}>Error</span>}
                  </td>
                  <td style={{textAlign:"right"}}><Mono className="muted">{r.lat}ms</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Errors panel */}
        <div className="panel col-span-4 p-4" style={{ borderRadius: 4 }}>
          <SectionHead title="Processing errors" desc="Last 24h · grouped by stage"/>
          <div className="flex flex-col gap-2 mt-1">
            {[
              { stage: "Attachment processor", n: 3, latest: "12m ago", note: "Textract async timeout > 5min" },
              { stage: "Vendor identifier",    n: 0, latest: "—",       note: "no errors" },
              { stage: "Thread correlator",    n: 0, latest: "—",       note: "no errors" },
              { stage: "S3 put",               n: 1, latest: "4h ago",  note: "AccessDenied (transient)" },
            ].map(e => (
              <div key={e.stage} className="flex items-start gap-3 p-3 rounded" style={{ background: e.n > 0 ? "color-mix(in oklch, var(--bad) 6%, var(--panel))" : "var(--bg)" }}>
                <I name={e.n > 0 ? "alert-circle" : "check-circle"} size={14} style={{ color: e.n > 0 ? "var(--bad)" : "var(--ok)", marginTop: 1 }}/>
                <div className="flex-1">
                  <div className="ink-2 flex items-center gap-2" style={{ fontSize: 12.5 }}>
                    {e.stage}
                    {e.n > 0 && <Mono style={{ color: "var(--bad)", fontWeight: 600 }}>{e.n}</Mono>}
                  </div>
                  <div className="muted" style={{ fontSize: 11 }}>{e.note} · {e.latest}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const Mini = ({ label, value, color }) => (
  <div>
    <div className="muted uppercase tracking-wider" style={{ fontSize: 9.5 }}>{label}</div>
    <Mono style={{ fontSize: 14, fontWeight: 600, color: color || "var(--ink)" }}>{value}</Mono>
  </div>
);

function formatAge(s) {
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s/60)}m ${s%60}s`;
  return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`;
}

const RECENT_INGEST = [
  { ts: "14:22:51", from: "billing@cloudwave.io",     subject: "Re: Invoice INV-88241 short paid by $1,847", vendor: "V-001", outcome: "enqueued", lat: 142 },
  { ts: "14:21:38", from: "ops@northwindlog.com",     subject: "Q1 2026 statement does not match remittance", vendor: "V-002", outcome: "enqueued", lat: 167 },
  { ts: "14:20:14", from: "noreply@mailchimp.com",    subject: "Your weekly newsletter is here",              vendor: "—",     outcome: "filtered", lat: 28 },
  { ts: "14:19:02", from: "rk@sigmadata.ai",          subject: "PO 4419821 partial shipment, do we re-bill?", vendor: "V-003", outcome: "enqueued", lat: 184 },
  { ts: "14:17:44", from: "billing@helios.print",     subject: "Scanned invoice — please process",            vendor: "V-004", outcome: "ocr",      lat: 1840 },
  { ts: "14:16:33", from: "g.lindqvist@northwindlog.com", subject: "Updated banking details — confirm",       vendor: "V-002", outcome: "enqueued", lat: 156 },
  { ts: "14:15:12", from: "unknown@gmail.com",        subject: "Hi, are you the right person?",               vendor: "—",     outcome: "filtered", lat: 33 },
  { ts: "14:13:08", from: "j.kowalski@helios.print",  subject: "W-9 expired, need updated copy on file",      vendor: "V-004", outcome: "enqueued", lat: 138 },
];

// --- Knowledge base / embeddings explorer ---

const KnowledgeBase = () => {
  const [q, setQ] = React.useState("");
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  const filtered = window.KB_ARTICLES.filter(a => !q || a.title.toLowerCase().includes(q.toLowerCase()) || a.id.includes(q));
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Knowledge base &amp; embeddings</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>memory.embedding_index · pgvector 0.7.0 · Titan Embed v2 (1536‑dim)</div>
        </div>
        <div className="flex items-center gap-2">
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="upload" size={13}/> Index article</button>
          <button className="btn btn-primary"><I name="plus" size={13}/> Re‑embed all</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Knowledge base · backend contract"
        subtitle="src/api/routes/kb.py · pgvector + Amazon Bedrock Titan Embed v2"
        endpoints={window.ENDPOINTS_KB}
        role={role}
      />

      <div className="grid grid-cols-12 gap-3 mb-3">
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10 }}>Index size</div>
          <div className="ink" style={{ fontSize: 26, fontWeight: 600 }}>{window.KB_ARTICLES.length}</div>
          <div className="muted" style={{ fontSize: 11 }}>articles · 1,536 dimensions each</div>
        </div>
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10 }}>Avg cosine on hit</div>
          <div className="ink" style={{ fontSize: 26, fontWeight: 600 }}>0.84</div>
          <div className="muted" style={{ fontSize: 11 }}>retrieval threshold ≥ 0.80</div>
        </div>
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10 }}>KB‑hit rate (Path A)</div>
          <div className="ink" style={{ fontSize: 26, fontWeight: 600, color: "var(--ok)" }}>91.2%</div>
          <div className="muted" style={{ fontSize: 11 }}>last 30 days</div>
        </div>
      </div>

      {/* Search probe */}
      <div className="panel p-4 mb-3" style={{ borderRadius: 4 }}>
        <SectionHead title="Probe similarity" desc="Test what the retriever returns for a hypothetical query"/>
        <div className="flex items-center gap-2">
          <input className="flex-1" placeholder='e.g. "vendor wants to update bank account"'/>
          <button className="btn btn-accent"><I name="zap" size={13}/> Embed &amp; search</button>
        </div>
      </div>

      <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
        <div className="p-3 border-b hairline flex items-center justify-between">
          <input placeholder="Filter articles…" value={q} onChange={e => setQ(e.target.value)} style={{ width: 280 }}/>
          <Mono className="muted">{filtered.length} articles</Mono>
        </div>
        <table className="vqms-table">
          <thead>
            <tr><th>Article</th><th>Last updated</th><th>Uses (30d)</th><th>Hit rate</th><th>Embedding</th></tr>
          </thead>
          <tbody>
            {filtered.map(a => (
              <tr key={a.id}>
                <td>
                  <div className="ink-2" style={{ fontSize: 12.5, fontWeight: 500 }}>{a.title}</div>
                  <Mono className="muted" style={{ fontSize: 10.5 }}>{a.id}</Mono>
                </td>
                <td><Mono className="muted" style={{ fontSize: 11.5 }}>{a.last_updated}</Mono></td>
                <td><Mono>{a.uses_30d}</Mono></td>
                <td><ConfidenceBar value={a.hit_rate} threshold={0.80}/></td>
                <td>
                  <div className="flex items-center gap-0.5">
                    {Array.from({ length: 24 }).map((_, i) => (
                      <span key={i} style={{
                        width: 3, height: 12 + (Math.sin(i * a.hit_rate * 7) * 4),
                        background: `oklch(${65 + (i * 7) % 25}% .12 ${(i * 21 + a.id.charCodeAt(3)) % 360})`,
                        borderRadius: 1, display: "inline-block"
                      }}/>
                    ))}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

Object.assign(window, { EmailMonitor, KnowledgeBase });
