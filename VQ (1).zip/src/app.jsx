// App shell — sidebar, topbar, routing

// Role-based access control matrix.
// Roles match the JWT model in src/api/middleware/auth_middleware.py: ADMIN, REVIEWER, VENDOR.
// (No "Vendor manager" — that role doesn't exist in the codebase.)
const ROLE_NAV = {
  "Admin":    ["overview","inbox","mail","triage","vendors","email","kb","bulk","audit","admin"],
  "Reviewer": ["overview","triage","kb"],
};

const NAV = [
  { id: "overview",   label: "Overview",        icon: "layout-dashboard" },
  { id: "inbox",      label: "Query inbox",     icon: "inbox", badge: () => window.QUERIES.filter(q => !["RESOLVED","CLOSED","MERGED_INTO_PARENT"].includes(q.status)).length },
  { id: "mail",       label: "Email management",icon: "mail-search", badge: () => window.MAIL_THREADS.filter(r => r._direction === "inbound" && r._status === "unread").length },
  { id: "triage",     label: "Triage queue",    icon: "user-check", badge: () => window.QUERIES.filter(q => q.processing_path === "C" && q.status === "PAUSED").length },
  { id: "vendors",    label: "Vendors",         icon: "building-2" },
  { id: "email",      label: "Email pipeline",  icon: "mail" },
  { id: "kb",         label: "Knowledge base",  icon: "book-open" },
  { id: "bulk",       label: "Bulk actions",    icon: "list-checks" },
  { id: "audit",      label: "Audit log",       icon: "scroll-text" },
  { id: "admin",      label: "Admin",           icon: "shield" },
];

// Capabilities — match what each role's JWT actually permits.
// Admin: every /admin/* route + /triage + /copilot/triage. Reviewer: /triage + /copilot/triage only.
const CAPS = {
  "Admin":    { approve: true,  reroute: true,  escalate: true,  bulk: true,  editVendor: true,  manageUsers: true,  toggleFlags: true,  forceClose: true,  copilot: true },
  "Reviewer": { approve: false, reroute: false, escalate: false, bulk: false, editVendor: false, manageUsers: false, toggleFlags: false, forceClose: false, copilot: true,
                // Reviewer can submit a triage decision (POST /triage/{id}/review) — that's the one mutation.
                triageDecide: true },
};

// Make role available to nested screens that need to gate buttons.
window.RoleContext = React.createContext({ role: "Admin", caps: CAPS["Admin"] });
const useRole = () => React.useContext(window.RoleContext);
window.useRole = useRole;

const App = () => {
  const [authed, setAuthed] = React.useState(false);
  const [role, setRole] = React.useState("Admin");
  const [view, setView] = React.useState("overview");
  const [vendorFocus, setVendorFocus] = React.useState(null);
  const [openQuery, setOpenQuery] = React.useState(null);
  const [dark, setDark] = React.useState(false);
  const [paletteOpen, setPaletteOpen] = React.useState(false);

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  React.useEffect(() => {
    if (window.lucide && window.lucide.createIcons) window.lucide.createIcons();
  });

  React.useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") { e.preventDefault(); setPaletteOpen(true); }
      if (e.key === "Escape") { setPaletteOpen(false); setOpenQuery(null); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  if (!authed) return <Login onSignIn={(r) => { setRole(r); setAuthed(true); setView(r === "Vendor" ? "vendor-portal" : "overview"); }}/>;

  if (role === "Vendor" || view === "vendor-portal") {
    return <VendorPortal onSignOut={() => { setAuthed(false); setRole("Admin"); setView("overview"); }}/>;
  }

  const allowed = ROLE_NAV[role] || ROLE_NAV["Admin"];
  const navItems = NAV.filter(n => allowed.includes(n.id));
  const caps = CAPS[role] || CAPS["Admin"];
  const canAccess = (v) => allowed.includes(v);

  return (
    <window.RoleContext.Provider value={{ role, caps }}>
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="flex flex-col border-r hairline" style={{ width: 232, background: "var(--panel)" }}>
        <div className="px-4 py-4 border-b hairline">
          <div className="flex items-center gap-2">
            <Logo size={22}/>
            <span className="ink" style={{ fontSize: 14, fontWeight: 600, letterSpacing: "-.01em" }}>VQMS</span>
            <Mono className="muted ml-auto" style={{ fontSize: 10 }}>v0.7.4</Mono>
          </div>
          <div className="muted mt-2" style={{ fontSize: 10.5, letterSpacing: ".06em", textTransform: "uppercase" }}>Hexaware · prod</div>
        </div>

        {/* Search bar */}
        <div className="p-3">
          <button className="w-full flex items-center gap-2 px-2.5 py-1.5"
            style={{ background: "var(--bg)", border: "1px solid var(--line)", borderRadius: 4, fontSize: 12, color: "var(--muted)" }}
            onClick={() => setPaletteOpen(true)}>
            <I name="search" size={13}/>
            <span>Search…</span>
            <Mono className="ml-auto" style={{ fontSize: 10 }}>⌘K</Mono>
          </button>
        </div>

        <nav className="flex-1 px-2 overflow-y-auto">
          {navItems.map(n => {
            const b = n.badge && n.badge();
            return (
              <div key={n.id} className={"nav-item " + (view === n.id ? "active" : "")} onClick={() => { setView(n.id); setVendorFocus(null); }}>
                <I name={n.icon} size={14}/>
                <span className="flex-1">{n.label}</span>
                {b !== undefined && b > 0 && (
                  <Mono style={{ fontSize: 10.5, padding: "1px 6px", background: view === n.id ? "var(--accent)" : "var(--line)",
                                color: view === n.id ? "white" : "var(--muted)", borderRadius: 999 }}>
                    {b}
                  </Mono>
                )}
              </div>
            );
          })}
        </nav>

        {/* User + dark mode */}
        <div className="p-3 border-t hairline">
          <div className="flex items-center gap-2">
            <Avatar name="Anika Verma" size={28}/>
            <div className="flex-1 min-w-0">
              <div className="ink truncate" style={{ fontSize: 12.5, fontWeight: 500 }}>Anika Verma</div>
              <Mono className="muted" style={{ fontSize: 10 }}>{role}</Mono>
            </div>
            <button className="btn btn-ghost" onClick={() => setDark(!dark)} title="Toggle dark mode">
              <I name={dark ? "sun" : "moon"} size={13}/>
            </button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar */}
        <div className="flex items-center justify-between px-6 py-2.5 border-b hairline" style={{ background: "var(--panel)" }}>
          <div className="flex items-center gap-2 muted" style={{ fontSize: 12 }}>
            <span className="ink-2">VQMS</span>
            <I name="chevron-right" size={11}/>
            <span>{NAV.find(n => n.id === view)?.label || "Vendor"}</span>
            {view === "vendors" && vendorFocus && <>
              <I name="chevron-right" size={11}/>
              <span className="ink">{window.VENDORS.find(v => v.vendor_id === vendorFocus)?.name}</span>
            </>}
          </div>
          <div className="flex items-center gap-2">
            <span className="chip" style={{
              background: role === "Admin" ? "var(--accent-soft)" : role === "Reviewer" ? "color-mix(in oklch, var(--info) 12%, var(--panel))" : "var(--bg)",
              color: role === "Admin" ? "var(--accent)" : role === "Reviewer" ? "var(--info)" : "var(--ink-2)",
              borderColor: "transparent"
            }}><I name="user" size={10}/> {role}</span>
            <span className="chip"><span className="pulse-dot" style={{display:"inline-block",width:6,height:6,background:"var(--ok)",borderRadius:999,marginRight:6}}/>All systems operational</span>
            <button className="btn btn-ghost" onClick={() => setPaletteOpen(true)}><I name="search" size={13}/></button>
            <button className="btn btn-ghost"><I name="bell" size={13}/></button>
            <button className="btn btn-ghost" onClick={() => setDark(!dark)}><I name={dark ? "sun" : "moon"} size={13}/></button>
            <button className="btn btn-ghost" onClick={() => { setAuthed(false); setRole("Admin"); setView("overview"); }} title="Sign out"><I name="log-out" size={13}/></button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto bg-bg">
          {!canAccess(view) ? <Forbidden role={role} view={view} onGoHome={() => setView(allowed[0] || "overview")}/> : <>
          {view === "overview" && <Overview/>}
          {view === "inbox"    && <Inbox onOpen={setOpenQuery}/>}
          {view === "triage"   && <TriageQueue onOpen={setOpenQuery}/>}
          {view === "vendors"  && (
            vendorFocus
              ? <Vendor360 vendor_id={vendorFocus} onBack={() => setVendorFocus(null)} onOpenQuery={setOpenQuery}/>
              : <VendorList onOpen={setVendorFocus}/>
          )}
          {view === "mail"     && <Mail/>}
          {view === "email"    && <EmailMonitor/>}
          {view === "kb"       && <KnowledgeBase/>}
          {view === "bulk"     && <BulkActions/>}
          {view === "audit"    && <AuditLog/>}
          {view === "admin"    && <Admin/>}
          </>}
        </div>
      </main>

      {openQuery && <QueryDetail query={openQuery} onClose={() => setOpenQuery(null)}/>}

      {paletteOpen && <CommandPalette onClose={() => setPaletteOpen(false)} allowed={allowed} onJump={(v, vid) => {
        setView(v);
        if (vid) setVendorFocus(vid);
        setPaletteOpen(false);
      }} onOpenQuery={(q) => { setOpenQuery(q); setPaletteOpen(false); }}/>}
    </div>
    </window.RoleContext.Provider>
  );
};

const Forbidden = ({ role, view, onGoHome }) => (
  <div className="flex items-center justify-center" style={{ minHeight: 480 }}>
    <div className="text-center fade-up" style={{ maxWidth: 380 }}>
      <div style={{ width: 56, height: 56, borderRadius: 999, background: "color-mix(in oklch, var(--bad) 12%, var(--panel))",
                    display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
        <I name="lock" size={22} style={{ color: "var(--bad)" }}/>
      </div>
      <div className="ink" style={{ fontSize: 18, fontWeight: 600, letterSpacing: "-.01em" }}>Access restricted</div>
      <div className="muted mt-1.5" style={{ fontSize: 13 }}>
        Your role <Mono style={{ color: "var(--ink)", fontWeight: 600 }}>{role}</Mono> does not have permission to view <Mono>{view}</Mono>.
        Contact an administrator if you need access.
      </div>
      <button className="btn btn-accent mt-5" onClick={onGoHome}><I name="arrow-left" size={13}/> Back to allowed area</button>
    </div>
  </div>
);

window.Forbidden = Forbidden;

// --- Vendor list ---

const VendorList = ({ onOpen }) => {
  const [search, setSearch] = React.useState("");
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  const list = window.VENDORS.filter(v => !search || v.name.toLowerCase().includes(search.toLowerCase()) || v.vendor_id.includes(search));
  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 20, fontWeight: 600, letterSpacing: "-.02em" }}>Vendors</div>
          <div className="muted mt-1" style={{ fontSize: 12.5 }}>{window.VENDORS.length} active · sourced from Salesforce <Mono>Vendor_Account__c</Mono></div>
        </div>
        <div className="flex items-center gap-2">
          <input placeholder="Search vendors…" value={search} onChange={e => setSearch(e.target.value)} style={{ width: 240 }}/>
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="download" size={13}/> Export</button>
          <button className="btn btn-primary"><I name="plus" size={13}/> New vendor</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Vendors · backend contract"
        subtitle="src/api/routes/vendors.py · synced from Salesforce every 5 min"
        endpoints={window.ENDPOINTS_VENDORS}
        role={role}
      />

      <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
        <table className="vqms-table">
          <thead>
            <tr><th>Vendor</th><th>Tier</th><th>Category</th><th>Region</th><th>Open queries</th><th>Health</th><th>SLA</th><th style={{textAlign:"right"}}>Annual rev.</th></tr>
          </thead>
          <tbody>
            {list.map(v => (
              <tr key={v.vendor_id} onClick={() => onOpen(v.vendor_id)}>
                <td>
                  <div className="flex items-center gap-3">
                    <Avatar name={v.name} size={28}/>
                    <div>
                      <div className="ink" style={{ fontSize: 13, fontWeight: 500 }}>{v.name}</div>
                      <Mono className="muted" style={{ fontSize: 10.5 }}>{v.vendor_id} · {v.website}</Mono>
                    </div>
                  </div>
                </td>
                <td><Tier tier={v.tier}/></td>
                <td className="ink-2" style={{ fontSize: 12.5 }}>{v.category}</td>
                <td className="muted" style={{ fontSize: 12 }}>{v.city}, {v.country}</td>
                <td>
                  <span style={{ fontSize: 12.5 }}>
                    <Mono style={{ fontWeight: 600 }}>{v.open_queries}</Mono>
                    {v.p1_open > 0 && <span style={{ color: "var(--bad)", marginLeft: 6 }}>· <Mono>{v.p1_open}P1</Mono></span>}
                  </span>
                </td>
                <td>
                  <div className="flex items-center gap-2">
                    <Donut pct={v.health}/>
                    <Mono style={{ color: v.health > 85 ? "var(--ok)" : v.health > 70 ? "var(--warn)" : "var(--bad)", fontWeight: 600 }}>{v.health}</Mono>
                  </div>
                </td>
                <td><Mono className="muted">{v.sla_response_hours}h / {v.sla_resolution_days}d</Mono></td>
                <td style={{ textAlign: "right" }}><Mono>${(v.annual_revenue/1_000_000).toFixed(1)}M</Mono></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// --- Command palette ---

const CommandPalette = ({ onClose, onJump, onOpenQuery, allowed = NAV.map(n => n.id) }) => {
  const [q, setQ] = React.useState("");
  const inputRef = React.useRef(null);
  React.useEffect(() => { inputRef.current && inputRef.current.focus(); }, []);

  const items = React.useMemo(() => {
    const out = [];
    NAV.filter(n => allowed.includes(n.id)).forEach(n => out.push({ kind: "nav", id: n.id, label: n.label, icon: n.icon }));
    window.VENDORS.forEach(v => out.push({ kind: "vendor", id: v.vendor_id, label: v.name, sub: v.vendor_id, icon: "building-2" }));
    window.QUERIES.slice(0, 30).forEach(qr => out.push({ kind: "query", id: qr.query_id, label: qr.query_id, sub: qr.subject, icon: "inbox", obj: qr }));
    if (!q) return out.slice(0, 14);
    const s = q.toLowerCase();
    return out.filter(i => i.label.toLowerCase().includes(s) || (i.sub && i.sub.toLowerCase().includes(s))).slice(0, 14);
  }, [q, allowed]);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-[12vh]" style={{ background: "rgba(0,0,0,.4)" }} onClick={onClose}>
      <div className="panel w-[600px] max-w-[92vw] fade-up" style={{ borderRadius: 6, overflow: "hidden", boxShadow: "0 20px 50px rgba(0,0,0,.18)" }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-4 py-3 border-b hairline">
          <I name="search" size={15} className="muted"/>
          <input ref={inputRef} className="flex-1 border-0 outline-none" style={{ background: "transparent", fontSize: 14, padding: 0 }}
            placeholder="Search queries, vendors, screens…" value={q} onChange={e => setQ(e.target.value)}/>
          <Mono className="muted" style={{ fontSize: 10 }}>esc</Mono>
        </div>
        <div className="max-h-[50vh] overflow-y-auto p-1">
          {items.map((it, i) => (
            <div key={i} className="nav-item" onClick={() => {
              if (it.kind === "nav") onJump(it.id);
              else if (it.kind === "vendor") onJump("vendors", it.id);
              else if (it.kind === "query") onOpenQuery(it.obj);
            }}>
              <I name={it.icon} size={13} className="muted"/>
              <div className="flex-1">
                <div className="ink-2" style={{ fontSize: 13 }}>{it.label}</div>
                {it.sub && <div className="muted" style={{ fontSize: 11.5 }}>{it.sub}</div>}
              </div>
              <Mono className="muted" style={{ fontSize: 10 }}>{it.kind}</Mono>
            </div>
          ))}
          {items.length === 0 && <div className="muted text-center py-8" style={{ fontSize: 12 }}>No results</div>}
        </div>
      </div>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
