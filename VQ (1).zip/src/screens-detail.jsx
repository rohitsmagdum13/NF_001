// Query detail drawer

const QueryDetail = ({ query, onClose }) => {
  const [tab, setTab] = React.useState("thread");
  const [draftEdit, setDraftEdit] = React.useState(false);
  const [draft, setDraft] = React.useState(window.AI_SUGGESTED);
  const v = window.VENDORS.find(x => x.vendor_id === query.vendor_id);
  const { caps, role } = window.useRole();

  return (
    <Drawer open={!!query} onClose={onClose} width={920}>
      {/* Header */}
      <div className="border-b hairline px-6 py-4 sticky top-0 bg-panel z-10">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Priority p={query.priority}/>
              <Mono style={{ color: "var(--ink)", fontWeight: 600, fontSize: 13 }}>{query.query_id}</Mono>
              <Status s={query.status}/>
              <PathBadge p={query.processing_path} size="sm"/>
              {query.ticket_id && <span className="chip mono"><I name="link-2" size={10}/> {query.ticket_id}</span>}
            </div>
            <div className="ink" style={{ fontSize: 17, fontWeight: 600, letterSpacing: "-.01em" }}>{query.subject}</div>
            <div className="muted mt-1.5 flex items-center gap-2 flex-wrap" style={{ fontSize: 12 }}>
              <span>{v.name}</span>
              <Tier tier={v.tier}/>
              <span>·</span>
              <Mono>{query.vendor_id}</Mono>
              <span>·</span>
              <span>{query.intent}</span>
              <span>·</span>
              <Mono>{relative(query.received_at)}</Mono>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button className="btn btn-ghost" title="Copy link"><I name="link" size={13}/></button>
            <button className="btn btn-ghost" title="More"><I name="more-horizontal" size={13}/></button>
            <button className="btn btn-ghost" onClick={onClose} title="Close"><I name="x" size={14}/></button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center mt-4 -mb-px">
          {["thread","ai-response","metadata","audit"].map(t => (
            <span key={t} className={"tab " + (tab === t ? "active" : "")} onClick={() => setTab(t)}>
              {{thread: "Thread", "ai-response": "AI response", metadata: "Pipeline metadata", audit: "Audit trail"}[t]}
              {t === "thread" && <Mono className="ml-1.5 muted">2</Mono>}
              {t === "ai-response" && <Mono className="ml-1.5 muted">{query.confidence.toFixed(2)}</Mono>}
            </span>
          ))}
        </div>
      </div>

      {/* Body */}
      <div className="px-6 py-5 grid grid-cols-3 gap-5">
        {/* Main column */}
        <div className="col-span-2">
          {tab === "thread" && (
            <div className="flex flex-col gap-3">
              {window.SAMPLE_THREAD.map((m, i) => (
                m.direction === "system" ? (
                  <div key={i} className="flex items-center gap-2 py-2">
                    <span style={{ width: 6, height: 6, background: "var(--accent)", borderRadius: 999 }}/>
                    <Mono className="muted" style={{ fontSize: 11 }}>{m.ts}</Mono>
                    <span className="muted" style={{ fontSize: 11.5 }}>{m.note}</span>
                  </div>
                ) : (
                  <div key={i} className="panel p-4" style={{ borderRadius: 4 }}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Avatar name="Marcus Holloway" size={28}/>
                        <div>
                          <div className="ink" style={{ fontSize: 12.5, fontWeight: 500 }}>Marcus Holloway</div>
                          <Mono className="muted" style={{ fontSize: 10.5 }}>{m.from}</Mono>
                        </div>
                      </div>
                      <Mono className="muted" style={{ fontSize: 11 }}>{m.ts}</Mono>
                    </div>
                    <div className="ink-2" style={{ fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap", textWrap: "pretty" }}>{m.body}</div>
                    {m.attachments && m.attachments.length > 0 && (
                      <div className="mt-3 pt-3 border-t hairline flex items-center gap-2 flex-wrap">
                        {m.attachments.map(a => (
                          <span key={a.name} className="chip" style={{ padding: "4px 10px" }}>
                            <I name="paperclip" size={11}/> {a.name} <span className="muted">· {a.size}</span>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )
              ))}
            </div>
          )}

          {tab === "ai-response" && (
            <div>
              <div className="panel p-4 mb-3" style={{ borderRadius: 4, borderColor: "var(--accent)", borderWidth: 1 }}>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <I name="sparkles" size={14} className="text-accent"/>
                    <span className="ink" style={{ fontSize: 13, fontWeight: 600 }}>Suggested response</span>
                    <span className="chip mono" style={{ fontSize: 10 }}>claude‑sonnet‑3.5</span>
                  </div>
                  <button className="btn btn-ghost" onClick={() => setDraftEdit(!draftEdit)}>
                    <I name={draftEdit ? "check" : "pencil"} size={13}/> {draftEdit ? "Done" : "Edit"}
                  </button>
                </div>
                {draftEdit ? (
                  <textarea value={draft} onChange={e => setDraft(e.target.value)}
                    style={{ width: "100%", minHeight: 240, fontFamily: "inherit", fontSize: 13, lineHeight: 1.55 }}/>
                ) : (
                  <div className="ink-2" style={{ fontSize: 13, lineHeight: 1.65, whiteSpace: "pre-wrap", textWrap: "pretty" }}>{draft}</div>
                )}
                <div className="grid grid-cols-3 gap-3 mt-4 pt-4 border-t hairline" style={{ fontSize: 11.5 }}>
                  <div>
                    <div className="muted uppercase tracking-wider mb-1" style={{ fontSize: 10 }}>Confidence</div>
                    <ConfidenceBar value={query.confidence}/>
                  </div>
                  <div>
                    <div className="muted uppercase tracking-wider mb-1" style={{ fontSize: 10 }}>KB Match (cosine)</div>
                    <ConfidenceBar value={query.kb_match} threshold={0.80}/>
                  </div>
                  <div>
                    <div className="muted uppercase tracking-wider mb-1" style={{ fontSize: 10 }}>Quality Gate</div>
                    <span className="chip" style={{ color: "var(--ok)", borderColor: "var(--ok)" }}><I name="check" size={11}/> 7/7 passed</span>
                  </div>
                </div>
              </div>

              <div className="panel p-4" style={{ borderRadius: 4 }}>
                <SectionHead title="Sources used" desc="Retrieved from memory.embedding_index"/>
                {window.SOURCES_USED.map(s => (
                  <div key={s.kb_id} className="flex items-center gap-3 py-2 border-b hairline last:border-0">
                    <I name="book-open" size={14} className="muted"/>
                    <div className="flex-1">
                      <div className="ink-2" style={{ fontSize: 12.5 }}>{s.title}</div>
                      <Mono className="muted" style={{ fontSize: 10.5 }}>{s.kb_id}</Mono>
                    </div>
                    <Mono>{s.cosine.toFixed(2)}</Mono>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab === "metadata" && (
            <div className="panel p-5" style={{ borderRadius: 4 }}>
              <div className="grid grid-cols-2 gap-x-6 gap-y-3" style={{ fontSize: 12.5 }}>
                <MetaRow label="execution_id" value={<Mono>{query.execution_id}</Mono>}/>
                <MetaRow label="correlation_id" value={<Mono>{query.correlation_id}</Mono>}/>
                <MetaRow label="source" value={query.source}/>
                <MetaRow label="received_at" value={<Mono>{query.received_at}</Mono>}/>
                <MetaRow label="processing_path" value={<PathBadge p={query.processing_path} size="sm"/>}/>
                <MetaRow label="assigned_team" value={query.assigned_team}/>
                <MetaRow label="ticket_id" value={query.ticket_id ? <Mono>{query.ticket_id}</Mono> : <span className="subtle">—</span>}/>
                <MetaRow label="confidence" value={<Mono>{query.confidence}</Mono>}/>
                <MetaRow label="kb_cosine" value={<Mono>{query.kb_match}</Mono>}/>
                <MetaRow label="sla_deadline" value={query.sla_pct ? <Mono>{query.sla_deadline_min}m left ({query.sla_pct}%)</Mono> : <span className="subtle">—</span>}/>
              </div>

              <div className="mt-5 pt-4 border-t hairline">
                <div className="muted uppercase tracking-wider mb-3" style={{ fontSize: 10.5 }}>State machine trace</div>
                <div className="flex items-center gap-1.5 flex-wrap mono" style={{ fontSize: 11 }}>
                  {["entry","context_loading","query_analysis","confidence_check","routing","kb_search","path_decision","resolution","quality_gate","delivery"].map((n, i, arr) => (
                    <React.Fragment key={n}>
                      <span className="chip" style={{
                        background: query.processing_path === "C" && i >= 4 ? "var(--bg)" : "color-mix(in oklch, var(--ok) 12%, var(--panel))",
                        color: query.processing_path === "C" && i >= 4 ? "var(--muted)" : "var(--ok)",
                        borderColor: "transparent"
                      }}>{n}</span>
                      {i < arr.length - 1 && <I name="chevron-right" size={10} className="subtle"/>}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          )}

          {tab === "audit" && (
            <div className="panel" style={{ borderRadius: 4 }}>
              {window.AUDIT_LOG.filter(a => a.target === query.query_id || a.target === "—" || Math.random() > 0.5).slice(0, 6).map((a, i) => (
                <div key={i} className="flex items-start gap-3 px-4 py-3 border-b hairline last:border-0">
                  <Mono className="muted" style={{ fontSize: 11, minWidth: 130 }}>{a.ts}</Mono>
                  <div className="flex-1">
                    <div className="ink-2" style={{ fontSize: 12.5 }}>{a.action}</div>
                    <div className="muted" style={{ fontSize: 11 }}>{a.note}</div>
                  </div>
                  <Mono className="muted" style={{ fontSize: 11 }}>{a.actor}</Mono>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Side column */}
        <div className="col-span-1 flex flex-col gap-4">
          {/* Actions */}
          <div className="panel p-4" style={{ borderRadius: 4 }}>
            <div className="flex items-center justify-between mb-3">
              <div className="ink" style={{ fontSize: 12.5, fontWeight: 600 }}>Actions</div>
              <Mono className="muted" style={{ fontSize: 10 }}>as {role}</Mono>
            </div>
            <div className="flex flex-col gap-2">
              {caps.approve  && <button className="btn btn-accent justify-center"><I name="send" size={13}/> Approve & send</button>}
              {caps.approve  && <button className="btn justify-center"><I name="pencil" size={13}/> Edit & send</button>}
              {caps.reroute  && <button className="btn justify-center"><I name="route" size={13}/> Reroute</button>}
              {caps.escalate && <button className="btn justify-center"><I name="alert-triangle" size={13}/> Escalate</button>}
              {caps.approve  && <button className="btn justify-center" style={{ color: "var(--bad)" }}><I name="x-circle" size={13}/> Reject draft</button>}
              {!caps.approve && !caps.reroute && !caps.escalate && (
                <div className="muted" style={{ fontSize: 12 }}>
                  <I name="lock" size={11} className="inline-block mr-1"/>
                  Read-only access for this query.
                </div>
              )}
            </div>
          </div>

          {/* Vendor mini */}
          <div className="panel p-4" style={{ borderRadius: 4 }}>
            <div className="flex items-center justify-between mb-3">
              <div className="ink" style={{ fontSize: 12.5, fontWeight: 600 }}>Vendor</div>
              <button className="btn btn-ghost"><I name="external-link" size={12}/></button>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <Avatar name={v.name} size={36}/>
              <div>
                <div className="ink" style={{ fontSize: 13, fontWeight: 500 }}>{v.name}</div>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <Tier tier={v.tier}/>
                  <Mono className="muted" style={{ fontSize: 10.5 }}>{v.vendor_id}</Mono>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-x-3 gap-y-2" style={{ fontSize: 11.5 }}>
              <Field label="Category" value={v.category}/>
              <Field label="Tier SLA" value={`${v.sla_response_hours}h / ${v.sla_resolution_days}d`}/>
              <Field label="Open queries" value={`${v.open_queries} (${v.p1_open} P1)`}/>
              <Field label="Health" value={
                <span style={{ color: v.health > 85 ? "var(--ok)" : v.health > 70 ? "var(--warn)" : "var(--bad)" }}>{v.health}/100</span>
              }/>
              <Field label="Onboarded" value={<Mono>{v.onboarded_date}</Mono>}/>
              <Field label="Region" value={`${v.city}, ${v.country}`}/>
            </div>
          </div>

          {/* SLA */}
          {query.sla_pct && (
            <div className="panel p-4" style={{ borderRadius: 4 }}>
              <div className="ink mb-2" style={{ fontSize: 12.5, fontWeight: 600 }}>SLA</div>
              <SLABar pct={query.sla_pct}/>
              <div className="muted mt-3" style={{ fontSize: 11 }}>
                {query.sla_pct >= 95 ? "Breached — L2 escalation" : query.sla_pct >= 85 ? "L1 escalation imminent" : query.sla_pct >= 70 ? "Warning fired" : "On track"}
                · <Mono>{query.sla_deadline_min}m left</Mono>
              </div>
            </div>
          )}
        </div>
      </div>
    </Drawer>
  );
};

const MetaRow = ({ label, value }) => (
  <div className="flex items-center justify-between gap-3 py-1.5 border-b hairline">
    <span className="muted" style={{ fontSize: 11.5 }}>{label}</span>
    <span className="ink-2" style={{ fontSize: 12.5 }}>{value}</span>
  </div>
);

const Field = ({ label, value }) => (
  <div>
    <div className="muted uppercase tracking-wider mb-0.5" style={{ fontSize: 9.5, letterSpacing: ".06em" }}>{label}</div>
    <div className="ink-2" style={{ fontSize: 12 }}>{value}</div>
  </div>
);

Object.assign(window, { QueryDetail, MetaRow, Field });
