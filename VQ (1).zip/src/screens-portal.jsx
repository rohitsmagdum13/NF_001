// Vendor self-service portal — for users with role = "Vendor"

const VendorPortal = ({ vendorName = "CloudWave Solutions", vendorId = "V-001", onSignOut }) => {
  const [tab, setTab] = React.useState("queries");
  const [composing, setComposing] = React.useState(false);
  const ep = window.useEndpoints();
  const myQueries = window.QUERIES.filter(q => q.vendor_id === vendorId);

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--bg)" }}>
      {/* Header */}
      <header className="border-b hairline px-6 py-3" style={{ background: "var(--panel)" }}>
        <div className="max-w-[1280px] mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Logo size={24}/>
            <div>
              <div className="ink" style={{ fontSize: 14, fontWeight: 600, letterSpacing: "-.01em" }}>VQMS Vendor Portal</div>
              <div className="muted" style={{ fontSize: 11 }}>Hexaware Technologies · Vendor self-service</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="chip"><Tier tier="PLATINUM"/> <Mono className="ml-1">{vendorId}</Mono></span>
            <span className="ink-2" style={{ fontSize: 13 }}>{vendorName}</span>
            <Avatar name={vendorName} size={28}/>
            <window.EndpointsButton onClick={ep.openIt} label="API"/>
            <button className="btn btn-ghost" onClick={onSignOut} title="Sign out"><I name="log-out" size={13}/></button>
          </div>
        </div>
      </header>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Vendor portal · API surface"
        subtitle="src/api/routes/portal.py · vendor JWT scoped to single vendor_id · row-level security enforced"
        endpoints={window.ENDPOINTS_PORTAL}
        role="Vendor"
      />

      {/* Hero strip */}
      <div className="border-b hairline" style={{ background: "var(--ink)", color: "var(--bg)" }}>
        <div className="max-w-[1280px] mx-auto px-6 py-6 grid grid-cols-12 gap-4 items-center">
          <div className="col-span-7">
            <div className="mono" style={{ fontSize: 10.5, opacity: .55, letterSpacing: ".1em", textTransform: "uppercase" }}>
              Welcome back
            </div>
            <div style={{ fontSize: 26, fontWeight: 600, letterSpacing: "-.02em", marginTop: 4 }}>
              {vendorName.split(" ")[0]}, you have <span style={{ color: "var(--accent)" }}>{myQueries.filter(q => !["RESOLVED","CLOSED"].includes(q.status)).length} open queries</span>.
            </div>
            <div style={{ fontSize: 12.5, opacity: .7, marginTop: 6 }}>
              We typically respond within 4 hours during business days. Track status anytime — every reply is logged here and on email.
            </div>
          </div>
          <div className="col-span-5 grid grid-cols-3 gap-3">
            <PortalStat v={myQueries.length} l="Total"/>
            <PortalStat v={myQueries.filter(q => q.status === "RESOLVED").length} l="Resolved" color="var(--ok)"/>
            <PortalStat v={myQueries.filter(q => !["RESOLVED","CLOSED"].includes(q.status)).length} l="Open" color="var(--accent)"/>
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="flex-1 max-w-[1280px] mx-auto w-full px-6 py-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1">
            {[
              { k: "queries",  l: "My queries", n: myQueries.length },
              { k: "compose",  l: "New query" },
              { k: "invoices", l: "Invoices",   n: 4 },
              { k: "contracts",l: "Contracts",  n: 2 },
              { k: "profile",  l: "Profile" },
            ].map(t => (
              <span key={t.k} className={"tab " + (tab === t.k ? "active" : "")} onClick={() => { setTab(t.k); if (t.k === "compose") setComposing(true); }}>
                {t.l}{t.n != null && <Mono className="ml-1.5 muted">{t.n}</Mono>}
              </span>
            ))}
          </div>
          <button className="btn btn-accent" onClick={() => setComposing(true)}><I name="plus" size={13}/> New query</button>
        </div>

        {tab === "queries" && (
          <div className="grid grid-cols-12 gap-3">
            <div className="col-span-12 panel" style={{ borderRadius: 4, overflow: "hidden" }}>
              <table className="vqms-table">
                <thead>
                  <tr><th>Reference</th><th>Subject</th><th>Status</th><th>Last update</th><th style={{ textAlign: "right" }}>Submitted</th></tr>
                </thead>
                <tbody>
                  {myQueries.map(q => (
                    <tr key={q.query_id}>
                      <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{q.query_id}</Mono></td>
                      <td>
                        <div className="ink-2" style={{ fontSize: 13 }}>{q.subject}</div>
                        <div className="muted mt-0.5" style={{ fontSize: 11 }}>{q.intent}</div>
                      </td>
                      <td><Status s={q.status}/></td>
                      <td><Mono className="muted">{relative(q.received_at)}</Mono></td>
                      <td style={{ textAlign: "right" }}><Mono className="muted">{q.received_at.slice(0, 10)}</Mono></td>
                    </tr>
                  ))}
                  {myQueries.length === 0 && <tr><td colSpan={5}><Empty title="No queries yet" desc="Submit a new query to get started."/></td></tr>}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {tab === "invoices" && (
          <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
            <table className="vqms-table">
              <thead><tr><th>Invoice</th><th>Amount</th><th>Issued</th><th>Due</th><th>Status</th></tr></thead>
              <tbody>
                {[
                  { id: "INV-88241", amt: 14750.00, issued: "2026-04-01", due: "2026-05-01", status: "DRAFTING", note: "Short paid · in dispute" },
                  { id: "INV-87104", amt:  8420.00, issued: "2026-03-15", due: "2026-04-15", status: "RESOLVED" },
                  { id: "INV-86012", amt: 22100.00, issued: "2026-02-28", due: "2026-03-30", status: "RESOLVED" },
                  { id: "INV-85006", amt:  4800.00, issued: "2026-02-01", due: "2026-03-03", status: "RESOLVED" },
                ].map(inv => (
                  <tr key={inv.id}>
                    <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{inv.id}</Mono>{inv.note && <div className="muted" style={{ fontSize: 11 }}>{inv.note}</div>}</td>
                    <td><Mono>${inv.amt.toLocaleString(undefined,{minimumFractionDigits:2})}</Mono></td>
                    <td><Mono className="muted">{inv.issued}</Mono></td>
                    <td><Mono className="muted">{inv.due}</Mono></td>
                    <td>{inv.status === "RESOLVED" ? <span className="chip" style={{color:"var(--ok)",borderColor:"var(--ok)"}}>Paid</span> : <Status s={inv.status}/>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "contracts" && (
          <div className="grid grid-cols-2 gap-3">
            {[
              { id: "MSA-2024-001", title: "Master Services Agreement", value: 480000, term: "2024-01-04 → 2027-01-04" },
              { id: "SOW-2026-014", title: "Q2 2026 Statement of Work", value: 124000, term: "2026-04-01 → 2026-06-30" },
            ].map(c => (
              <div key={c.id} className="panel p-5" style={{ borderRadius: 4 }}>
                <div className="flex items-start justify-between mb-2">
                  <Mono style={{ color: "var(--ink)", fontWeight: 600 }}>{c.id}</Mono>
                  <span className="chip" style={{color:"var(--ok)",borderColor:"var(--ok)"}}>Active</span>
                </div>
                <div className="ink" style={{ fontSize: 15, fontWeight: 500 }}>{c.title}</div>
                <div className="muted mt-1" style={{ fontSize: 12 }}>{c.term}</div>
                <div className="mt-3 pt-3 border-t hairline flex items-center justify-between">
                  <Stat label="Value" value={`$${c.value.toLocaleString()}`}/>
                  <button className="btn"><I name="download" size={12}/> Download PDF</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "profile" && (
          <div className="grid grid-cols-12 gap-3">
            <div className="panel p-5 col-span-7" style={{ borderRadius: 4 }}>
              <SectionHead title="Company profile" desc="Your master record · synced to Hexaware Salesforce CRM"/>
              <div className="grid grid-cols-2 gap-x-6 gap-y-3 mt-3" style={{ fontSize: 12.5 }}>
                <Field label="Legal name" value="CloudWave Solutions Inc."/>
                <Field label="Vendor ID" value={<Mono>{vendorId}</Mono>}/>
                <Field label="Tax ID (EIN)" value={<Mono>**-***6418</Mono>}/>
                <Field label="DUNS" value={<Mono>084-619-552</Mono>}/>
                <Field label="Address" value="221 Broadway, New York, NY 10007, US"/>
                <Field label="Payment terms" value="Net 30"/>
                <Field label="Primary contact" value="Marcus Holloway"/>
                <Field label="Billing email" value={<Mono>billing@cloudwave.io</Mono>}/>
              </div>
              <div className="mt-4 pt-4 border-t hairline">
                <div className="muted uppercase tracking-wider mb-2" style={{ fontSize: 10 }}>Banking on file</div>
                <div className="flex items-center gap-2">
                  <Mono className="muted">Acct ending **** 4271 · Bank of America · ACH</Mono>
                  <span className="chip"><I name="lock" size={10}/> Verified Apr 12</span>
                </div>
                <div className="muted mt-2" style={{ fontSize: 11.5 }}>
                  To change banking details, submit a query — verification protocol requires phone callback to your authorized contact.
                </div>
              </div>
            </div>
            <div className="panel p-5 col-span-5" style={{ borderRadius: 4 }}>
              <SectionHead title="Quick actions"/>
              <div className="flex flex-col gap-2">
                <button className="btn justify-start"><I name="upload" size={13}/> Upload W-9 / W-8BEN</button>
                <button className="btn justify-start"><I name="upload" size={13}/> Upload insurance certificate</button>
                <button className="btn justify-start"><I name="users" size={13}/> Manage authorized contacts</button>
                <button className="btn justify-start"><I name="key" size={13}/> Reset password</button>
                <button className="btn justify-start"><I name="bell" size={13}/> Notification preferences</button>
              </div>
            </div>
          </div>
        )}
      </div>

      {composing && <ComposeQuery onClose={() => { setComposing(false); setTab("queries"); }}/>}
    </div>
  );
};

const PortalStat = ({ v, l, color = "var(--bg)" }) => (
  <div style={{ background: "rgba(255,255,255,.06)", border: "1px solid rgba(255,255,255,.1)", borderRadius: 4, padding: "12px 14px" }}>
    <div className="mono" style={{ fontSize: 22, fontWeight: 600, color, lineHeight: 1 }}>{v}</div>
    <div className="mono" style={{ fontSize: 10, opacity: .55, letterSpacing: ".06em", textTransform: "uppercase", marginTop: 6 }}>{l}</div>
  </div>
);

const ComposeQuery = ({ onClose }) => {
  const [intent, setIntent] = React.useState("INVOICE_DISPUTE");
  return (
    <Drawer open={true} onClose={onClose} width={640}>
      <div className="px-6 py-4 border-b hairline">
        <div className="flex items-center justify-between">
          <div>
            <div className="ink" style={{ fontSize: 16, fontWeight: 600 }}>New query</div>
            <div className="muted mt-0.5" style={{ fontSize: 12 }}>We'll reply within your tier SLA · Platinum: 2h response, 1‑day resolution</div>
          </div>
          <button className="btn btn-ghost" onClick={onClose}><I name="x" size={14}/></button>
        </div>
      </div>
      <div className="px-6 py-5 flex flex-col gap-4">
        <Field2 label="What can we help with?">
          <div className="grid grid-cols-2 gap-2">
            {[
              { k: "INVOICE_DISPUTE",   l: "Invoice / payment", icon: "receipt" },
              { k: "CONTRACT",          l: "Contract / SOW",    icon: "file-text" },
              { k: "BANKING",           l: "Banking change",    icon: "credit-card" },
              { k: "TAX",               l: "Tax / W-9 / W-8",   icon: "landmark" },
              { k: "ONBOARDING",        l: "Onboarding",        icon: "user-plus" },
              { k: "OTHER",             l: "Something else",    icon: "help-circle" },
            ].map(o => (
              <label key={o.k} className="flex items-center gap-2 p-3 rounded cursor-pointer"
                style={{ border: "1px solid " + (intent === o.k ? "var(--accent)" : "var(--line)"),
                         background: intent === o.k ? "var(--accent-soft)" : "transparent" }}>
                <input type="radio" checked={intent === o.k} onChange={() => setIntent(o.k)} style={{ accentColor: "var(--accent)" }}/>
                <I name={o.icon} size={13} className="muted"/>
                <span style={{ fontSize: 12.5 }}>{o.l}</span>
              </label>
            ))}
          </div>
        </Field2>
        <Field2 label="Subject">
          <input className="w-full" placeholder="One line that summarizes your question" defaultValue="Q1 2026 statement reconciliation question"/>
        </Field2>
        <Field2 label="Reference (optional)">
          <input className="w-full" placeholder="PO, invoice, or contract number" defaultValue="INV-88241"/>
        </Field2>
        <Field2 label="Details">
          <textarea className="w-full" style={{ minHeight: 140, fontFamily: "inherit", fontSize: 13, lineHeight: 1.55 }}
            placeholder="Describe your question. Attach any relevant files below."
            defaultValue="Hi team — looking at the Q1 statement we received on Apr 15, the totals don't reconcile with what we have on our side. We're showing $14,750 outstanding for INV-88241 but the statement shows $12,903. Could you confirm which is correct? Happy to jump on a call if useful."/>
        </Field2>
        <Field2 label="Attachments">
          <div className="rounded p-4 text-center cursor-pointer" style={{ border: "1px dashed var(--line-strong)" }}>
            <I name="paperclip" size={16} className="muted mb-2"/>
            <div className="ink-2" style={{ fontSize: 12.5 }}>Drop files or click to browse</div>
            <div className="muted" style={{ fontSize: 11 }}>PDF, PNG, JPG, XLSX · max 25MB</div>
          </div>
        </Field2>
        <div className="flex items-center justify-between pt-3 border-t hairline">
          <div className="muted" style={{ fontSize: 11.5 }}>
            <I name="info" size={11} className="inline-block mr-1"/>
            Submitting creates a ticket in our system with a unique reference. You'll receive email updates.
          </div>
          <div className="flex items-center gap-2">
            <button className="btn" onClick={onClose}>Cancel</button>
            <button className="btn btn-accent" onClick={onClose}><I name="send" size={13}/> Submit query</button>
          </div>
        </div>
      </div>
    </Drawer>
  );
};

Object.assign(window, { VendorPortal, PortalStat, ComposeQuery });
