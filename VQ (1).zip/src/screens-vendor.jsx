// Vendor 360 view

const Vendor360 = ({ vendor_id, onBack, onOpenQuery }) => {
  const [tab, setTab] = React.useState("overview");
  const v = window.VENDORS.find(x => x.vendor_id === vendor_id) || window.VENDORS[0];
  const contacts = window.CONTACTS[v.vendor_id] || [];
  const contracts = window.CONTRACTS[v.vendor_id] || [];
  const vendorQueries = window.QUERIES.filter(q => q.vendor_id === v.vendor_id);
  const { role } = window.useRole();
  const ep = window.useEndpoints();

  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      <div className="flex items-center justify-between mb-3">
        <button className="btn btn-ghost" onClick={onBack}><I name="arrow-left" size={13}/> Back</button>
        <window.EndpointsButton onClick={ep.openIt}/>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title={`Vendor 360 · ${v.name}`}
        subtitle="vendors.py + queries.py + memory.py · vendor-scoped reads"
        endpoints={window.ENDPOINTS_VENDOR360}
        role={role}
      />

      {/* Header */}
      <div className="panel p-5 mb-3" style={{ borderRadius: 4 }}>
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div style={{ width: 56, height: 56, background: "var(--bg)", border: "1px solid var(--line-strong)", borderRadius: 6,
                          display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 600, fontFamily: "JetBrains Mono" }}>
              {v.name.split(" ").map(s => s[0]).slice(0,2).join("")}
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="ink" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-.02em" }}>{v.name}</span>
                <Tier tier={v.tier}/>
                <Mono className="muted">{v.vendor_id}</Mono>
              </div>
              <div className="muted" style={{ fontSize: 13 }}>
                {v.category} · {v.city}, {v.state !== "—" ? `${v.state}, ` : ""}{v.country} · <span className="mono">{v.website}</span>
              </div>
              <div className="flex items-center gap-3 mt-3" style={{ fontSize: 12 }}>
                <Stat label="Annual revenue" value={`$${(v.annual_revenue / 1_000_000).toFixed(1)}M`}/>
                <Stat label="Payment terms" value={v.payment_terms}/>
                <Stat label="SLA" value={`${v.sla_response_hours}h / ${v.sla_resolution_days}d`}/>
                <Stat label="Onboarded" value={v.onboarded_date}/>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-2">
              <button className="btn"><I name="mail" size={13}/> Compose email</button>
              <button className="btn"><I name="external-link" size={13}/> Salesforce</button>
              <button className="btn btn-primary"><I name="pencil" size={13}/> Edit</button>
            </div>
            <div className="flex items-center gap-3 mt-1">
              <Donut pct={v.health}/>
              <div>
                <div className="muted uppercase tracking-wider" style={{ fontSize: 10 }}>Health</div>
                <Mono style={{ fontSize: 18, fontWeight: 600, color: v.health > 85 ? "var(--ok)" : v.health > 70 ? "var(--warn)" : "var(--bad)" }}>{v.health}</Mono>
                <span className="muted" style={{ fontSize: 11 }}>/100</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b hairline flex items-center mb-4">
        {["overview","queries","contacts","contracts","documents","timeline"].map(t => (
          <span key={t} className={"tab " + (tab === t ? "active" : "")} onClick={() => setTab(t)}>
            {t[0].toUpperCase() + t.slice(1)}
            {t === "queries" && <Mono className="ml-1.5 muted">{vendorQueries.length}</Mono>}
            {t === "contacts" && <Mono className="ml-1.5 muted">{contacts.length}</Mono>}
            {t === "contracts" && <Mono className="ml-1.5 muted">{contracts.length}</Mono>}
          </span>
        ))}
      </div>

      {tab === "overview" && (
        <div className="grid grid-cols-12 gap-3">
          <div className="panel p-4 col-span-8" style={{ borderRadius: 4 }}>
            <SectionHead title="Query history" desc="Last 30 days · all paths"/>
            <QueryVolumeChart data={window.TREND_30D.map(d => ({...d, A: Math.round(d.A * 0.18), B: Math.round(d.B * 0.18), C: Math.round(d.C * 0.18)}))}/>
          </div>
          <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
            <SectionHead title="At a glance"/>
            <div className="flex flex-col gap-3">
              <Stat block label="Open queries" value={vendorQueries.filter(q => !["RESOLVED","CLOSED"].includes(q.status)).length}/>
              <Stat block label="P1 open" value={v.p1_open} accent={v.p1_open > 0}/>
              <Stat block label="Avg resolution (last 30d)" value="2h 18m"/>
              <Stat block label="Resolution rate" value="93.1%"/>
              <Stat block label="SLA on‑time" value="96.4%"/>
            </div>
          </div>
          <div className="panel p-4 col-span-12" style={{ borderRadius: 4 }}>
            <SectionHead title="Communication timeline" desc="Inbound + outbound · last 14 days"/>
            <Timeline/>
          </div>
        </div>
      )}

      {tab === "queries" && (
        <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
          <table className="vqms-table">
            <thead>
              <tr><th>Query</th><th>Subject</th><th>Path</th><th>Status</th><th>Conf.</th><th>SLA</th><th style={{ textAlign: "right" }}>Received</th></tr>
            </thead>
            <tbody>
              {vendorQueries.map(q => (
                <tr key={q.query_id} onClick={() => onOpenQuery(q)}>
                  <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{q.query_id}</Mono></td>
                  <td><div className="ink-2 truncate" style={{ maxWidth: 380 }}>{q.subject}</div></td>
                  <td><PathBadge p={q.processing_path}/></td>
                  <td><Status s={q.status}/></td>
                  <td><ConfidenceBar value={q.confidence}/></td>
                  <td><SLABar pct={q.sla_pct}/></td>
                  <td style={{ textAlign: "right" }}><Mono className="muted">{relative(q.received_at)}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab === "contacts" && (
        <div className="grid grid-cols-3 gap-3">
          {contacts.map(c => (
            <div key={c.email} className="panel p-4" style={{ borderRadius: 4 }}>
              <div className="flex items-start gap-3">
                <Avatar name={c.name} size={40}/>
                <div className="flex-1 min-w-0">
                  <div className="ink truncate" style={{ fontSize: 13.5, fontWeight: 500 }}>{c.name}</div>
                  <div className="muted" style={{ fontSize: 11.5 }}>{c.role}</div>
                </div>
              </div>
              <div className="mt-3 flex flex-col gap-1.5" style={{ fontSize: 11.5 }}>
                <div className="flex items-center gap-2"><I name="mail" size={11} className="muted"/> <Mono>{c.email}</Mono></div>
                <div className="flex items-center gap-2"><I name="phone" size={11} className="muted"/> <Mono>{c.phone}</Mono></div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "contracts" && (
        <div className="panel" style={{ borderRadius: 4, overflow: "hidden" }}>
          <table className="vqms-table">
            <thead><tr><th>Contract</th><th>Title</th><th>Value</th><th>Term</th><th>Status</th></tr></thead>
            <tbody>
              {contracts.map(c => (
                <tr key={c.id}>
                  <td><Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{c.id}</Mono></td>
                  <td className="ink-2">{c.title}</td>
                  <td><Mono>${c.value.toLocaleString()}</Mono></td>
                  <td><Mono className="muted">{c.start} → {c.end}</Mono></td>
                  <td><Status s="RESOLVED"/></td>
                </tr>
              ))}
              {contracts.length === 0 && <tr><td colSpan={5}><Empty title="No contracts on file" desc="None retrieved from Salesforce."/></td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {tab === "documents" && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { name: "MSA — executed.pdf", size: "1.2 MB", date: "2024-01-04" },
            { name: "W-9 (2026).pdf", size: "186 KB", date: "2026-01-08" },
            { name: "Insurance certificate.pdf", size: "412 KB", date: "2026-04-15" },
            { name: "DPA.pdf", size: "640 KB", date: "2024-01-04" },
          ].map(d => (
            <div key={d.name} className="panel p-4" style={{ borderRadius: 4 }}>
              <I name="file-text" size={20} className="muted mb-3"/>
              <div className="ink-2" style={{ fontSize: 12.5, fontWeight: 500 }}>{d.name}</div>
              <Mono className="muted mt-1" style={{ fontSize: 11 }}>{d.size} · {d.date}</Mono>
            </div>
          ))}
        </div>
      )}

      {tab === "timeline" && <div className="panel p-5" style={{ borderRadius: 4 }}><Timeline/></div>}
    </div>
  );
};

const Stat = ({ label, value, block, accent }) => (
  <div className={block ? "flex items-center justify-between" : "flex flex-col"}>
    <span className="muted uppercase tracking-wider" style={{ fontSize: 10 }}>{label}</span>
    <span className="ink mono" style={{ fontSize: block ? 14 : 13, fontWeight: 600, color: accent ? "var(--bad)" : "var(--ink)" }}>{value}</span>
  </div>
);

const Donut = ({ pct }) => {
  const r = 22, c = 2 * Math.PI * r;
  return (
    <svg width="56" height="56" viewBox="0 0 56 56">
      <circle cx="28" cy="28" r={r} fill="none" stroke="var(--line)" strokeWidth="4"/>
      <circle cx="28" cy="28" r={r} fill="none"
        stroke={pct > 85 ? "var(--ok)" : pct > 70 ? "var(--warn)" : "var(--bad)"}
        strokeWidth="4" strokeDasharray={`${c * pct / 100} ${c}`} strokeLinecap="round"
        transform="rotate(-90 28 28)"/>
    </svg>
  );
};

const Timeline = () => {
  const items = [
    { ts: "Apr 28, 11:14", who: "Marcus Holloway", dir: "in",  text: "Inbound · Re: INV-88241 short paid by $1,847" },
    { ts: "Apr 28, 11:15", who: "VQMS",            dir: "out", text: "Auto‑resolution drafted · Path A · sent" },
    { ts: "Apr 27, 16:02", who: "Priya Raman",     dir: "in",  text: "Inbound · banking detail change request" },
    { ts: "Apr 27, 16:03", who: "Niraj Shah",      dir: "out", text: "Manual response sent · verification protocol enclosed" },
    { ts: "Apr 26, 09:48", who: "Marcus Holloway", dir: "in",  text: "Inbound · Q1 statement reconciliation" },
    { ts: "Apr 22, 14:30", who: "VQMS",            dir: "out", text: "Acknowledgment · ServiceNow INC-2139891 created" },
  ];
  return (
    <div className="flex flex-col">
      {items.map((it, i) => (
        <div key={i} className="flex items-start gap-3 py-2.5 border-b hairline last:border-0">
          <Mono className="muted" style={{ fontSize: 11, minWidth: 100 }}>{it.ts}</Mono>
          <span style={{
            display: "inline-flex", alignItems: "center", justifyContent: "center",
            width: 22, height: 22, borderRadius: 999,
            background: it.dir === "in" ? "color-mix(in oklch, var(--info) 14%, var(--panel))" : "color-mix(in oklch, var(--accent) 14%, var(--panel))",
            color: it.dir === "in" ? "var(--info)" : "var(--accent)",
          }}>
            <I name={it.dir === "in" ? "arrow-down-left" : "arrow-up-right"} size={12}/>
          </span>
          <div className="flex-1">
            <div className="ink-2" style={{ fontSize: 12.5 }}>{it.text}</div>
            <Mono className="muted" style={{ fontSize: 11 }}>{it.who}</Mono>
          </div>
        </div>
      ))}
    </div>
  );
};

Object.assign(window, { Vendor360, Stat, Donut, Timeline });
