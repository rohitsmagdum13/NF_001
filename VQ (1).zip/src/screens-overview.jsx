// Overview / dashboard

const Overview = ({ darkMode }) => {
  const queries = window.QUERIES;
  const { role } = window.useRole();
  const ep = window.useEndpoints();
  const totalA = queries.filter(q => q.processing_path === "A").length;
  const totalB = queries.filter(q => q.processing_path === "B").length;
  const totalC = queries.filter(q => q.processing_path === "C").length;
  const breached = queries.filter(q => q.sla_pct && q.sla_pct >= 95).length;
  const open = queries.filter(q => !["RESOLVED","CLOSED","MERGED_INTO_PARENT"].includes(q.status)).length;
  const recent = [...queries].sort((a,b) => b.received_at.localeCompare(a.received_at)).slice(0, 8);
  const sparkA = window.TREND_30D.map(d => ({ v: d.A }));
  const sparkB = window.TREND_30D.map(d => ({ v: d.B }));
  const sparkC = window.TREND_30D.map(d => ({ v: d.C }));
  const sparkSLA = window.TREND_30D.map(d => ({ v: 92 + Math.sin(d.A) * 3 }));

  return (
    <div className="p-6 max-w-[1600px] mx-auto fade-up">
      {/* Header band */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <div className="ink" style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-.02em" }}>Operations overview</div>
          <div className="muted mt-1" style={{ fontSize: 13 }}>
            <span className="mono">{new Date().toLocaleString("en-US", { weekday: "long", month: "long", day: "numeric" })}</span>
            {" · "}Last 30 days · All vendors
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn"><I name="calendar" size={13}/> Last 30 days</button>
          <window.EndpointsButton onClick={ep.openIt}/>
          <button className="btn"><I name="download" size={13}/> Export</button>
          <button className="btn btn-primary"><I name="bell" size={13}/> Subscribe</button>
        </div>
      </div>

      <window.EndpointsDrawer
        open={ep.open}
        onClose={ep.closeIt}
        title="Operations overview · backend contract"
        subtitle="src/api/routes/dashboard.py · aggregated KPIs"
        endpoints={window.ENDPOINTS_OVERVIEW}
        role={role}
      />

      {/* KPI row */}
      <div className="grid grid-cols-4 gap-3 mb-3">
        <KPI label="Queries received" value="1,284" delta={12} sub="vs. previous 30d · 42.8/day avg" icon="inbox"
          sparkline={<Sparkline data={window.TREND_30D.map(d => ({v: d.received}))} color="var(--ink-2)" />} />
        <KPI label="Resolution rate" value="91.4%" delta={2} sub="1,174 of 1,284 · auto‑close enabled"   icon="check-circle"
          sparkline={<Sparkline data={sparkSLA} color="var(--ok)" />} />
        <KPI label="Avg response time" value="4h 12m" delta={-18} sub="P50 · email‑to‑first‑touch"        icon="timer"
          sparkline={<Sparkline data={window.TREND_30D.map(d => ({v: 250 - d.A}))} color="var(--accent)" />} />
        <KPI label="SLA breaches" value={breached} delta={-22} sub="last 30d · 70/85/95 thresholds"        icon="alert-triangle"
          sparkline={<Sparkline data={window.TREND_30D.map((d,i) => ({v: 14 - i % 6}))} color="var(--bad)" />} />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-12 gap-3 mb-3">
        <div className="panel p-4 col-span-8" style={{ borderRadius: 4 }}>
          <SectionHead
            title="Query volume by routing path"
            desc="Stacked daily counts · Path A (AI‑resolved) · Path B (human team) · Path C (low‑confidence triage)"
            right={<div className="flex items-center gap-3 text-[11.5px] mono">
              <span className="flex items-center gap-1.5"><span style={{width:8,height:8,background:"var(--path-a)",borderRadius:2}}/> A · {totalA}</span>
              <span className="flex items-center gap-1.5"><span style={{width:8,height:8,background:"var(--path-b)",borderRadius:2}}/> B · {totalB}</span>
              <span className="flex items-center gap-1.5"><span style={{width:8,height:8,background:"var(--path-c)",borderRadius:2}}/> C · {totalC}</span>
            </div>} />
          <QueryVolumeChart data={window.TREND_30D} />
        </div>
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="Path distribution" desc="Current 30d resolution mix" />
          <PathPie a={totalA} b={totalB} c={totalC} />
          <div className="mt-4 pt-4 border-t hairline" style={{ fontSize: 12 }}>
            <div className="muted mb-2">Confidence threshold</div>
            <div className="flex items-center justify-between">
              <Mono>≥ 0.85 → A or B</Mono>
              <Mono style={{ color: "var(--ok)" }}>92.6%</Mono>
            </div>
            <div className="flex items-center justify-between mt-1">
              <Mono>{"<"} 0.85 → triage (C)</Mono>
              <Mono style={{ color: "var(--warn)" }}>7.4%</Mono>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-3 mb-3">
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="Confidence histogram" desc="Last 30d · LLM Gateway scoring" />
          <ConfidenceChart data={window.CONFIDENCE_HIST} />
          <div className="mt-2 muted" style={{ fontSize: 11 }}>
            <span className="inline-flex items-center gap-1"><span style={{width:6,height:6,background:"var(--accent)",borderRadius:1}}/> 0.85 cutoff</span>
          </div>
        </div>
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="Hourly throughput" desc="Last 24h · ingested vs. resolved" />
          <HourlyChart data={window.HOURLY_24H} />
          <div className="mt-2 flex items-center gap-3 text-[11px] mono">
            <span className="flex items-center gap-1.5"><span style={{width:8,height:8,background:"var(--ink-2)",borderRadius:2}}/> Ingested</span>
            <span className="flex items-center gap-1.5"><span style={{width:8,height:8,background:"var(--accent)",borderRadius:2}}/> Resolved</span>
          </div>
        </div>
        <div className="panel p-4 col-span-4" style={{ borderRadius: 4 }}>
          <SectionHead title="SLA performance by team" desc="On‑time vs. breached · 30d" />
          <SLATeamChart data={window.SLA_BY_TEAM} />
        </div>
      </div>

      <div className="grid grid-cols-12 gap-3">
        {/* Recent activity */}
        <div className="panel col-span-8" style={{ borderRadius: 4 }}>
          <div className="flex items-center justify-between p-4 border-b hairline">
            <SectionHead title="Recent queries" desc="Newest 8 across all paths" />
            <button className="btn btn-ghost"><I name="arrow-right" size={13}/> Open inbox</button>
          </div>
          <table className="vqms-table">
            <thead>
              <tr><th>Query</th><th>Vendor</th><th>Path</th><th>Status</th><th>Conf.</th><th>SLA</th><th style={{textAlign:"right"}}>Received</th></tr>
            </thead>
            <tbody>
              {recent.map(q => (
                <tr key={q.query_id}>
                  <td>
                    <div className="flex items-center gap-2">
                      <Priority p={q.priority}/>
                      <Mono style={{ color: "var(--ink)", fontWeight: 500 }}>{q.query_id}</Mono>
                    </div>
                    <div className="muted truncate mt-0.5" style={{ fontSize: 11.5, maxWidth: 380 }}>{q.subject}</div>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      <span className="ink-2" style={{ fontSize: 12.5 }}>{q.vendor_name}</span>
                      <Tier tier={q.vendor_tier}/>
                    </div>
                    <Mono className="muted" style={{ fontSize: 11 }}>{q.vendor_id}</Mono>
                  </td>
                  <td><PathBadge p={q.processing_path}/></td>
                  <td><Status s={q.status}/></td>
                  <td><ConfidenceBar value={q.confidence}/></td>
                  <td><SLABar pct={q.sla_pct}/></td>
                  <td style={{textAlign:"right"}}><Mono className="muted">{relative(q.received_at)}</Mono></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Top intents + Vendor health */}
        <div className="col-span-4 flex flex-col gap-3">
          <div className="panel p-4" style={{ borderRadius: 4 }}>
            <SectionHead title="Top intents" desc="Last 30d · top 6" />
            <div className="flex flex-col gap-2 mt-1">
              {window.TOP_INTENTS.map(it => {
                const max = window.TOP_INTENTS[0].n;
                return (
                  <div key={it.intent}>
                    <div className="flex items-center justify-between text-[12px]">
                      <span className="ink-2">{it.intent}</span>
                      <Mono className="muted">{it.n}</Mono>
                    </div>
                    <div style={{ height: 3, background: "var(--line)", borderRadius: 2, marginTop: 3, overflow: "hidden" }}>
                      <div style={{ width: `${it.n / max * 100}%`, height: "100%", background: "var(--accent)" }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <div className="panel p-4" style={{ borderRadius: 4 }}>
            <SectionHead title="Vendor health" desc="Tier‑weighted score · open queries" />
            <div className="flex flex-col gap-2.5 mt-1">
              {window.VENDORS.slice(0, 6).map(v => (
                <div key={v.vendor_id} className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <Tier tier={v.tier}/>
                      <span className="ink truncate" style={{ fontSize: 13 }}>{v.name}</span>
                    </div>
                    <div className="muted" style={{ fontSize: 11 }}>{v.open_queries} open · {v.p1_open} P1</div>
                  </div>
                  <div style={{ width: 70 }}>
                    <div style={{ height: 4, background: "var(--line)", borderRadius: 2, overflow: "hidden" }}>
                      <div style={{ width: `${v.health}%`, height: "100%", background: v.health > 85 ? "var(--ok)" : v.health > 70 ? "var(--warn)" : "var(--bad)" }}/>
                    </div>
                  </div>
                  <Mono style={{ width: 28, textAlign: "right" }}>{v.health}</Mono>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function relative(iso) {
  const now = new Date("2026-04-28T14:23:00Z");
  const ms = now - new Date(iso);
  const m = Math.round(ms / 60000);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.round(h/24)}d ago`;
}

Object.assign(window, { Overview, relative });
