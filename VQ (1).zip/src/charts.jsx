// Recharts wrappers

const {
  ResponsiveContainer, AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, ReferenceLine
} = window.Recharts;

const QueryVolumeChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={220}>
    <AreaChart data={data} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
      <defs>
        <linearGradient id="gA" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="var(--path-a)" stopOpacity={0.32}/>
          <stop offset="100%" stopColor="var(--path-a)" stopOpacity={0}/>
        </linearGradient>
        <linearGradient id="gB" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="var(--path-b)" stopOpacity={0.28}/>
          <stop offset="100%" stopColor="var(--path-b)" stopOpacity={0}/>
        </linearGradient>
        <linearGradient id="gC" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%"  stopColor="var(--path-c)" stopOpacity={0.28}/>
          <stop offset="100%" stopColor="var(--path-c)" stopOpacity={0}/>
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="2 4" vertical={false} />
      <XAxis dataKey="date" tickLine={false} axisLine={false} interval={3} />
      <YAxis tickLine={false} axisLine={false} width={32} />
      <Tooltip />
      <Area type="monotone" dataKey="A" stackId="1" stroke="var(--path-a)" fill="url(#gA)" strokeWidth={1.5} />
      <Area type="monotone" dataKey="B" stackId="1" stroke="var(--path-b)" fill="url(#gB)" strokeWidth={1.5} />
      <Area type="monotone" dataKey="C" stackId="1" stroke="var(--path-c)" fill="url(#gC)" strokeWidth={1.5} />
    </AreaChart>
  </ResponsiveContainer>
);

const HourlyChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={180}>
    <BarChart data={data} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
      <CartesianGrid strokeDasharray="2 4" vertical={false} />
      <XAxis dataKey="hour" tickLine={false} axisLine={false} interval={2} />
      <YAxis tickLine={false} axisLine={false} width={28} />
      <Tooltip />
      <Bar dataKey="ingested" fill="var(--ink-2)" radius={[2,2,0,0]} />
      <Bar dataKey="resolved" fill="var(--accent)" radius={[2,2,0,0]} />
    </BarChart>
  </ResponsiveContainer>
);

const ConfidenceChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={170}>
    <BarChart data={data} margin={{ top: 8, right: 8, left: -10, bottom: 0 }}>
      <CartesianGrid strokeDasharray="2 4" vertical={false} />
      <XAxis dataKey="band" tickLine={false} axisLine={false} />
      <YAxis tickLine={false} axisLine={false} width={28} />
      <Tooltip />
      <ReferenceLine x="0.8–0.9" stroke="var(--accent)" strokeDasharray="3 3" />
      <Bar dataKey="n" radius={[2,2,0,0]}>
        {data.map((d, i) => (
          <Cell key={i} fill={
            d.band.startsWith("0.8") || d.band.startsWith("0.9") ? "var(--ok)"
            : d.band.startsWith("0.6") ? "var(--warn)"
            : "var(--bad)"
          } />
        ))}
      </Bar>
    </BarChart>
  </ResponsiveContainer>
);

const PathPie = ({ a, b, c }) => {
  const total = a + b + c;
  const data = [
    { name: "Path A", value: a, color: "var(--path-a)" },
    { name: "Path B", value: b, color: "var(--path-b)" },
    { name: "Path C", value: c, color: "var(--path-c)" },
  ];
  return (
    <div className="flex items-center gap-4">
      <div style={{ width: 110, height: 110 }}>
        <ResponsiveContainer>
          <PieChart>
            <Pie data={data} dataKey="value" innerRadius={36} outerRadius={52} stroke="var(--panel)" strokeWidth={2}>
              {data.map((d, i) => <Cell key={i} fill={d.color} />)}
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="flex flex-col gap-1.5 text-[12px]">
        {data.map(d => (
          <div key={d.name} className="flex items-center gap-2">
            <span style={{ width: 8, height: 8, background: d.color, borderRadius: 2 }} />
            <span className="ink-2" style={{ minWidth: 56 }}>{d.name}</span>
            <span className="mono ink" style={{ fontWeight: 600 }}>{Math.round(d.value/total*100)}%</span>
            <span className="mono muted">({d.value})</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const Sparkline = ({ data, height = 28, color = "var(--accent)" }) => (
  <ResponsiveContainer width="100%" height={height}>
    <AreaChart data={data} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
      <defs>
        <linearGradient id="sparkG" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.28}/>
          <stop offset="100%" stopColor={color} stopOpacity={0}/>
        </linearGradient>
      </defs>
      <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} fill="url(#sparkG)" />
    </AreaChart>
  </ResponsiveContainer>
);

const SLATeamChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={180}>
    <BarChart data={data} layout="vertical" margin={{ top: 0, right: 8, left: 0, bottom: 0 }}>
      <CartesianGrid strokeDasharray="2 4" horizontal={false} />
      <XAxis type="number" tickLine={false} axisLine={false} />
      <YAxis type="category" dataKey="team" width={100} tickLine={false} axisLine={false} />
      <Tooltip />
      <Bar dataKey="on_time" stackId="a" fill="var(--ok)"  radius={[0,0,0,0]} />
      <Bar dataKey="breached" stackId="a" fill="var(--bad)" radius={[0,2,2,0]} />
    </BarChart>
  </ResponsiveContainer>
);

Object.assign(window, { QueryVolumeChart, HourlyChart, ConfidenceChart, PathPie, Sparkline, SLATeamChart });
