// Realistic mock data based on actual VQMS schema discovered in codebase

const VENDORS = [
  { vendor_id: "V-001", name: "Cloudwave Hosting", website: "cloudwave.io",     tier: "PLATINUM", category: "Cloud Infrastructure", payment_terms: "NET 45", annual_revenue: 84_200_000, sla_response_hours: 2,  sla_resolution_days: 1, status: "ACTIVE", city: "Seattle", state: "WA", country: "USA", onboarded_date: "2019-03-12", health: 98, open_queries: 4, p1_open: 0 },
  { vendor_id: "V-002", name: "Northwind Logistics", website: "northwindlog.com", tier: "GOLD",     category: "Logistics",            payment_terms: "NET 60", annual_revenue: 41_800_000, sla_response_hours: 4,  sla_resolution_days: 3, status: "ACTIVE", city: "Chicago", state: "IL", country: "USA", onboarded_date: "2020-08-04", health: 86, open_queries: 7, p1_open: 1 },
  { vendor_id: "V-003", name: "Sigma Data Labs",     website: "sigmadata.ai",   tier: "PLATINUM", category: "Data & Analytics",     payment_terms: "NET 30", annual_revenue: 62_000_000, sla_response_hours: 2,  sla_resolution_days: 1, status: "ACTIVE", city: "Austin",  state: "TX", country: "USA", onboarded_date: "2021-01-22", health: 92, open_queries: 3, p1_open: 0 },
  { vendor_id: "V-004", name: "Helios Print Co.",    website: "helios.print",   tier: "SILVER",   category: "Office Services",      payment_terms: "NET 30", annual_revenue: 8_400_000,  sla_response_hours: 8,  sla_resolution_days: 5, status: "ACTIVE", city: "Toronto", state: "ON", country: "CAN", onboarded_date: "2022-06-15", health: 71, open_queries: 12, p1_open: 0 },
  { vendor_id: "V-005", name: "Bramble & Hart LLP",  website: "bramblehart.com",tier: "GOLD",     category: "Legal Services",       payment_terms: "NET 30", annual_revenue: 19_900_000, sla_response_hours: 4,  sla_resolution_days: 3, status: "ACTIVE", city: "London", state: "—",  country: "GBR", onboarded_date: "2018-11-30", health: 88, open_queries: 2, p1_open: 0 },
  { vendor_id: "V-006", name: "Yamasaki Hardware",   website: "yamasaki.co.jp", tier: "BRONZE",   category: "Hardware Supply",      payment_terms: "NET 60", annual_revenue: 3_200_000,  sla_response_hours: 12, sla_resolution_days: 7, status: "ACTIVE", city: "Osaka",  state: "—",  country: "JPN", onboarded_date: "2023-04-10", health: 64, open_queries: 9, p1_open: 2 },
  { vendor_id: "V-007", name: "Continental Steelworks", website: "continental-steel.de", tier: "PLATINUM", category: "Manufacturing", payment_terms: "NET 45", annual_revenue: 128_500_000, sla_response_hours: 2, sla_resolution_days: 1, status: "ACTIVE", city: "Hamburg", state: "—", country: "DEU", onboarded_date: "2017-02-08", health: 95, open_queries: 1, p1_open: 0 },
  { vendor_id: "V-008", name: "Greenline Catering",  website: "greenline.com",  tier: "SILVER",   category: "Office Services",      payment_terms: "NET 30", annual_revenue: 6_100_000,  sla_response_hours: 8,  sla_resolution_days: 5, status: "ACTIVE", city: "Brooklyn", state: "NY", country: "USA", onboarded_date: "2022-09-01", health: 78, open_queries: 5, p1_open: 0 },
];

const CONTACTS = {
  "V-001": [
    { name: "Marcus Holloway", role: "Account Manager", email: "m.holloway@cloudwave.io", phone: "+1 206 555 0188" },
    { name: "Priya Raman",     role: "Billing Lead",    email: "billing@cloudwave.io",    phone: "+1 206 555 0190" },
    { name: "Dao Nguyen",      role: "Technical Liaison", email: "dao.n@cloudwave.io",    phone: "+1 206 555 0142" },
  ],
  "V-002": [
    { name: "Greta Lindqvist", role: "Account Manager", email: "g.lindqvist@northwindlog.com", phone: "+1 312 555 0227" },
    { name: "Owen Adesina",    role: "Operations",      email: "ops@northwindlog.com",         phone: "+1 312 555 0231" },
  ],
  "V-003": [
    { name: "Reza Karimi",     role: "Account Manager", email: "rk@sigmadata.ai", phone: "+1 512 555 0144" },
  ],
  "V-004": [
    { name: "Janelle Kowalski", role: "Account Manager", email: "j.kowalski@helios.print", phone: "+1 416 555 0119" },
  ],
};

const CONTRACTS = {
  "V-001": [
    { id: "C-2024-118", title: "Master Services Agreement", value: 4_200_000, currency: "USD", start: "2024-01-01", end: "2026-12-31", status: "ACTIVE" },
    { id: "C-2024-119", title: "Data Processing Addendum",  value: 0,         currency: "USD", start: "2024-01-01", end: "2026-12-31", status: "ACTIVE" },
  ],
  "V-002": [
    { id: "C-2023-088", title: "Logistics SOW — North Region", value: 1_900_000, currency: "USD", start: "2023-07-01", end: "2025-06-30", status: "ACTIVE" },
  ],
  "V-003": [
    { id: "C-2025-012", title: "Analytics Platform License",   value: 2_700_000, currency: "USD", start: "2025-01-01", end: "2027-12-31", status: "ACTIVE" },
  ],
};

const TEAMS = ["Billing Ops", "Procurement", "Tax & Compliance", "Vendor Relations", "Engineering Liaison", "Legal"];

const INTENTS = ["Invoice clarification", "Payment status inquiry", "Tax form W‑9", "Contract amendment", "PO confirmation", "Banking detail change", "Statement reconciliation", "Onboarding update", "Service credit request", "Insurance certificate"];

const QUERIES = (() => {
  const now = new Date("2026-04-28T14:23:00Z");
  const items = [];
  const subjects = [
    "Re: Invoice INV‑88241 short paid by $1,847",
    "Updated banking details — please confirm receipt",
    "Q1 2026 statement does not match remittance",
    "PO 4419821 — partial shipment, do we re‑bill?",
    "W‑9 expired, need updated copy on file",
    "Amendment #3 to MSA — counter‑signature pending",
    "Service credit owed for Feb 14 outage",
    "Certificate of insurance expiring May 1",
    "Duplicate invoice INV‑88112 / INV‑88114 — please void one",
    "Change of remit‑to address",
    "Annual rate increase notice — clarification",
    "Past‑due reminder for already‑paid INV‑87900",
    "Diversity certification — NAICS update",
    "1099 issuance question for FY2025",
    "Onboarding form — section 4 unclear",
    "Portal access — locked out for 3 days",
    "Sales tax exemption certificate refresh",
    "Late fee waiver request — March cycle",
    "ACH details mismatch — vendor master vs. invoice",
    "Cancellation of standing PO 4418772",
  ];
  const paths = ["A","A","A","A","B","B","B","C","C","B"];
  const statuses = ["RESOLVED","DELIVERING","DRAFTING","ROUTING","ANALYZING","AWAITING_RESOLUTION","PAUSED","RESOLVED","RESOLVED","DRAFTING"];
  const teamsByPath = { A: "—", B: ["Billing Ops","Procurement","Tax & Compliance"], C: "Triage Reviewer" };

  for (let i = 0; i < 56; i++) {
    const v = VENDORS[i % VENDORS.length];
    const path = paths[i % paths.length];
    const status = i < 4 ? ["DRAFTING","ROUTING","ANALYZING","PAUSED"][i] : statuses[i % statuses.length];
    const conf = path === "C" ? 0.42 + (i % 7) * 0.05 : 0.86 + (i % 9) * 0.012;
    const rec = new Date(now.getTime() - (i * 1000 * 60 * (37 + (i % 11) * 13)));
    const sla_pct = path === "A" ? null : Math.min(99, 18 + (i * 7) % 90);
    items.push({
      query_id: `VQ-2026-${String(1842 - i).padStart(4, "0")}`,
      correlation_id: `corr_${(0xa3f12c + i * 1117).toString(16)}`,
      execution_id: `exec_${(0xb91240 + i * 4231).toString(16)}`,
      source: i % 4 === 0 ? "portal" : "email",
      subject: subjects[i % subjects.length],
      vendor_id: v.vendor_id,
      vendor_name: v.name,
      vendor_tier: v.tier,
      priority: i % 13 === 0 ? "P1" : (i % 5 === 0 ? "P2" : "P3"),
      status,
      processing_path: path,
      assigned_team: path === "B" ? teamsByPath.B[i % 3] : (path === "C" ? "Triage Reviewer" : "—"),
      intent: INTENTS[i % INTENTS.length],
      confidence: Number(conf.toFixed(3)),
      kb_match: path === "A" ? Number((0.81 + (i % 9) * 0.012).toFixed(2)) : (path === "B" ? Number((0.42 + (i % 9) * 0.03).toFixed(2)) : Number((0.31 + (i % 9) * 0.02).toFixed(2))),
      received_at: rec.toISOString(),
      sla_pct,
      sla_deadline_min: sla_pct ? Math.round((100 - sla_pct) * 1.4) : null,
      attachments: i % 3 === 0 ? Math.max(1, i % 4) : 0,
      ticket_id: path === "B" ? `INC-${String(2_140_000 + i).padStart(7,"0")}` : null,
      reopened: i % 17 === 0,
    });
  }
  return items;
})();

// Trends — last 30 days
const TREND_30D = (() => {
  const out = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date(2026, 3, 28 - i); // Apr 28 backwards
    const base = 38 + Math.round(14 * Math.sin(i / 4)) + (i % 7 === 0 ? -8 : 0);
    out.push({
      date: d.toISOString().slice(5, 10),
      A: Math.max(8, Math.round(base * 0.62 + (i % 5))),
      B: Math.max(4, Math.round(base * 0.27 + (i % 3))),
      C: Math.max(2, Math.round(base * 0.11 + (i % 2))),
      received: base + 2,
    });
  }
  return out;
})();

// Hourly throughput (last 24h)
const HOURLY_24H = Array.from({ length: 24 }, (_, h) => ({
  hour: String(h).padStart(2,"0"),
  ingested: 4 + Math.round(8 * Math.abs(Math.sin((h - 8) / 3))) + (h > 8 && h < 18 ? 6 : 0),
  resolved: 3 + Math.round(7 * Math.abs(Math.sin((h - 9) / 3))) + (h > 9 && h < 19 ? 5 : 0),
}));

// Confidence histogram
const CONFIDENCE_HIST = [
  { band: "0.0–0.2", n: 4 },
  { band: "0.2–0.4", n: 11 },
  { band: "0.4–0.6", n: 18 },
  { band: "0.6–0.8", n: 27 },
  { band: "0.8–0.9", n: 64 },
  { band: "0.9–1.0", n: 142 },
];

// SLA breaches by team
const SLA_BY_TEAM = [
  { team: "Billing Ops", on_time: 84, breached: 7 },
  { team: "Procurement", on_time: 41, breached: 2 },
  { team: "Tax & Compliance", on_time: 22, breached: 4 },
  { team: "Vendor Relations", on_time: 38, breached: 1 },
  { team: "Eng. Liaison", on_time: 14, breached: 0 },
  { team: "Legal", on_time: 9, breached: 1 },
];

// Top intents
const TOP_INTENTS = [
  { intent: "Invoice clarification", n: 89 },
  { intent: "Payment status",        n: 64 },
  { intent: "Statement reconciliation", n: 41 },
  { intent: "Banking detail change", n: 28 },
  { intent: "Tax form W‑9",          n: 22 },
  { intent: "PO confirmation",       n: 19 },
];

const KB_ARTICLES = [
  { id: "kb_001", title: "Standard remittance address by region",                 last_updated: "2026-04-12", uses_30d: 142, hit_rate: 0.94 },
  { id: "kb_002", title: "How to interpret short‑pay deductions on remittance",   last_updated: "2026-03-28", uses_30d: 88,  hit_rate: 0.81 },
  { id: "kb_003", title: "Updated banking details — verification protocol",       last_updated: "2026-04-22", uses_30d: 64,  hit_rate: 0.97 },
  { id: "kb_004", title: "W‑9 collection workflow (US vendors)",                  last_updated: "2026-02-11", uses_30d: 51,  hit_rate: 0.92 },
  { id: "kb_005", title: "MSA amendment counter‑signature SLA",                   last_updated: "2026-01-19", uses_30d: 18,  hit_rate: 0.74 },
  { id: "kb_006", title: "Late fee waiver — eligibility matrix",                  last_updated: "2026-04-02", uses_30d: 33,  hit_rate: 0.88 },
  { id: "kb_007", title: "Service credit calculation methodology",                last_updated: "2025-11-30", uses_30d: 22,  hit_rate: 0.79 },
  { id: "kb_008", title: "Diversity certification — NAICS code refresh",          last_updated: "2026-03-04", uses_30d: 9,   hit_rate: 0.66 },
  { id: "kb_009", title: "Insurance certificate renewal cadence",                 last_updated: "2026-04-15", uses_30d: 27,  hit_rate: 0.91 },
  { id: "kb_010", title: "Portal lockout — self‑service unlock procedure",        last_updated: "2026-04-20", uses_30d: 14,  hit_rate: 0.83 },
  { id: "kb_011", title: "1099 issuance — fiscal year cutoffs",                   last_updated: "2025-12-15", uses_30d: 6,   hit_rate: 0.71 },
  { id: "kb_012", title: "Standing PO cancellation — required approvers",         last_updated: "2026-02-28", uses_30d: 11,  hit_rate: 0.77 },
];

const INTEGRATIONS = [
  { name: "Amazon Bedrock",            kind: "LLM",            status: "healthy", latency_ms: 612,  region: "us-east-1", note: "claude-sonnet-3.5 + titan-embed-v2" },
  { name: "Amazon RDS for PostgreSQL", kind: "Database",       status: "healthy", latency_ms: 14,   region: "us-east-1", note: "pgvector 0.7.0 · 6 schemas" },
  { name: "Amazon S3",                 kind: "Object Storage", status: "healthy", latency_ms: 41,   region: "us-east-1", note: "vqms-data-store · 1.84 TB" },
  { name: "Amazon SQS",                kind: "Queue",          status: "healthy", latency_ms: 22,   region: "us-east-1", note: "intake + DLQ · 3 visible" },
  { name: "Amazon EventBridge",        kind: "Events",         status: "healthy", latency_ms: 18,   region: "us-east-1", note: "20 event types" },
  { name: "Amazon Textract",           kind: "OCR",            status: "healthy", latency_ms: 1850, region: "us-east-1", note: "async jobs only" },
  { name: "Microsoft Graph API",       kind: "Email Source",   status: "degraded",latency_ms: 2240, region: "global",    note: "throttling on /messages — 429s last 14m" },
  { name: "Salesforce CRM",            kind: "Vendor Master",  status: "healthy", latency_ms: 380,  region: "—",         note: "Vendor_Account__c · 8 cached" },
  { name: "ServiceNow ITSM",           kind: "Ticketing",      status: "healthy", latency_ms: 491,  region: "—",         note: "incident table · webhook live" },
  { name: "OpenAI (fallback)",         kind: "LLM",            status: "standby", latency_ms: null, region: "—",         note: "GPT-4o · used 0× in 24h" },
];

const QUEUES = [
  { name: "vqms-email-intake-queue", visible: 3, in_flight: 1, dlq: 0, oldest_age_s: 7,   throughput_1m: 14 },
  { name: "vqms-query-intake-queue", visible: 0, in_flight: 0, dlq: 0, oldest_age_s: 0,   throughput_1m: 6 },
  { name: "vqms-email-intake-dlq",   visible: 0, in_flight: 0, dlq: 0, oldest_age_s: 0,   throughput_1m: 0 },
  { name: "vqms-query-intake-dlq",   visible: 1, in_flight: 0, dlq: 1, oldest_age_s: 4_120, throughput_1m: 0 },
];

const EMAIL_PIPELINE = [
  { stage: "MS Graph webhook",      in: 218, out: 218, errors: 0,  median_ms: 84 },
  { stage: "Relevance filter",      in: 218, out: 187, errors: 0,  median_ms: 31 }, // 4-layer noise drop
  { stage: "Attachment processor",  in: 187, out: 184, errors: 3,  median_ms: 1240 },
  { stage: "Vendor identifier",     in: 184, out: 184, errors: 0,  median_ms: 96 },
  { stage: "Thread correlator",     in: 184, out: 184, errors: 0,  median_ms: 22 },
  { stage: "Persist + SQS enqueue", in: 184, out: 184, errors: 0,  median_ms: 51 },
];

// Audit log
const AUDIT_LOG = [
  { ts: "2026-04-28 14:21:08", actor: "system",                  action: "Path A resolution delivered", target: "VQ-2026-1842", note: "kb_001 · conf 0.93" },
  { ts: "2026-04-28 14:19:42", actor: "n.shah@hexaware.com",     action: "Triage decision — corrected intent", target: "VQ-2026-1838", note: "→ Banking detail change" },
  { ts: "2026-04-28 14:18:11", actor: "system",                  action: "SLA warning fired (70%)",      target: "VQ-2026-1816", note: "Billing Ops · 14m left" },
  { ts: "2026-04-28 14:15:33", actor: "k.tanaka@hexaware.com",   action: "Draft approved",               target: "VQ-2026-1834", note: "Path B resolution-from-notes" },
  { ts: "2026-04-28 14:12:07", actor: "system",                  action: "Quality Gate failed — redraft",target: "VQ-2026-1839", note: "missing_attribution" },
  { ts: "2026-04-28 14:09:51", actor: "system",                  action: "ServiceNow webhook RESOLVED",  target: "INC-2140017",  note: "→ Step 15 enqueued" },
  { ts: "2026-04-28 14:04:18", actor: "j.okafor@hexaware.com",   action: "Bulk reroute (12)",            target: "—",            note: "Procurement → Billing Ops" },
  { ts: "2026-04-28 14:01:02", actor: "system",                  action: "Episodic memory written",      target: "VQ-2026-1830", note: "vendor V-002 · invoice clarification" },
  { ts: "2026-04-28 13:58:44", actor: "system",                  action: "Path C package persisted",     target: "VQ-2026-1837", note: "conf 0.49" },
  { ts: "2026-04-28 13:54:22", actor: "admin@hexaware.com",      action: "Feature flag toggled",         target: "step15_resolution_from_notes", note: "OFF → ON" },
];

const USERS = [
  { email: "admin@hexaware.com",         name: "Anika Verma",   role: "Admin",          last_active: "2m",  status: "online" },
  { email: "n.shah@hexaware.com",        name: "Niraj Shah",    role: "Reviewer",       last_active: "now", status: "online" },
  { email: "k.tanaka@hexaware.com",      name: "Kenji Tanaka",  role: "Admin",          last_active: "8m",  status: "online" },
  { email: "j.okafor@hexaware.com",      name: "Jide Okafor",   role: "Admin",          last_active: "21m", status: "away" },
  { email: "p.barros@hexaware.com",      name: "Paula Barros",  role: "Reviewer",       last_active: "2h",  status: "offline" },
  { email: "h.lefevre@hexaware.com",     name: "Hugo Lefèvre",  role: "Reviewer",       last_active: "now", status: "online" },
  { email: "vendor@cloudwave.io",        name: "Marcus Holloway", role: "Vendor",       last_active: "1d",  status: "offline" },
];

const FEATURE_FLAGS = [
  { key: "step15_resolution_from_notes", on: true,  scope: "global", changed: "2026-04-28 13:54" },
  { key: "openai_fallback",              on: true,  scope: "global", changed: "2026-04-22 09:11" },
  { key: "auto_close_after_window",      on: true,  scope: "global", changed: "2026-04-08 12:00" },
  { key: "reviewer_copilot_sse",         on: true,  scope: "reviewer", changed: "2026-04-15 17:42" },
  { key: "bulk_reroute",                 on: true,  scope: "vendor_manager", changed: "2026-03-30 10:18" },
  { key: "vendor_self_serve_kb",         on: false, scope: "vendor", changed: "2026-02-12 11:01" },
  { key: "amazon_bedrock_streaming",     on: false, scope: "global", changed: "—" },
];

const PATH_COLORS = { A: "var(--path-a)", B: "var(--path-b)", C: "var(--path-c)" };

// Threading sample for one query (for detail view)
const SAMPLE_THREAD = [
  {
    direction: "inbound", from: "billing@cloudwave.io", to: "vendor-support@hexaware.com",
    ts: "2026-04-28 11:14",
    subject: "Re: Invoice INV-88241 short paid by $1,847",
    body: "Hi team — we received your remittance for INV-88241 but it short‑paid by $1,847.00. Could you confirm the deduction code and provide the netted document? Our records show this should have paid in full at $24,310.50. Attaching the original invoice and the remittance advice.\n\nThanks,\nMarcus Holloway\nCloudwave Hosting · Account Manager",
    attachments: [{ name: "INV-88241.pdf", size: "184 KB" }, { name: "Remittance-2026-04-22.pdf", size: "62 KB" }]
  },
  {
    direction: "system", ts: "2026-04-28 11:14:08",
    note: "Email parsed · vendor identified V-001 (Cloudwave Hosting) via Salesforce match · attachments OCR'd via Amazon Textract"
  },
  {
    direction: "system", ts: "2026-04-28 11:14:22",
    note: "Query analysis · intent=Invoice clarification · confidence=0.93 · KB best match kb_002 cosine=0.87 → Path A"
  },
];

// Suggested response
const AI_SUGGESTED = `Hi Marcus,

Thanks for the detail. The $1,847.00 short‑pay on INV-88241 corresponds to deduction code SP‑D‑412 (early‑payment discount applied per your January 2026 amendment). The netted document is attached as INV-88241‑NET.pdf.

Summary of the math:
  Original invoice         $24,310.50
  Early‑payment discount   −$ 1,847.00  (7.6% per Amendment §3.2)
  Remitted total           $22,463.50

If your records reflect a different posting, let us know the AR document number on your side and we'll reconcile.

Best,
Hexaware Vendor Support`;

const SOURCES_USED = [
  { kb_id: "kb_002", title: "How to interpret short‑pay deductions on remittance", cosine: 0.87 },
  { kb_id: "kb_001", title: "Standard remittance address by region",                cosine: 0.74 },
];

// ============================================================
// EMAIL MANAGEMENT — data shape mirrors intake.email_messages +
// intake.admin_outbound_emails + workflow.draft_responses
// ============================================================

// Folders (left rail) — counts derived live in screens-mail.jsx,
// these defaults are seeded for first render
const MAIL_FOLDERS = [
  { id: "all",         label: "All Mail",        icon: "mails" },
  { id: "unread",      label: "Unread",          icon: "mail" },
  { id: "inbox",       label: "Inbox",           icon: "inbox" },
  { id: "sent",        label: "Sent",            icon: "send" },
  { id: "drafts",      label: "Drafts",          icon: "file-edit" },
  { id: "awaiting",    label: "Awaiting reply",  icon: "clock" },
  { id: "ai_suggested",label: "AI‑suggested",    icon: "sparkles" },
  { id: "flagged",     label: "Flagged",         icon: "flag" },
  { id: "archived",    label: "Archived",        icon: "archive" },
  { id: "spam",        label: "Filtered out",    icon: "ban" },
];

// Email message rows. Field names match intake.email_messages columns
// (message_id, conversation_id, in_reply_to, from_address, to_addresses,
// cc_addresses, subject, body_text, body_html, received_at, ingestion_status,
// attachments via intake.email_attachments → S3 keys). We add UI-only
// fields prefixed with `_` for derived display state.
const MAIL_BODIES = {
  short_pay: `Hi team,

We received your remittance for INV-88241 but it short‑paid by $1,847.00. Could you confirm the deduction code and provide the netted document? Our records show this should have paid in full at $24,310.50.

Attaching the original invoice and the remittance advice.

Thanks,
Marcus Holloway
Cloudwave Hosting · Account Manager
+1 206 555 0188`,
  banking: `Hello,

Effective May 1, our bank details have changed. Please update your records:

  Bank:        First Continental
  Routing:     026009593
  Account:     ••••‑••‑4419
  SWIFT:       FCONUS33

Confirmation of receipt would be appreciated. We will continue to monitor inbound payments to the legacy account through May 31 as a safeguard.

Best regards,
Greta Lindqvist
Northwind Logistics`,
  recon: `Team —

Our Q1 2026 statement shows $112,408.00 outstanding but our remittance ledger reflects $108,200.00 paid in full. The $4,208.00 delta appears across three invoices (INV‑87904, INV‑87918, INV‑87931). Can you reconcile and re‑issue the statement?

Spreadsheet attached.

— Reza Karimi, Sigma Data Labs`,
  partial: `PO 4419821 shipped in two parts (60% on Apr 14, 40% on Apr 22). Should we re‑bill against the same PO line items, or do you need split invoices? Following the convention you used last quarter unless we hear back.

Janelle Kowalski, Helios Print Co.`,
  w9: `Our W‑9 on file with your AP team expired in February. Please find the updated 2026 copy attached, signed by our controller. Confirm receipt at your convenience.

Thanks,
Hugo Lefèvre
Bramble & Hart LLP`,
  amendment: `Counter‑signature still pending on Amendment #3. Legal sent over the redline 11 days ago. SLA on contract amendments is 5 business days per our MSA — please advise.

Reza Karimi
Sigma Data Labs`,
  credit: `Per our SLA, the Feb 14 outage exceeded the 4‑hour resolution window by 2h 18m, qualifying for a service credit of 7.5% on the affected month. Please apply against May invoicing or remit separately.

Marcus Holloway
Cloudwave Hosting`,
  insurance: `Our certificate of insurance expires May 1. Renewed COI attached, effective through May 1, 2027. Carrier and coverage limits unchanged.

Owen Adesina, Northwind Logistics`,
  duplicate: `INV-88112 and INV-88114 appear to be duplicates of the same shipment (PO 4418901). Both were posted on Apr 18 with identical line items. Please void INV-88114.

Greta Lindqvist`,
  remit: `Please update remit‑to address for all future payments:

  Yamasaki Hardware Co., Ltd.
  3‑15‑8 Umeda, Kita‑ku
  Osaka 530‑0001, Japan

Effective immediately. ACH details unchanged.

Tomohiro Yamasaki`,
  rate: `The annual rate increase notice we received references a 6.4% adjustment but our MSA Section 7.3 caps yearly escalation at CPI+1% (currently 4.2%). Could you clarify how 6.4% was derived?

Reza Karimi, Sigma Data Labs`,
  paid: `We received a past‑due reminder this morning for INV-87900, but our records show this was paid via ACH on Apr 11 (ref #FT2026041100871). Attaching wire confirmation.

— Janelle, Helios Print`,
};

const MAIL_THREADS = (() => {
  const now = new Date("2026-04-28T14:23:00Z");
  const seeds = [
    { vendor: "V-001", contact: "Marcus Holloway", email: "billing@cloudwave.io", subject: "Re: Invoice INV‑88241 short paid by $1,847", body: "short_pay",  path: "A", conf: 0.93, query_id: "VQ-2026-1842", path_team: null, sla: 22, attach: ["INV-88241.pdf","Remittance-2026-04-22.pdf"], flagged: false, has_ai: true, status: "unread"   , dir: "inbound" },
    { vendor: "V-002", contact: "Greta Lindqvist", email: "g.lindqvist@northwindlog.com", subject: "Updated banking details — please confirm receipt", body: "banking", path: "C", conf: 0.49, query_id: "VQ-2026-1841", path_team: "Triage Reviewer", sla: 71, attach: ["Bank-Letter-Northwind.pdf"], flagged: true, has_ai: true, status: "unread", dir: "inbound" },
    { vendor: "V-003", contact: "Reza Karimi",     email: "rk@sigmadata.ai", subject: "Q1 2026 statement does not match remittance", body: "recon", path: "B", conf: 0.88, query_id: "VQ-2026-1840", path_team: "Billing Ops", sla: 48, attach: ["Q1-2026-Recon.xlsx"], flagged: false, has_ai: false, status: "read", dir: "inbound" },
    { vendor: "V-004", contact: "Janelle Kowalski", email: "j.kowalski@helios.print", subject: "PO 4419821 — partial shipment, do we re‑bill?", body: "partial", path: "B", conf: 0.86, query_id: "VQ-2026-1839", path_team: "Procurement", sla: 92, attach: [], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    { vendor: "V-005", contact: "Hugo Lefèvre",    email: "h.lefevre@bramblehart.com", subject: "W‑9 expired, need updated copy on file", body: "w9", path: "A", conf: 0.91, query_id: "VQ-2026-1838", path_team: null, sla: 8, attach: ["W9-2026-Bramble.pdf"], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    { vendor: "V-003", contact: "Reza Karimi",     email: "rk@sigmadata.ai", subject: "Amendment #3 to MSA — counter‑signature pending", body: "amendment", path: "B", conf: 0.87, query_id: "VQ-2026-1837", path_team: "Legal", sla: 96, attach: [], flagged: true, has_ai: false, status: "read", dir: "inbound" },
    { vendor: "V-001", contact: "Marcus Holloway", email: "m.holloway@cloudwave.io", subject: "Service credit owed for Feb 14 outage", body: "credit", path: "B", conf: 0.84, query_id: "VQ-2026-1836", path_team: "Billing Ops", sla: 38, attach: ["SLA-breach-log-Feb14.pdf"], flagged: false, has_ai: true, status: "unread", dir: "inbound" },
    { vendor: "V-002", contact: "Owen Adesina",    email: "ops@northwindlog.com", subject: "Certificate of insurance expiring May 1", body: "insurance", path: "A", conf: 0.95, query_id: "VQ-2026-1835", path_team: null, sla: 12, attach: ["COI-Northwind-2027.pdf"], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    { vendor: "V-002", contact: "Greta Lindqvist", email: "g.lindqvist@northwindlog.com", subject: "Duplicate invoice INV‑88112 / INV‑88114 — please void one", body: "duplicate", path: "A", conf: 0.92, query_id: "VQ-2026-1834", path_team: null, sla: 18, attach: [], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    { vendor: "V-006", contact: "Tomohiro Yamasaki", email: "t.yamasaki@yamasaki.co.jp", subject: "Change of remit‑to address", body: "remit", path: "A", conf: 0.89, query_id: "VQ-2026-1833", path_team: null, sla: 9, attach: [], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    { vendor: "V-003", contact: "Reza Karimi",     email: "rk@sigmadata.ai", subject: "Annual rate increase notice — clarification", body: "rate", path: "C", conf: 0.51, query_id: "VQ-2026-1832", path_team: "Triage Reviewer", sla: 64, attach: ["MSA-Section-7.3-excerpt.pdf"], flagged: false, has_ai: true, status: "unread", dir: "inbound" },
    { vendor: "V-004", contact: "Janelle Kowalski", email: "j.kowalski@helios.print", subject: "Past‑due reminder for already‑paid INV‑87900", body: "paid", path: "A", conf: 0.94, query_id: "VQ-2026-1831", path_team: null, sla: 14, attach: ["FT2026041100871.pdf"], flagged: false, has_ai: true, status: "read", dir: "inbound" },
    // a sent reply to show "Sent" folder population
    { vendor: "V-001", contact: "Anika Verma",     email: "vendor-support@hexaware.com", subject: "Re: Insurance certificate renewal — confirmed", body: "insurance", path: "A", conf: 0.95, query_id: "VQ-2026-1835", path_team: null, sla: null, attach: [], flagged: false, has_ai: false, status: "sent", dir: "outbound" },
    // a draft
    { vendor: "V-005", contact: "Anika Verma",     email: "vendor-support@hexaware.com", subject: "Re: W‑9 expired, need updated copy on file (draft)", body: "w9", path: "A", conf: 0.91, query_id: "VQ-2026-1838", path_team: null, sla: null, attach: [], flagged: false, has_ai: false, status: "draft", dir: "outbound" },
  ];
  return seeds.map((s, i) => {
    const v = window.VENDORS.find(x => x.vendor_id === s.vendor);
    const rec = new Date(now.getTime() - i * 1000 * 60 * (12 + (i % 7) * 31));
    return {
      message_id: `<AAMkAG${(0xab12 + i * 211).toString(16)}@graph.microsoft.com>`,
      conversation_id: `conv_${(0xc92a + Math.floor(i / 2) * 41).toString(16)}`,
      in_reply_to: i % 3 === 0 ? `<AAMkAG${(0xab12 + (i - 1) * 211).toString(16)}@graph.microsoft.com>` : null,
      from_address: s.email,
      from_name: s.contact,
      to_addresses: s.dir === "inbound" ? ["vendor-support@hexaware.com"] : [s.email],
      cc_addresses: i % 5 === 0 ? ["ap-team@hexaware.com"] : [],
      subject: s.subject,
      body_text: MAIL_BODIES[s.body] || "(empty)",
      body_html: null,
      received_at: rec.toISOString(),
      ingestion_status: "PROCESSED",
      processed_at: new Date(rec.getTime() + 4200).toISOString(),
      attachments: s.attach.map((name, k) => ({
        attachment_id: `att_${i}_${k}`,
        filename: name,
        size_bytes: 60_000 + (k * 41_000) + (i * 7_000),
        mime_type: name.endsWith(".pdf") ? "application/pdf" : name.endsWith(".xlsx") ? "application/vnd.openxmlformats" : "application/octet-stream",
        s3_key: `s3://vqms-data-store/inbound-emails/${rec.toISOString().slice(0,10)}/${s.vendor}/${name}`,
      })),
      // links to workflow row
      query_id: s.query_id,
      processing_path: s.path,
      confidence_score: s.conf,
      assigned_team: s.path_team,
      ticket_id: s.path === "B" ? `INC-${String(2_140_000 + i).padStart(7,"0")}` : null,
      // vendor context
      vendor_id: s.vendor,
      vendor_name: v?.name || "—",
      vendor_tier: v?.tier || "SILVER",
      // ui-only
      _direction: s.dir,
      _status: s.status,                  // unread | read | sent | draft
      _flagged: s.flagged,
      _has_ai_draft: s.has_ai,
      _sla_pct: s.sla,
    };
  });
})();

// AI suggested drafts (workflow.draft_responses) — keyed by message_id
const MAIL_AI_DRAFTS = {
  // first inbound message (Marcus Holloway short-pay)
  [MAIL_THREADS[0].message_id]: {
    draft_id: "drf_a1b2c3",
    draft_type: "RESOLUTION",
    confidence: 0.93,
    body_text: `Hi Marcus,

Thanks for the detail. The $1,847.00 short‑pay on INV‑88241 corresponds to deduction code SP‑D‑412 (early‑payment discount applied per your January 2026 amendment). The netted document is attached as INV‑88241‑NET.pdf.

Summary of the math:
  Original invoice         $24,310.50
  Early‑payment discount   −$ 1,847.00  (7.6% per Amendment §3.2)
  Remitted total           $22,463.50

If your records reflect a different posting, share the AR document number on your side and we'll reconcile.

Best,
Hexaware Vendor Support`,
    sources: [
      { kb_id: "kb_002", title: "How to interpret short‑pay deductions on remittance", cosine: 0.87 },
      { kb_id: "kb_001", title: "Standard remittance address by region",                cosine: 0.74 },
    ],
    quality_gate: { passed: true, checks_passed: 7, checks_failed: 0 },
    generated_at: "2026-04-28T11:14:38Z",
  },
  [MAIL_THREADS[1].message_id]: {
    draft_id: "drf_d4e5f6",
    draft_type: "ACKNOWLEDGMENT",
    confidence: 0.49,
    body_text: `Hi Greta,

We've received your bank detail change request. For verification, our updated‑banking‑details protocol requires a second confirmation channel per kb_003.

A reviewer will validate and confirm receipt within 1 business day. No payments to the new account will be issued until verification clears.

Hexaware Vendor Support`,
    sources: [
      { kb_id: "kb_003", title: "Updated banking details — verification protocol", cosine: 0.81 },
    ],
    quality_gate: { passed: false, checks_passed: 5, checks_failed: 2, failed: ["confidence_below_threshold","verification_required"] },
    generated_at: "2026-04-28T13:51:02Z",
  },
  [MAIL_THREADS[6].message_id]: {
    draft_id: "drf_g7h8i9",
    draft_type: "ACKNOWLEDGMENT",
    confidence: 0.84,
    body_text: `Hi Marcus,

Your service credit request for the Feb 14 outage has been acknowledged and routed to Billing Ops (ticket INC‑2140006). Per our SLA, we'll calculate the eligible credit using the methodology in kb_007 and respond within 2 business days.

Hexaware Vendor Support`,
    sources: [{ kb_id: "kb_007", title: "Service credit calculation methodology", cosine: 0.79 }],
    quality_gate: { passed: true, checks_passed: 7, checks_failed: 0 },
    generated_at: "2026-04-28T12:48:11Z",
  },
};

// Email thread per conversation_id (full message history)
const MAIL_THREAD_HISTORY = {
  // conversation for the Cloudwave short-pay query
  [MAIL_THREADS[0].conversation_id]: [
    { from: "billing@cloudwave.io", from_name: "Marcus Holloway", to: ["vendor-support@hexaware.com"], ts: "2026-04-22T09:14:00Z", subject: "Invoice INV‑88241 — payment received, please confirm", snippet: "Wanted to confirm you received our payment for INV‑88241 last Friday…", collapsed: true },
    { from: "vendor-support@hexaware.com", from_name: "Hexaware Vendor Support", to: ["billing@cloudwave.io"], ts: "2026-04-22T11:02:00Z", subject: "Re: Invoice INV‑88241 — payment received", snippet: "Confirming receipt. Posting to your account today.", collapsed: true },
    { from: "billing@cloudwave.io", from_name: "Marcus Holloway", to: ["vendor-support@hexaware.com"], ts: "2026-04-28T11:14:00Z", subject: "Re: Invoice INV‑88241 short paid by $1,847", body: MAIL_BODIES.short_pay, attachments: ["INV-88241.pdf","Remittance-2026-04-22.pdf"], collapsed: false },
  ],
};

// Audit trail per message
const MAIL_AUDIT = {
  [MAIL_THREADS[0].message_id]: [
    { ts: "2026-04-28 11:14:00", actor: "system",                action: "Email received via Microsoft Graph webhook" },
    { ts: "2026-04-28 11:14:08", actor: "system",                action: "Vendor identified V‑001 (Cloudwave Hosting) via Salesforce" },
    { ts: "2026-04-28 11:14:14", actor: "system",                action: "Attachments OCR'd via Amazon Textract (2 files)" },
    { ts: "2026-04-28 11:14:22", actor: "system",                action: "Path A · KB match kb_002 cosine 0.87 · confidence 0.93" },
    { ts: "2026-04-28 11:14:38", actor: "system",                action: "AI draft generated — Quality Gate: passed (7/7)" },
    { ts: "2026-04-28 14:18:09", actor: "n.shah@hexaware.com",   action: "Viewed message" },
  ],
};

// Internal team notes per message_id
const MAIL_INTERNAL_NOTES = {
  [MAIL_THREADS[0].message_id]: [
    { author: "Niraj Shah", ts: "2026-04-28 13:42", text: "Marcus is the right contact here — billing@ alias forwards to him. Safe to send AI draft as‑is." },
    { author: "Kenji Tanaka", ts: "2026-04-28 14:05", text: "Confirmed amendment §3.2 applies. Approve." },
  ],
  [MAIL_THREADS[1].message_id]: [
    { author: "Niraj Shah", ts: "2026-04-28 13:55", text: "Banking change — route through verification protocol. Need callback to Greta on +1 312 555 0227 before clearing." },
  ],
};

// MS Graph sync health for the banner
const MAIL_SYNC = {
  last_sync_seconds_ago: 8,
  next_poll_seconds: 52,
  graph_status: "degraded",                  // matches INTEGRATIONS row
  graph_note: "throttling on /messages — 429s last 14m",
  sqs_visible: 3,
  sqs_in_flight: 1,
  sqs_dlq: 0,
};

// Email templates (proposed — codebase has S3 prefix `templates/` but no admin endpoint yet)
const MAIL_TEMPLATES = [
  { id: "tpl_ack_received",      name: "Acknowledgment — received",        category: "Acknowledgment" },
  { id: "tpl_w9_request",        name: "W‑9 request",                       category: "Tax" },
  { id: "tpl_short_pay_explain", name: "Short‑pay explanation",            category: "Billing" },
  { id: "tpl_banking_verify",    name: "Banking change — verification",    category: "Compliance" },
  { id: "tpl_resolution_close",  name: "Resolution & closure",             category: "Closure" },
];

// Backend endpoint contract — surfaced as a card in the UI for the dev handoff
const MAIL_ENDPOINTS = [
  { method: "GET",    path: "/admin/mail",                                     status: "exists",  source: "extends GET /emails (dashboard.py)", note: "add ?folder=&direction=&flagged=" },
  { method: "GET",    path: "/admin/mail/stats",                                status: "exists",  source: "GET /emails/stats",                  note: "folder counts" },
  { method: "GET",    path: "/admin/mail/{message_id}",                         status: "new",     source: "—",                                  note: "single message + thread + AI draft + audit" },
  { method: "GET",    path: "/admin/mail/thread/{conversation_id}",             status: "new",     source: "uses thread_correlator",             note: "full conversation by conversation_id" },
  { method: "POST",   path: "/admin/email/queries/{query_id}/reply",            status: "exists",  source: "admin_email.py",                     note: "preserves conversationId, multipart for attachments" },
  { method: "POST",   path: "/admin/email/send",                                status: "exists",  source: "admin_email.py",                     note: "fresh compose, X‑Request‑Id idempotency" },
  { method: "POST",   path: "/admin/mail/{message_id}/forward",                 status: "new",     source: "—",                                  note: "wraps email_send.send_message" },
  { method: "POST",   path: "/admin/mail/{message_id}/link-query",              status: "new",     source: "—",                                  note: "binds message → existing query_id" },
  { method: "POST",   path: "/admin/mail/{message_id}/create-query",            status: "new",     source: "wraps services/portal_submission",  note: "promotes orphan email to a query" },
  { method: "POST",   path: "/admin/mail/{message_id}/draft/approve",           status: "exists",  source: "admin_drafts.py",                    note: "uses workflow.draft_responses approval" },
  { method: "POST",   path: "/admin/mail/{message_id}/draft/regenerate",        status: "new",     source: "—",                                  note: "re‑runs resolution node" },
  { method: "POST",   path: "/admin/mail/{message_id}/draft/reject",            status: "exists",  source: "admin_drafts.py",                    note: "rejection + reason" },
  { method: "POST",   path: "/admin/mail/{message_id}/notes",                   status: "new",     source: "audit.action_log",                   note: "internal note on message" },
  { method: "POST",   path: "/admin/mail/{message_id}/flag",                    status: "new",     source: "—",                                  note: "toggle flagged" },
  { method: "POST",   path: "/admin/mail/{message_id}/archive",                 status: "new",     source: "—",                                  note: "soft‑archive" },
  { method: "POST",   path: "/admin/mail/bulk",                                 status: "new",     source: "—",                                  note: "{ids[], action: read|archive|assign|link_query}" },
  { method: "GET",    path: "/admin/mail/health",                                status: "exists",  source: "GET /health",                        note: "MS Graph + SQS sync status" },
  { method: "GET",    path: "/admin/mail/templates",                             status: "new",     source: "S3 prefix templates/",               note: "list reply templates" },
];

// expose
Object.assign(window, {
  VENDORS, CONTACTS, CONTRACTS, TEAMS, INTENTS, QUERIES,
  TREND_30D, HOURLY_24H, CONFIDENCE_HIST, SLA_BY_TEAM, TOP_INTENTS,
  KB_ARTICLES, INTEGRATIONS, QUEUES, EMAIL_PIPELINE, AUDIT_LOG,
  USERS, FEATURE_FLAGS, PATH_COLORS, SAMPLE_THREAD, AI_SUGGESTED, SOURCES_USED,
  MAIL_FOLDERS, MAIL_THREADS, MAIL_AI_DRAFTS, MAIL_THREAD_HISTORY, MAIL_AUDIT,
  MAIL_INTERNAL_NOTES, MAIL_SYNC, MAIL_TEMPLATES, MAIL_ENDPOINTS,
});
