// Small reusable presentational atoms

const Tier = ({ tier }) => {
  const map = {
    PLATINUM: { bg: "color-mix(in oklch, var(--ink) 92%, white)", fg: "var(--bg)", label: "Platinum" },
    GOLD:     { bg: "#a16207", fg: "white", label: "Gold" },
    SILVER:   { bg: "var(--line-strong)", fg: "var(--ink)", label: "Silver" },
    BRONZE:   { bg: "#9a3412", fg: "white", label: "Bronze" },
  };
  const t = map[tier] || map.SILVER;
  return (
    <span className="mono inline-flex items-center"
      style={{ background: t.bg, color: t.fg, fontSize: 9.5, padding: "1px 6px", borderRadius: 2, letterSpacing: ".08em", fontWeight: 600 }}>
      {t.label.toUpperCase()}
    </span>
  );
};

const PathBadge = ({ p, size = "md" }) => {
  if (!p || p === "—") return <span className="subtle mono text-xs">—</span>;
  const color = window.PATH_COLORS[p];
  const label = { A: "AI‑resolved", B: "Human team", C: "Reviewer" }[p];
  const small = size === "sm";
  return (
    <span className="inline-flex items-center gap-1.5" style={{ fontSize: small ? 11 : 12 }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: color, display: "inline-block" }} />
      <span className="mono" style={{ fontWeight: 600, color }}>Path {p}</span>
      {!small && <span className="muted">· {label}</span>}
    </span>
  );
};

const Status = ({ s }) => {
  const m = {
    RESOLVED:             { bg: "color-mix(in oklch, var(--ok) 14%, var(--panel))",   fg: "var(--ok)",   label: "Resolved" },
    DELIVERING:           { bg: "color-mix(in oklch, var(--info) 14%, var(--panel))", fg: "var(--info)", label: "Delivering" },
    DRAFTING:             { bg: "color-mix(in oklch, var(--info) 14%, var(--panel))", fg: "var(--info)", label: "Drafting" },
    VALIDATING:           { bg: "color-mix(in oklch, var(--info) 14%, var(--panel))", fg: "var(--info)", label: "Validating" },
    ROUTING:              { bg: "color-mix(in oklch, var(--info) 14%, var(--panel))", fg: "var(--info)", label: "Routing" },
    ANALYZING:            { bg: "color-mix(in oklch, var(--info) 14%, var(--panel))", fg: "var(--info)", label: "Analyzing" },
    AWAITING_RESOLUTION:  { bg: "color-mix(in oklch, var(--warn) 14%, var(--panel))", fg: "var(--warn)", label: "Awaiting" },
    PAUSED:               { bg: "color-mix(in oklch, var(--warn) 14%, var(--panel))", fg: "var(--warn)", label: "Paused" },
    REOPENED:             { bg: "color-mix(in oklch, var(--warn) 14%, var(--panel))", fg: "var(--warn)", label: "Reopened" },
    CLOSED:               { bg: "var(--bg)",                                            fg: "var(--muted)", label: "Closed" },
    FAILED:               { bg: "color-mix(in oklch, var(--bad) 14%, var(--panel))",  fg: "var(--bad)",  label: "Failed" },
    MERGED_INTO_PARENT:   { bg: "var(--bg)",                                            fg: "var(--muted)", label: "Merged" },
    RECEIVED:             { bg: "var(--bg)",                                            fg: "var(--ink-2)",label: "Received" },
  }[s] || { bg: "var(--bg)", fg: "var(--ink-2)", label: s };
  return (
    <span className="inline-flex items-center"
      style={{ background: m.bg, color: m.fg, fontSize: 11, padding: "2px 7px", borderRadius: 3, fontWeight: 500, letterSpacing: ".01em" }}>
      <span style={{ width: 4, height: 4, borderRadius: 999, background: m.fg, marginRight: 5 }} />
      {m.label}
    </span>
  );
};

const Priority = ({ p }) => {
  const map = { P1: { fg: "var(--bad)", bg: "color-mix(in oklch, var(--bad) 12%, var(--panel))" },
                P2: { fg: "var(--warn)", bg: "color-mix(in oklch, var(--warn) 12%, var(--panel))" },
                P3: { fg: "var(--muted)", bg: "var(--bg)" } }[p];
  return <span className="mono" style={{ background: map.bg, color: map.fg, fontSize: 10.5, fontWeight: 600, padding: "2px 6px", borderRadius: 2 }}>{p}</span>;
};

const ConfidenceBar = ({ value, threshold = 0.85 }) => {
  const pct = Math.round(value * 100);
  const fill = value >= threshold ? "var(--ok)" : value >= 0.6 ? "var(--warn)" : "var(--bad)";
  return (
    <div className="flex items-center gap-2">
      <div style={{ width: 60, height: 4, background: "var(--line)", borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: fill }} />
      </div>
      <span className="mono" style={{ fontSize: 11, color: "var(--ink-2)", minWidth: 32 }}>{value.toFixed(2)}</span>
    </div>
  );
};

const SLABar = ({ pct }) => {
  if (pct == null) return <span className="subtle mono text-xs">—</span>;
  const color = pct >= 95 ? "var(--bad)" : pct >= 85 ? "var(--warn)" : pct >= 70 ? "var(--warn)" : "var(--ok)";
  return (
    <div className="flex items-center gap-2">
      <div style={{ width: 56, height: 4, background: "var(--line)", borderRadius: 2, overflow: "hidden" }}>
        <div style={{ width: `${pct}%`, height: "100%", background: color }} />
      </div>
      <span className="mono" style={{ fontSize: 11, color: "var(--ink-2)" }}>{pct}%</span>
    </div>
  );
};

const HealthDot = ({ status }) => {
  const c = { healthy: "var(--ok)", degraded: "var(--warn)", down: "var(--bad)", standby: "var(--subtle)" }[status] || "var(--subtle)";
  const animate = status === "degraded" || status === "down";
  return <span className={animate ? "pulse-dot" : ""} style={{ display: "inline-block", width: 8, height: 8, borderRadius: 999, background: c }} />;
};

const KPI = ({ label, value, delta, sub, icon, accent, sparkline }) => (
  <div className="panel p-4 fade-up" style={{ borderRadius: 4 }}>
    <div className="flex items-start justify-between mb-3">
      <div className="text-[10.5px] muted uppercase tracking-wider font-medium">{label}</div>
      {icon && <I name={icon} size={14} className="muted" />}
    </div>
    <div className="flex items-baseline gap-2">
      <div className="ink" style={{ fontSize: 28, fontWeight: 600, letterSpacing: "-.02em", lineHeight: 1 }}>{value}</div>
      {delta != null && (
        <span className="mono" style={{ fontSize: 11, color: delta >= 0 ? "var(--ok)" : "var(--bad)", fontWeight: 600 }}>
          {delta >= 0 ? "▲" : "▼"} {Math.abs(delta)}%
        </span>
      )}
    </div>
    {sub && <div className="muted mt-1.5" style={{ fontSize: 11.5 }}>{sub}</div>}
    {sparkline && (
      <div className="mt-3 -mx-1">{sparkline}</div>
    )}
  </div>
);

const SectionHead = ({ title, desc, right }) => (
  <div className="flex items-end justify-between mb-3">
    <div>
      <div className="ink" style={{ fontSize: 14, fontWeight: 600 }}>{title}</div>
      {desc && <div className="muted mt-0.5" style={{ fontSize: 12 }}>{desc}</div>}
    </div>
    {right}
  </div>
);

const Mono = ({ children, className = "", style }) => (
  <span className={"mono " + className} style={{ fontSize: 12, color: "var(--ink-2)", ...style }}>{children}</span>
);

const Avatar = ({ name, size = 24 }) => {
  const initials = name.split(" ").map(s => s[0]).slice(0, 2).join("");
  // hash to color
  let h = 0; for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
  return (
    <span className="inline-flex items-center justify-center mono"
      style={{ width: size, height: size, borderRadius: 999, background: `oklch(78% .07 ${h})`, color: "#000",
               fontSize: size * 0.42, fontWeight: 600 }}>
      {initials}
    </span>
  );
};

const Empty = ({ icon = "inbox", title, desc }) => (
  <div className="flex flex-col items-center justify-center py-16 text-center fade-up">
    <div style={{ width: 48, height: 48, borderRadius: 999, background: "var(--bg)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <I name={icon} size={20} className="subtle" />
    </div>
    <div className="ink mt-3" style={{ fontSize: 14, fontWeight: 500 }}>{title}</div>
    {desc && <div className="muted mt-1" style={{ fontSize: 12, maxWidth: 320 }}>{desc}</div>}
  </div>
);

const Drawer = ({ open, onClose, children, width = 720 }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40" style={{ background: "rgba(0,0,0,.32)" }} onClick={onClose}>
      <div className="absolute right-0 top-0 bottom-0 panel fade-up overflow-auto"
        style={{ width, borderLeft: "1px solid var(--line-strong)" }}
        onClick={(e) => e.stopPropagation()}>
        {children}
      </div>
    </div>
  );
};

Object.assign(window, { Tier, PathBadge, Status, Priority, ConfidenceBar, SLABar, HealthDot, KPI, SectionHead, Mono, Avatar, Empty, Drawer });
